--
-- PostgreSQL database dump
--

\restrict GJCjCN0GFtlAHWdjwiw2YxF72JtWcf4dAojP3UWWcKqollutH5LsLLXU7phinU1

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: AccountType; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."AccountType" AS ENUM (
    'ASSET',
    'LIABILITY',
    'EQUITY',
    'REVENUE',
    'EXPENSE'
);


ALTER TYPE public."AccountType" OWNER TO cosmos;

--
-- Name: AssistantMessageRole; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."AssistantMessageRole" AS ENUM (
    'USER',
    'ASSISTANT',
    'SYSTEM',
    'TOOL'
);


ALTER TYPE public."AssistantMessageRole" OWNER TO cosmos;

--
-- Name: BankAccountProvider; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."BankAccountProvider" AS ENUM (
    'MANUAL_IMPORT',
    'AKOYA'
);


ALTER TYPE public."BankAccountProvider" OWNER TO cosmos;

--
-- Name: BankTxnStatus; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."BankTxnStatus" AS ENUM (
    'IMPORTED',
    'CATEGORIZED',
    'MATCHED',
    'POSTED',
    'EXCLUDED'
);


ALTER TYPE public."BankTxnStatus" OWNER TO cosmos;

--
-- Name: BillableType; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."BillableType" AS ENUM (
    'BILLABLE',
    'NON_BILLABLE',
    'INTERNAL'
);


ALTER TYPE public."BillableType" OWNER TO cosmos;

--
-- Name: BoardType; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."BoardType" AS ENUM (
    'KANBAN',
    'SCRUM',
    'BACKLOG',
    'TABLE',
    'CALENDAR',
    'TIMELINE',
    'OKR',
    'DASHBOARD',
    'PORTFOLIO',
    'RAID',
    'ROADMAP',
    'CFD',
    'PROGRAM'
);


ALTER TYPE public."BoardType" OWNER TO cosmos;

--
-- Name: ChatBotToolScope; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."ChatBotToolScope" AS ENUM (
    'NONE',
    'READONLY',
    'FULL'
);


ALTER TYPE public."ChatBotToolScope" OWNER TO cosmos;

--
-- Name: ChatChannelKind; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."ChatChannelKind" AS ENUM (
    'CHANNEL',
    'DM',
    'GROUP_DM'
);


ALTER TYPE public."ChatChannelKind" OWNER TO cosmos;

--
-- Name: ChatChannelMemberRole; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."ChatChannelMemberRole" AS ENUM (
    'ADMIN',
    'MEMBER'
);


ALTER TYPE public."ChatChannelMemberRole" OWNER TO cosmos;

--
-- Name: ChatMessageKind; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."ChatMessageKind" AS ENUM (
    'USER',
    'ACTION',
    'SYSTEM',
    'ASSISTANT'
);


ALTER TYPE public."ChatMessageKind" OWNER TO cosmos;

--
-- Name: ChatNotificationPref; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."ChatNotificationPref" AS ENUM (
    'ALL',
    'MENTIONS',
    'MUTED'
);


ALTER TYPE public."ChatNotificationPref" OWNER TO cosmos;

--
-- Name: ClassificationLevel; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."ClassificationLevel" AS ENUM (
    'PUBLIC',
    'UNCLASSIFIED',
    'FOUO',
    'CUI',
    'CONFIDENTIAL'
);


ALTER TYPE public."ClassificationLevel" OWNER TO cosmos;

--
-- Name: ColumnCategory; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."ColumnCategory" AS ENUM (
    'TODO',
    'IN_PROGRESS',
    'DONE',
    'CANCELLED'
);


ALTER TYPE public."ColumnCategory" OWNER TO cosmos;

--
-- Name: ComplianceFramework; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."ComplianceFramework" AS ENUM (
    'NIST_800_53',
    'NIST_800_171',
    'CMMC_L2',
    'FEDRAMP_MOD',
    'CUSTOM'
);


ALTER TYPE public."ComplianceFramework" OWNER TO cosmos;

--
-- Name: ControlStatus; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."ControlStatus" AS ENUM (
    'NOT_ASSESSED',
    'IN_PROGRESS',
    'IMPLEMENTED',
    'PARTIALLY_IMPLEMENTED',
    'NOT_APPLICABLE',
    'FAILED'
);


ALTER TYPE public."ControlStatus" OWNER TO cosmos;

--
-- Name: CycleKind; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."CycleKind" AS ENUM (
    'SPRINT',
    'PHASE',
    'MODULE',
    'RUN',
    'EVENT_DAY',
    'RELEASE',
    'ITERATION'
);


ALTER TYPE public."CycleKind" OWNER TO cosmos;

--
-- Name: Density; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."Density" AS ENUM (
    'COMPACT',
    'COMFORTABLE',
    'SPACIOUS'
);


ALTER TYPE public."Density" OWNER TO cosmos;

--
-- Name: EntryDirection; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."EntryDirection" AS ENUM (
    'DEBIT',
    'CREDIT'
);


ALTER TYPE public."EntryDirection" OWNER TO cosmos;

--
-- Name: ExpenseStatus; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."ExpenseStatus" AS ENUM (
    'DRAFT',
    'SUBMITTED',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public."ExpenseStatus" OWNER TO cosmos;

--
-- Name: FeedbackStatus; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."FeedbackStatus" AS ENUM (
    'OPEN',
    'PLANNED',
    'IN_PROGRESS',
    'DONE',
    'DECLINED'
);


ALTER TYPE public."FeedbackStatus" OWNER TO cosmos;

--
-- Name: FeedbackType; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."FeedbackType" AS ENUM (
    'BUG',
    'FEATURE'
);


ALTER TYPE public."FeedbackType" OWNER TO cosmos;

--
-- Name: FieldType; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."FieldType" AS ENUM (
    'TEXT',
    'NUMBER',
    'DATE',
    'SELECT',
    'MULTI_SELECT',
    'CHECKBOX',
    'URL',
    'EMAIL',
    'USER'
);


ALTER TYPE public."FieldType" OWNER TO cosmos;

--
-- Name: IntegrationStatus; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."IntegrationStatus" AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'ERROR'
);


ALTER TYPE public."IntegrationStatus" OWNER TO cosmos;

--
-- Name: JournalSource; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."JournalSource" AS ENUM (
    'MANUAL',
    'REVENUE',
    'EXPENSE'
);


ALTER TYPE public."JournalSource" OWNER TO cosmos;

--
-- Name: JournalStatus; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."JournalStatus" AS ENUM (
    'DRAFT',
    'POSTED',
    'VOID'
);


ALTER TYPE public."JournalStatus" OWNER TO cosmos;

--
-- Name: KeyResultStatus; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."KeyResultStatus" AS ENUM (
    'NOT_STARTED',
    'IN_PROGRESS',
    'AT_RISK',
    'ON_TRACK',
    'DONE'
);


ALTER TYPE public."KeyResultStatus" OWNER TO cosmos;

--
-- Name: MeetingStatus; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."MeetingStatus" AS ENUM (
    'SCHEDULED',
    'IN_PROGRESS',
    'MEETING_COMPLETED',
    'CANCELLED'
);


ALTER TYPE public."MeetingStatus" OWNER TO cosmos;

--
-- Name: MeetingType; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."MeetingType" AS ENUM (
    'STANDUP',
    'SPRINT_PLANNING',
    'SPRINT_REVIEW',
    'RETROSPECTIVE',
    'OTHER'
);


ALTER TYPE public."MeetingType" OWNER TO cosmos;

--
-- Name: NavigationStyle; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."NavigationStyle" AS ENUM (
    'TABS',
    'BREADCRUMBS',
    'BOTH'
);


ALTER TYPE public."NavigationStyle" OWNER TO cosmos;

--
-- Name: NormalBalance; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."NormalBalance" AS ENUM (
    'DEBIT',
    'CREDIT'
);


ALTER TYPE public."NormalBalance" OWNER TO cosmos;

--
-- Name: ObjectiveStatus; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."ObjectiveStatus" AS ENUM (
    'DRAFT',
    'ACTIVE',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public."ObjectiveStatus" OWNER TO cosmos;

--
-- Name: OrgRole; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."OrgRole" AS ENUM (
    'OWNER',
    'ADMIN',
    'BILLING_ADMIN',
    'MEMBER',
    'VIEWER',
    'GUEST'
);


ALTER TYPE public."OrgRole" OWNER TO cosmos;

--
-- Name: PeriodStatus; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."PeriodStatus" AS ENUM (
    'OPEN',
    'CLOSED'
);


ALTER TYPE public."PeriodStatus" OWNER TO cosmos;

--
-- Name: Plan; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."Plan" AS ENUM (
    'FREE',
    'TEAM',
    'BUSINESS',
    'ENTERPRISE',
    'GOV'
);


ALTER TYPE public."Plan" OWNER TO cosmos;

--
-- Name: Priority; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."Priority" AS ENUM (
    'CRITICAL',
    'HIGH',
    'MEDIUM',
    'LOW'
);


ALTER TYPE public."Priority" OWNER TO cosmos;

--
-- Name: ProjectRole; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."ProjectRole" AS ENUM (
    'MANAGER',
    'LEAD',
    'MEMBER',
    'VIEWER'
);


ALTER TYPE public."ProjectRole" OWNER TO cosmos;

--
-- Name: RevenueType; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."RevenueType" AS ENUM (
    'RECURRING',
    'ONE_TIME',
    'PROJECT_BASED'
);


ALTER TYPE public."RevenueType" OWNER TO cosmos;

--
-- Name: ScimResourceType; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."ScimResourceType" AS ENUM (
    'USER',
    'GROUP'
);


ALTER TYPE public."ScimResourceType" OWNER TO cosmos;

--
-- Name: SessionStatus; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."SessionStatus" AS ENUM (
    'ACTIVE',
    'EXPIRED',
    'REVOKED'
);


ALTER TYPE public."SessionStatus" OWNER TO cosmos;

--
-- Name: SidebarPosition; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."SidebarPosition" AS ENUM (
    'LEFT',
    'RIGHT'
);


ALTER TYPE public."SidebarPosition" OWNER TO cosmos;

--
-- Name: SprintStatus; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."SprintStatus" AS ENUM (
    'PLANNED',
    'ACTIVE',
    'COMPLETED'
);


ALTER TYPE public."SprintStatus" OWNER TO cosmos;

--
-- Name: ThemeMode; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."ThemeMode" AS ENUM (
    'LIGHT',
    'DARK',
    'HIGH_CONTRAST'
);


ALTER TYPE public."ThemeMode" OWNER TO cosmos;

--
-- Name: TimeEntryStatus; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."TimeEntryStatus" AS ENUM (
    'DRAFT',
    'SUBMITTED',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public."TimeEntryStatus" OWNER TO cosmos;

--
-- Name: Visibility; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."Visibility" AS ENUM (
    'PRIVATE',
    'PROJECT',
    'ORG'
);


ALTER TYPE public."Visibility" OWNER TO cosmos;

--
-- Name: WebhookDeliveryStatus; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."WebhookDeliveryStatus" AS ENUM (
    'PENDING',
    'SUCCESS',
    'FAILED'
);


ALTER TYPE public."WebhookDeliveryStatus" OWNER TO cosmos;

--
-- Name: WidgetCategory; Type: TYPE; Schema: public; Owner: cosmos
--

CREATE TYPE public."WidgetCategory" AS ENUM (
    'DATA',
    'LAYOUT',
    'FILTER',
    'INFO'
);


ALTER TYPE public."WidgetCategory" OWNER TO cosmos;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO cosmos;

--
-- Name: accounting_periods; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.accounting_periods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    status public."PeriodStatus" DEFAULT 'OPEN'::public."PeriodStatus" NOT NULL,
    closed_at timestamp(3) without time zone,
    closed_by_id uuid
);


ALTER TABLE public.accounting_periods OWNER TO cosmos;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    type public."AccountType" NOT NULL,
    normal_balance public."NormalBalance" NOT NULL,
    parent_id uuid,
    is_active boolean DEFAULT true NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.accounts OWNER TO cosmos;

--
-- Name: activities; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.activities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    work_item_id uuid NOT NULL,
    user_id uuid NOT NULL,
    action text NOT NULL,
    field text,
    old_value text,
    new_value text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.activities OWNER TO cosmos;

--
-- Name: allowed_emails; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.allowed_emails (
    id text NOT NULL,
    email text NOT NULL,
    added_by text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.allowed_emails OWNER TO cosmos;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.api_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    key_hash text NOT NULL,
    prefix text NOT NULL,
    scopes text[],
    expires_at timestamp(3) without time zone,
    last_used timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.api_keys OWNER TO cosmos;

--
-- Name: assistant_conversations; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.assistant_conversations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    user_id uuid NOT NULL,
    title text DEFAULT 'New conversation'::text NOT NULL,
    archived boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    cli_session_id text
);


ALTER TABLE public.assistant_conversations OWNER TO cosmos;

--
-- Name: assistant_messages; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.assistant_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    conversation_id uuid NOT NULL,
    role public."AssistantMessageRole" NOT NULL,
    content text DEFAULT ''::text NOT NULL,
    tool_calls jsonb DEFAULT '[]'::jsonb NOT NULL,
    tool_call_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.assistant_messages OWNER TO cosmos;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    user_id uuid,
    action text NOT NULL,
    entity text NOT NULL,
    entity_id text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    ip_address text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO cosmos;

--
-- Name: bank_accounts; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.bank_accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    institution text,
    mask text,
    currency text DEFAULT 'USD'::text NOT NULL,
    provider public."BankAccountProvider" DEFAULT 'MANUAL_IMPORT'::public."BankAccountProvider" NOT NULL,
    ledger_account_id uuid,
    is_active boolean DEFAULT true NOT NULL,
    created_by_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.bank_accounts OWNER TO cosmos;

--
-- Name: bank_rules; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.bank_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    description_contains text,
    direction text DEFAULT 'any'::text NOT NULL,
    amount_min numeric(19,4),
    amount_max numeric(19,4),
    category text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.bank_rules OWNER TO cosmos;

--
-- Name: bank_transactions; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.bank_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    bank_account_id uuid NOT NULL,
    external_id text,
    fingerprint text NOT NULL,
    posted_date date NOT NULL,
    amount numeric(19,4) NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    pending boolean DEFAULT false NOT NULL,
    status public."BankTxnStatus" DEFAULT 'IMPORTED'::public."BankTxnStatus" NOT NULL,
    matched_expense_id uuid,
    category text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    matched_revenue_id uuid
);


ALTER TABLE public.bank_transactions OWNER TO cosmos;

--
-- Name: board_columns; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.board_columns (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    board_id uuid NOT NULL,
    name text NOT NULL,
    key text NOT NULL,
    color text DEFAULT '#7dd3fc'::text NOT NULL,
    wip_limit integer,
    sort_order integer DEFAULT 0 NOT NULL,
    category public."ColumnCategory" DEFAULT 'TODO'::public."ColumnCategory" NOT NULL
);


ALTER TABLE public.board_columns OWNER TO cosmos;

--
-- Name: board_template_widgets; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.board_template_widgets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    template_id uuid NOT NULL,
    widget_slug text NOT NULL,
    parent_widget_id uuid,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    layout jsonb DEFAULT '{}'::jsonb NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.board_template_widgets OWNER TO cosmos;

--
-- Name: board_templates; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.board_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    slug text NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    methodology text,
    description text DEFAULT ''::text NOT NULL,
    thumbnail_url text,
    is_built_in boolean DEFAULT false NOT NULL,
    is_published boolean DEFAULT true NOT NULL,
    default_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    project_template_id uuid,
    sector text,
    source_template_id uuid,
    board_type text DEFAULT 'KANBAN'::text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.board_templates OWNER TO cosmos;

--
-- Name: boards; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.boards (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    project_id uuid NOT NULL,
    name text NOT NULL,
    type public."BoardType" NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.boards OWNER TO cosmos;

--
-- Name: chat_alert_keywords; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.chat_alert_keywords (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    keyword text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.chat_alert_keywords OWNER TO cosmos;

--
-- Name: chat_bot_channels; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.chat_bot_channels (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bot_id uuid NOT NULL,
    channel_id uuid NOT NULL,
    auto_respond boolean DEFAULT false NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.chat_bot_channels OWNER TO cosmos;

--
-- Name: chat_bot_runs; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.chat_bot_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bot_id uuid NOT NULL,
    message_id uuid NOT NULL,
    triggered_by_user_id uuid NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.chat_bot_runs OWNER TO cosmos;

--
-- Name: chat_bots; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.chat_bots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    key text NOT NULL,
    display_name text NOT NULL,
    persona text DEFAULT ''::text NOT NULL,
    model text DEFAULT 'sonnet'::text NOT NULL,
    tool_scope public."ChatBotToolScope" DEFAULT 'NONE'::public."ChatBotToolScope" NOT NULL,
    enabled_mcp boolean DEFAULT false NOT NULL,
    schedule_cron text,
    user_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.chat_bots OWNER TO cosmos;

--
-- Name: chat_channel_members; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.chat_channel_members (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    channel_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role public."ChatChannelMemberRole" DEFAULT 'MEMBER'::public."ChatChannelMemberRole" NOT NULL,
    notification_pref public."ChatNotificationPref" DEFAULT 'MENTIONS'::public."ChatNotificationPref" NOT NULL,
    last_read_message_id uuid,
    last_read_at timestamp(3) without time zone,
    muted_until timestamp(3) without time zone,
    joined_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.chat_channel_members OWNER TO cosmos;

--
-- Name: chat_channels; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.chat_channels (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    kind public."ChatChannelKind" NOT NULL,
    name text,
    slug text,
    description text,
    topic text,
    is_private boolean DEFAULT false NOT NULL,
    is_general boolean DEFAULT false NOT NULL,
    project_id uuid,
    created_by_id uuid NOT NULL,
    dm_key text,
    last_message_at timestamp(3) without time zone,
    archived_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.chat_channels OWNER TO cosmos;

--
-- Name: chat_message_attachments; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.chat_message_attachments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id uuid,
    kind text NOT NULL,
    url text NOT NULL,
    storage_key text NOT NULL,
    filename text NOT NULL,
    content_type text NOT NULL,
    size integer NOT NULL,
    width integer,
    height integer,
    uploaded_by_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    classification_level public."ClassificationLevel" DEFAULT 'UNCLASSIFIED'::public."ClassificationLevel" NOT NULL
);


ALTER TABLE public.chat_message_attachments OWNER TO cosmos;

--
-- Name: chat_message_mentions; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.chat_message_mentions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.chat_message_mentions OWNER TO cosmos;

--
-- Name: chat_message_reactions; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.chat_message_reactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id uuid NOT NULL,
    user_id uuid NOT NULL,
    emoji text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.chat_message_reactions OWNER TO cosmos;

--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.chat_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    channel_id uuid NOT NULL,
    author_id uuid NOT NULL,
    content text NOT NULL,
    parent_message_id uuid,
    edited_at timestamp(3) without time zone,
    deleted_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    content_tsv tsvector GENERATED ALWAYS AS (to_tsvector('english'::regconfig, COALESCE(content, ''::text))) STORED,
    kind public."ChatMessageKind" DEFAULT 'USER'::public."ChatMessageKind" NOT NULL
);


ALTER TABLE public.chat_messages OWNER TO cosmos;

--
-- Name: chat_pinned_messages; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.chat_pinned_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    channel_id uuid NOT NULL,
    message_id uuid NOT NULL,
    pinned_by_id uuid NOT NULL,
    pinned_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.chat_pinned_messages OWNER TO cosmos;

--
-- Name: chat_thread_followers; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.chat_thread_followers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    channel_id uuid NOT NULL,
    parent_message_id uuid NOT NULL,
    last_read_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.chat_thread_followers OWNER TO cosmos;

--
-- Name: comments; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.comments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    work_item_id uuid NOT NULL,
    author_id uuid NOT NULL,
    content text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.comments OWNER TO cosmos;

--
-- Name: compliance_controls; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.compliance_controls (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    framework public."ComplianceFramework" NOT NULL,
    control_id text NOT NULL,
    title text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    status public."ControlStatus" DEFAULT 'NOT_ASSESSED'::public."ControlStatus" NOT NULL,
    evidence jsonb DEFAULT '[]'::jsonb NOT NULL,
    notes text DEFAULT ''::text NOT NULL,
    assessed_at timestamp(3) without time zone,
    assessed_by_id uuid,
    due_date timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.compliance_controls OWNER TO cosmos;

--
-- Name: contracts; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.contracts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    partner_id uuid,
    product_id uuid,
    title text NOT NULL,
    value numeric(19,4),
    currency text DEFAULT 'USD'::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    start_date timestamp(3) without time zone,
    end_date timestamp(3) without time zone,
    terms text,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    docusign_envelope_id text,
    docusign_status text,
    signed_at timestamp(3) without time zone,
    search_vector jsonb
);


ALTER TABLE public.contracts OWNER TO cosmos;

--
-- Name: crm_contacts; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.crm_contacts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    stage text DEFAULT 'lead'::text NOT NULL,
    value text,
    deal_value numeric(19,4),
    contact_info text,
    owner_id uuid,
    notes text,
    custom_fields jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.crm_contacts OWNER TO cosmos;

--
-- Name: custom_fields; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.custom_fields (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    project_id uuid,
    name text NOT NULL,
    key text NOT NULL,
    field_type public."FieldType" NOT NULL,
    options jsonb DEFAULT '[]'::jsonb NOT NULL,
    required boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.custom_fields OWNER TO cosmos;

--
-- Name: cycle_capacities; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.cycle_capacities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    cycle_id uuid NOT NULL,
    user_id uuid NOT NULL,
    capacity double precision DEFAULT 0 NOT NULL,
    notes text DEFAULT ''::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.cycle_capacities OWNER TO cosmos;

--
-- Name: cycles; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.cycles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    project_id uuid NOT NULL,
    cycle_kind public."CycleKind" DEFAULT 'SPRINT'::public."CycleKind" NOT NULL,
    number integer NOT NULL,
    name text NOT NULL,
    sector_label text,
    goal text DEFAULT ''::text NOT NULL,
    start_date timestamp(3) without time zone NOT NULL,
    end_date timestamp(3) without time zone NOT NULL,
    status public."SprintStatus" DEFAULT 'PLANNED'::public."SprintStatus" NOT NULL,
    report jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.cycles OWNER TO cosmos;

--
-- Name: dashboard_widgets; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.dashboard_widgets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    board_id uuid NOT NULL,
    type text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    "position" jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.dashboard_widgets OWNER TO cosmos;

--
-- Name: data_classifications; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.data_classifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    project_id uuid,
    level public."ClassificationLevel" DEFAULT 'UNCLASSIFIED'::public."ClassificationLevel" NOT NULL,
    markings text[] DEFAULT ARRAY[]::text[],
    handling_instructions text DEFAULT ''::text NOT NULL,
    applied_by_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.data_classifications OWNER TO cosmos;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    project_id uuid NOT NULL,
    title text NOT NULL,
    classification_level public."ClassificationLevel" DEFAULT 'UNCLASSIFIED'::public."ClassificationLevel" NOT NULL,
    storage_key text NOT NULL,
    filename text NOT NULL,
    content_type text NOT NULL,
    size integer NOT NULL,
    uploaded_by_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.documents OWNER TO cosmos;

--
-- Name: expenses; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.expenses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    amount numeric(19,4) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    date date NOT NULL,
    category text NOT NULL,
    vendor text,
    description text DEFAULT ''::text NOT NULL,
    recurring boolean DEFAULT false NOT NULL,
    created_by_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    approved_at timestamp(3) without time zone,
    approved_by_id uuid,
    status public."ExpenseStatus" DEFAULT 'DRAFT'::public."ExpenseStatus" NOT NULL,
    submitted_at timestamp(3) without time zone
);


ALTER TABLE public.expenses OWNER TO cosmos;

--
-- Name: feedback_items; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.feedback_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    author_id uuid NOT NULL,
    type public."FeedbackType" DEFAULT 'FEATURE'::public."FeedbackType" NOT NULL,
    title text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    status public."FeedbackStatus" DEFAULT 'OPEN'::public."FeedbackStatus" NOT NULL,
    vote_count integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.feedback_items OWNER TO cosmos;

--
-- Name: feedback_votes; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.feedback_votes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    feedback_item_id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.feedback_votes OWNER TO cosmos;

--
-- Name: home_widgets; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.home_widgets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    owner_id uuid NOT NULL,
    type text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.home_widgets OWNER TO cosmos;

--
-- Name: integrations; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.integrations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    provider text NOT NULL,
    display_name text DEFAULT ''::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    status public."IntegrationStatus" DEFAULT 'ACTIVE'::public."IntegrationStatus" NOT NULL,
    installed_by_id uuid NOT NULL,
    last_sync_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.integrations OWNER TO cosmos;

--
-- Name: invitations; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.invitations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    email text NOT NULL,
    role public."OrgRole" DEFAULT 'MEMBER'::public."OrgRole" NOT NULL,
    token text DEFAULT gen_random_uuid() NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.invitations OWNER TO cosmos;

--
-- Name: ip_allowlists; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.ip_allowlists (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    cidr text NOT NULL,
    label text DEFAULT ''::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.ip_allowlists OWNER TO cosmos;

--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.journal_entries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    entry_number integer NOT NULL,
    date date NOT NULL,
    memo text DEFAULT ''::text NOT NULL,
    status public."JournalStatus" DEFAULT 'POSTED'::public."JournalStatus" NOT NULL,
    source public."JournalSource" DEFAULT 'MANUAL'::public."JournalSource" NOT NULL,
    source_id uuid,
    reverses_id uuid,
    posted_at timestamp(3) without time zone,
    created_by_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.journal_entries OWNER TO cosmos;

--
-- Name: journal_lines; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.journal_lines (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    journal_entry_id uuid NOT NULL,
    account_id uuid NOT NULL,
    direction public."EntryDirection" NOT NULL,
    amount numeric(19,4) NOT NULL,
    description text,
    sort_order integer DEFAULT 0 NOT NULL,
    project_id uuid,
    contract_id uuid,
    cost_objective_id uuid,
    cost_pool_id uuid
);


ALTER TABLE public.journal_lines OWNER TO cosmos;

--
-- Name: key_results; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.key_results (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    objective_id uuid NOT NULL,
    title text NOT NULL,
    description text,
    start_value double precision DEFAULT 0 NOT NULL,
    current_value double precision DEFAULT 0 NOT NULL,
    target_value double precision DEFAULT 100 NOT NULL,
    unit text DEFAULT ''::text NOT NULL,
    status public."KeyResultStatus" DEFAULT 'NOT_STARTED'::public."KeyResultStatus" NOT NULL,
    owner_id uuid,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.key_results OWNER TO cosmos;

--
-- Name: mcp_servers; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.mcp_servers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    transport text NOT NULL,
    command text,
    args text[] DEFAULT ARRAY[]::text[],
    env jsonb DEFAULT '{}'::jsonb NOT NULL,
    url text,
    headers jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.mcp_servers OWNER TO cosmos;

--
-- Name: meeting_attendees; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.meeting_attendees (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    meeting_id uuid NOT NULL,
    user_id uuid NOT NULL,
    done_since_last text DEFAULT ''::text NOT NULL,
    working_on text DEFAULT ''::text NOT NULL,
    blockers text DEFAULT ''::text NOT NULL,
    notes text DEFAULT ''::text NOT NULL
);


ALTER TABLE public.meeting_attendees OWNER TO cosmos;

--
-- Name: notes; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.notes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    author_id uuid NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    content text DEFAULT ''::text NOT NULL,
    visibility public."Visibility" DEFAULT 'PRIVATE'::public."Visibility" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    search_vector jsonb
);


ALTER TABLE public.notes OWNER TO cosmos;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    user_id uuid NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    ref_type text,
    ref_id text,
    read boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    url text
);


ALTER TABLE public.notifications OWNER TO cosmos;

--
-- Name: objectives; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.objectives (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    project_id uuid NOT NULL,
    title text NOT NULL,
    description text,
    owner_id uuid,
    period text,
    status public."ObjectiveStatus" DEFAULT 'ACTIVE'::public."ObjectiveStatus" NOT NULL,
    progress integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.objectives OWNER TO cosmos;

--
-- Name: org_member_work_roles; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.org_member_work_roles (
    org_member_id uuid NOT NULL,
    work_role_id uuid NOT NULL,
    scope jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.org_member_work_roles OWNER TO cosmos;

--
-- Name: org_members; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.org_members (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role public."OrgRole" DEFAULT 'MEMBER'::public."OrgRole" NOT NULL,
    permissions bigint DEFAULT 0 NOT NULL,
    abac_rules jsonb DEFAULT '{}'::jsonb NOT NULL,
    joined_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.org_members OWNER TO cosmos;

--
-- Name: org_security_settings; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.org_security_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    mfa_required boolean DEFAULT false NOT NULL,
    session_timeout_mins integer DEFAULT 480 NOT NULL,
    ip_allowlist_enabled boolean DEFAULT false NOT NULL,
    scim_enabled boolean DEFAULT false NOT NULL,
    sso_enforced boolean DEFAULT false NOT NULL,
    sso_connection_id text,
    allowed_domains text[] DEFAULT ARRAY[]::text[],
    audit_retention_days integer DEFAULT 365 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.org_security_settings OWNER TO cosmos;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.organizations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    auth0_org_id text,
    plan public."Plan" DEFAULT 'FREE'::public."Plan" NOT NULL,
    logo_url text,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    db_connection_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    theme_mode text,
    theme_primary text
);


ALTER TABLE public.organizations OWNER TO cosmos;

--
-- Name: partners; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.partners (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    type text DEFAULT 'vendor'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    website text,
    contact_name text,
    contact_email text,
    contact_phone text,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.partners OWNER TO cosmos;

--
-- Name: products; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    description text,
    sku text,
    price numeric(19,4),
    currency text DEFAULT 'USD'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    category text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.products OWNER TO cosmos;

--
-- Name: project_members; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.project_members (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    org_member_id uuid NOT NULL,
    role public."ProjectRole" DEFAULT 'MEMBER'::public."ProjectRole" NOT NULL
);


ALTER TABLE public.project_members OWNER TO cosmos;

--
-- Name: project_templates; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.project_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    slug text NOT NULL,
    sector text NOT NULL,
    name text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    thumbnail_url text,
    is_built_in boolean DEFAULT false NOT NULL,
    is_published boolean DEFAULT false NOT NULL,
    default_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    source_template_id uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.project_templates OWNER TO cosmos;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.projects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    key text NOT NULL,
    description text,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    archived boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    enabled_features text[] DEFAULT ARRAY[]::text[],
    project_template_id uuid
);


ALTER TABLE public.projects OWNER TO cosmos;

--
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.push_subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    endpoint text NOT NULL,
    p256dh text NOT NULL,
    auth text NOT NULL,
    user_agent text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_used_at timestamp(3) without time zone
);


ALTER TABLE public.push_subscriptions OWNER TO cosmos;

--
-- Name: revenues; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.revenues (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    amount numeric(19,4) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    date date NOT NULL,
    client text,
    product text,
    type public."RevenueType" DEFAULT 'ONE_TIME'::public."RevenueType" NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    created_by_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.revenues OWNER TO cosmos;

--
-- Name: saved_reports; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.saved_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    created_by_id uuid NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    schedule text,
    last_run_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.saved_reports OWNER TO cosmos;

--
-- Name: scim_tokens; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.scim_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    token_hash text NOT NULL,
    prefix text NOT NULL,
    label text DEFAULT ''::text NOT NULL,
    expires_at timestamp(3) without time zone,
    last_used timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.scim_tokens OWNER TO cosmos;

--
-- Name: session_records; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.session_records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    user_id uuid NOT NULL,
    session_token text NOT NULL,
    ip_address text,
    user_agent text,
    status public."SessionStatus" DEFAULT 'ACTIVE'::public."SessionStatus" NOT NULL,
    last_active_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    revoked_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.session_records OWNER TO cosmos;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    user_id uuid NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.sessions OWNER TO cosmos;

--
-- Name: sync_meetings; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.sync_meetings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    project_id uuid,
    sprint_id uuid,
    meeting_date timestamp(3) without time zone NOT NULL,
    meeting_type public."MeetingType" DEFAULT 'STANDUP'::public."MeetingType" NOT NULL,
    status public."MeetingStatus" DEFAULT 'SCHEDULED'::public."MeetingStatus" NOT NULL,
    transcript text,
    ai_summary text,
    ai_tickets jsonb DEFAULT '[]'::jsonb NOT NULL,
    notes text DEFAULT ''::text NOT NULL,
    created_by_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    search_vector jsonb,
    artifacts jsonb DEFAULT '[]'::jsonb NOT NULL,
    meet_conference_name text,
    meet_space_name text,
    meeting_url text,
    video_provider text
);


ALTER TABLE public.sync_meetings OWNER TO cosmos;

--
-- Name: themes; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.themes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    slug text NOT NULL,
    name text NOT NULL,
    mode public."ThemeMode" DEFAULT 'DARK'::public."ThemeMode" NOT NULL,
    colors jsonb DEFAULT '{}'::jsonb NOT NULL,
    typography jsonb DEFAULT '{}'::jsonb NOT NULL,
    spacing jsonb DEFAULT '{}'::jsonb NOT NULL,
    branding jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_built_in boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.themes OWNER TO cosmos;

--
-- Name: time_entries; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.time_entries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    user_id uuid NOT NULL,
    project_id uuid,
    work_item_id uuid,
    date date NOT NULL,
    hours double precision NOT NULL,
    rate numeric(19,4),
    client text,
    description text DEFAULT ''::text NOT NULL,
    billable_type public."BillableType" DEFAULT 'BILLABLE'::public."BillableType" NOT NULL,
    status public."TimeEntryStatus" DEFAULT 'DRAFT'::public."TimeEntryStatus" NOT NULL,
    approved_by_id uuid,
    approved_at timestamp(3) without time zone,
    tags text[] DEFAULT ARRAY[]::text[],
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.time_entries OWNER TO cosmos;

--
-- Name: user_preferences; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.user_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    theme_id uuid,
    theme_mode public."ThemeMode",
    sidebar_position public."SidebarPosition" DEFAULT 'LEFT'::public."SidebarPosition" NOT NULL,
    navigation_style public."NavigationStyle" DEFAULT 'BOTH'::public."NavigationStyle" NOT NULL,
    density public."Density" DEFAULT 'COMFORTABLE'::public."Density" NOT NULL,
    default_board_id uuid,
    methodology text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    bg_dark_url text,
    bg_light_url text,
    dnd_enabled boolean DEFAULT false NOT NULL,
    dnd_start text,
    dnd_end text,
    dnd_timezone text
);


ALTER TABLE public.user_preferences OWNER TO cosmos;

--
-- Name: users; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    auth0_user_id text,
    email text NOT NULL,
    display_name text NOT NULL,
    avatar_url text,
    last_active_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    google_id text,
    google_refresh_token text,
    is_bot boolean DEFAULT false NOT NULL,
    custom_status text,
    custom_status_emoji text,
    dnd_until_at timestamp(3) without time zone
);


ALTER TABLE public.users OWNER TO cosmos;

--
-- Name: webhook_deliveries; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.webhook_deliveries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    webhook_id uuid NOT NULL,
    event text NOT NULL,
    payload jsonb NOT NULL,
    status public."WebhookDeliveryStatus" DEFAULT 'PENDING'::public."WebhookDeliveryStatus" NOT NULL,
    status_code integer,
    response_body text,
    attempts integer DEFAULT 0 NOT NULL,
    last_attempt_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.webhook_deliveries OWNER TO cosmos;

--
-- Name: webhooks; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.webhooks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    url text NOT NULL,
    events text[],
    secret text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.webhooks OWNER TO cosmos;

--
-- Name: work_item_type_fields; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.work_item_type_fields (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    work_item_type_id uuid NOT NULL,
    custom_field_id uuid NOT NULL,
    required boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.work_item_type_fields OWNER TO cosmos;

--
-- Name: work_item_types; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.work_item_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid,
    project_template_id uuid,
    key text NOT NULL,
    name text NOT NULL,
    plural_name text,
    icon text,
    color text,
    is_built_in boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    default_parent_type_key text,
    celebrate_on_complete boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.work_item_types OWNER TO cosmos;

--
-- Name: work_items; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.work_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    project_id uuid NOT NULL,
    title text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    column_key text NOT NULL,
    assignee_id uuid,
    priority public."Priority" DEFAULT 'MEDIUM'::public."Priority" NOT NULL,
    parent_id uuid,
    ticket_number integer NOT NULL,
    story_points integer,
    sort_order integer DEFAULT 0 NOT NULL,
    due_date timestamp(3) without time zone,
    start_date timestamp(3) without time zone,
    completed_at timestamp(3) without time zone,
    column_entered_at timestamp(3) without time zone,
    tags text[] DEFAULT ARRAY[]::text[],
    custom_fields jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    cycle_id uuid,
    work_item_type_id uuid NOT NULL,
    search_vector jsonb
);


ALTER TABLE public.work_items OWNER TO cosmos;

--
-- Name: work_roles; Type: TABLE; Schema: public; Owner: cosmos
--

CREATE TABLE public.work_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    description text,
    grants bigint DEFAULT 0 NOT NULL,
    policies jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_built_in boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.work_roles OWNER TO cosmos;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
1d97a237-35f4-4a16-8f17-b96a41c0d31e	c587e5907c519522b0870bf490f003c79e9ced7816612bac92113ec71de5fe0b	2026-05-25 22:42:08.827338-04	20260525000000_baseline		\N	2026-05-25 22:42:08.827338-04	0
daf401b4-5059-4189-a144-0f43b85627da	fc2ae5540e898c3f79c05f688c8f763c14a56ebfde745e114b098bf98d1dfa63	2026-05-28 11:31:39.201538-04	20260528170000_team_chat_phase_1	\N	\N	2026-05-28 11:31:39.177551-04	1
fda74006-ceab-4106-a09d-2acade39b1b3	4a394b2e885b7304b16330c726d532837fca8b748b6bd46ef9e54d0387c6b147	2026-05-25 22:42:16.158807-04	20260526024216_phase_a_add_templates	\N	\N	2026-05-25 22:42:16.124364-04	1
1527beb3-f75b-4f03-a759-f398b7e8696f	3e79408637b10fc92f51d94c63d0df5ceb461b4db077af869adf47af5e48854e	2026-05-25 22:49:50.392645-04	20260526024950_add_board_template_type_sort	\N	\N	2026-05-25 22:49:50.390166-04	1
d2281a27-0662-44df-b604-d9020c5fb34e	230f3b2a51e9c44cbb01a4d445aa5b44af3098ab5eddecf2c31aa8e470e2502e	2026-06-02 10:51:29.551898-04	20260602030000_add_home_widgets	\N	\N	2026-06-02 10:51:29.474008-04	1
8c10b559-492b-4853-91ee-d714caf347a2	52126b7e02d1bc15973e21f1a42d2dbcd8f08471a6cd5ff754532902d05ddd5c	2026-05-25 23:06:27.67165-04	20260526030627_phase_c_drop_legacy	\N	\N	2026-05-25 23:06:27.662981-04	1
c3e20424-6b3e-4ca6-99e7-9525c520e58b	22c40abdd4fc6e3be9c9bc0ccafd6ebc3e6a9f1f6bc9728df6524934e4fba39b	2026-05-27 20:42:26.933168-04	20260527204215_add_meeting_title		\N	2026-05-27 20:42:26.933168-04	0
2ec31e8c-204d-434f-809e-40639fb28b0e	7ce25343abaa27c1097be8a6fdf526db84ecf66fe86aa038e63c31d1db35aaa6	2026-05-28 13:05:16.421114-04	20260528180000_backfill_notification_url	\N	\N	2026-05-28 13:05:16.418947-04	1
7a51d64b-a316-431e-b0fa-c31964b2c4ed	208db7cf8f32863462fbceca9a2908359aa74ed1eca6dd0b391e8fba97074144	2026-05-27 22:25:22.07064-04	20260528022522_add_bg_urls	\N	\N	2026-05-27 22:25:22.068292-04	1
314b50e7-71d7-4365-89ba-20b8113cbac1	f4b6cb83c060504fb77e0fd09dfbb2562e66fe8278c2e8527b2a90b588cb8e2f	2026-05-28 08:34:14.198065-04	20260528031245_custom_field_key_unique_per_org	\N	\N	2026-05-28 08:34:14.19343-04	1
74beec34-d2d5-4d78-9dd1-d09fa5b947a2	5b019dabe0e764ccd4457333218ebdf01ff58db57222c710e31e206f0d614f40	2026-05-28 08:34:14.571286-04	20260528123414_add_cli_session_id	\N	\N	2026-05-28 08:34:14.569321-04	1
af379ca1-25d0-46bd-84fe-38e5015d7000	9edf79f742aa8d169cdee94f0538befee2354abffb54167ecbd41c98e5c22b2e	2026-05-28 16:03:19.721587-04	20260529000000_chat_messages_tsvector	\N	\N	2026-05-28 16:03:19.706382-04	1
97faaf62-83cc-4b1a-8f79-e58567b53392	ce7b879a89e061ba448dec54bb61e16810a1cbba53dca85a3c6742bfcbf334c8	2026-05-28 08:54:40.780028-04	20260528125440_add_mcp_servers	\N	\N	2026-05-28 08:54:40.773723-04	1
884e176f-764c-40bc-bb11-4c90f8e6dd82	3461480966807a91737d58ad9971831cd2696e63ec8dc85d215ef549fd050240	2026-05-28 08:56:21.04046-04	20260528150000_add_embeddings	\N	\N	2026-05-28 08:56:21.03721-04	1
0b059ec1-22b1-417d-8435-8d67195607dc	a3f9ca78830ea870d04dfd3be9228025f877777df10901c7dcc6b35a080d9e2e	2026-05-28 20:24:57.890385-04	20260530000000_user_prefs_dnd	\N	\N	2026-05-28 20:24:57.887797-04	1
0b3aba3f-c483-4c80-b38c-89a0654c7e8e	3260663d71caa3a307b8ee5f9b76a20ca576d76f2d912f9d25b296fe45e29a4f	2026-06-02 15:09:05.858651-04	20260602040000_add_work_role_abac	\N	\N	2026-06-02 15:09:05.849146-04	1
d97fec84-c79d-4894-b902-4e1f1e8b7988	aa56f2f7a8ad7b2badade911389e7fde244cd4f42d0ca73223d887dae956294e	2026-05-29 00:04:10.239192-04	20260531000000_chat_message_kind	\N	\N	2026-05-29 00:04:10.235954-04	1
ec67bf7c-97ed-43af-be1e-ccd9987dbe09	3c442f7f6202ddbd3a266424e927d70d95792bd1ee01126dbff19e60375d9569	2026-06-03 10:45:54.303876-04	20260603120000_add_project_classification_relation		\N	2026-06-03 10:45:54.303876-04	0
59039715-1cae-42e7-b9aa-c7c8c9d70ed5	2a7e3a9de7f93820db4123523bf6540ebb6778d4885d05d618b9c7a4d62ee9f7	2026-05-28 11:06:54.543519-04	20260528160000_rename_chat_to_assistant	\N	\N	2026-05-28 11:06:54.540336-04	1
d77e2679-8c81-401f-9be8-bc7395c2da86	d7e17683eb731f9e6e800ea6d12f81fe8d0b189d25f30118e0d0c1603afb975b	2026-05-29 00:47:22.556048-04	20260531010000_chat_pinned_messages	\N	\N	2026-05-29 00:47:22.54944-04	1
ad0d2a06-7bd3-469c-839c-aeb58681b95a	a6a67f2918f58968207bf9747331bb86ff9b1e66c767ef8908a882e384a7e6d6	2026-06-04 23:06:42.717344-04	20260604010000_chat_bots	\N	\N	2026-06-04 23:06:42.703393-04	1
b8507dcd-218f-49f3-9cf3-fcc946a1df6d	05d79c5694b797f57989ae0b0b1ff37a61c57dc72600347875f83209cc14db9c	2026-06-02 08:22:05.707386-04	20260602000000_add_okr_models	\N	\N	2026-06-02 08:22:05.69666-04	1
9db1c922-72a5-4162-b887-9eb897345276	cac7c614a477b535eeefc5337be2f9d38e556560ce1e9dab5edf3f988eb0384b	2026-06-03 12:01:39.884973-04	20260603120000_add_meeting_video_fields	\N	\N	2026-06-03 12:01:39.881746-04	1
d713f5c6-6ee8-4c50-b7d1-3998b9ecc97d	2c3605fc96c50780b5abcd8a28022a8e824ebf31cec7947bb7bea6068b1b7e3d	2026-06-02 09:03:19.291387-04	20260602010000_add_feedback_portal	\N	\N	2026-06-02 09:03:19.282458-04	1
4760e441-4da7-4361-877f-9e61342f1454	0e03efd3c415d5307f26b6485d10bb59184d989e7e94b5adcfa9e5edb7fa624e	2026-06-04 09:24:19.601713-04	20260604120000_add_attachment_classification		\N	2026-06-04 09:24:19.601713-04	0
7afaf1a9-67c4-43a9-9799-67546e4ac066	b00f0b0a87740a6f674922cc8f994184c4a97325a0efec12b93c595815ffaa41	2026-06-02 10:03:41.722196-04	20260602020000_add_expense_approval	\N	\N	2026-06-02 10:03:41.715654-04	1
5bede526-3fc9-4fb8-95ce-723593b1d633	dabace560bddecf40e0cb6b637cb59282c1438d64eac47292b61f96c334a240d	2026-06-04 09:59:35.997171-04	20260604130000_add_documents		\N	2026-06-04 09:59:35.997171-04	0
e4844669-04e1-4c5d-a044-0737b104abc2	495fe446cb120c967b6d4f11b4b019bf3418a394f5f965ebf50bc166763e01f2	2026-06-04 23:06:42.735011-04	20260604030000_chat_alerts_presence	\N	\N	2026-06-04 23:06:42.730859-04	1
5d9dbcba-e232-41f0-b567-44a494752eac	3068b362d5a6e6d5e3566d5a184d33f969de03a9927cde01f6ee67bb0e25d648	2026-06-04 23:06:42.683029-04	20260603130000_money_float_to_decimal	\N	\N	2026-06-04 23:06:42.653736-04	1
fda27ad9-5c9d-4f50-96ac-f643cf6d7549	eed7980635b26fe3ee34df5d98ffe9cc3cfad3a8bc079d8bc90e77afcbc9827f	2026-06-04 23:06:42.72532-04	20260604020000_add_bank_feeds	\N	\N	2026-06-04 23:06:42.717725-04	1
e64a1fab-ca2a-4f95-ad1c-ac9c687eb727	e46368bd37aeb0a13ee291d00e977b35dfde801f01ca2a1f64541f7337b1b081	2026-06-04 23:06:42.702974-04	20260604000000_add_ledger_engine	\N	\N	2026-06-04 23:06:42.683462-04	1
2a5526ae-2236-4002-ad1c-5b5489832c49	9cd9d40d255b7cc1cd4478f0cb7740667266ce485609d29b79f9f6b72e42dcc7	2026-06-04 23:06:42.730475-04	20260604020000_chat_threads	\N	\N	2026-06-04 23:06:42.725743-04	1
0ff2ee92-7e7b-4995-b98b-6419a003d1ef	a51e2647c79180f432619efb55ef61b45f4594a3c7cc0a3da1b63508b4b035dc	2026-06-05 00:41:16.403621-04	20260605010000_add_bank_rules	\N	\N	2026-06-05 00:41:16.395914-04	1
82253185-ed2b-4249-b151-18e3eada31ab	8edef8121a80ea68813771ae7df20201320a45bb4a0d1a85aeb24a3eded2518b	2026-06-04 23:51:36.982578-04	20260605000000_add_bank_matched_revenue_id	\N	\N	2026-06-04 23:51:36.979812-04	1
\.


--
-- Data for Name: accounting_periods; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.accounting_periods (id, org_id, start_date, end_date, status, closed_at, closed_by_id) FROM stdin;
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.accounts (id, org_id, code, name, type, normal_balance, parent_id, is_active, is_system, created_at, updated_at) FROM stdin;
6c5bf3bc-281f-4793-aabf-bedd998d29b5	b3b93f25-2072-4514-8820-74712a67ca64	1000	Cash & Bank	ASSET	DEBIT	\N	t	t	2026-06-05 04:06:10.985	2026-06-05 04:06:10.985
10fc2280-6857-486d-b979-2aa32f68c515	b3b93f25-2072-4514-8820-74712a67ca64	1100	Accounts Receivable	ASSET	DEBIT	\N	t	t	2026-06-05 04:06:10.985	2026-06-05 04:06:10.985
3e0752c9-bb56-4369-b49f-70bdf0d8237e	b3b93f25-2072-4514-8820-74712a67ca64	2000	Accounts Payable	LIABILITY	CREDIT	\N	t	t	2026-06-05 04:06:10.985	2026-06-05 04:06:10.985
000aaf64-c302-4376-8c8f-69a6fb7e13c2	b3b93f25-2072-4514-8820-74712a67ca64	2100	Sales Tax Payable	LIABILITY	CREDIT	\N	t	t	2026-06-05 04:06:10.985	2026-06-05 04:06:10.985
4fb3590c-b74c-4b23-bcd1-cf2a2f06fbc0	b3b93f25-2072-4514-8820-74712a67ca64	3000	Owner's Equity	EQUITY	CREDIT	\N	t	t	2026-06-05 04:06:10.985	2026-06-05 04:06:10.985
4aa90558-2b54-4e18-9be9-58c172275e51	b3b93f25-2072-4514-8820-74712a67ca64	3900	Retained Earnings	EQUITY	CREDIT	\N	t	t	2026-06-05 04:06:10.985	2026-06-05 04:06:10.985
95084846-d67d-4885-8875-88463495fc3a	b3b93f25-2072-4514-8820-74712a67ca64	4000	Sales Revenue	REVENUE	CREDIT	\N	t	t	2026-06-05 04:06:10.985	2026-06-05 04:06:10.985
02cb2bfd-a172-48ac-8502-245f771a54e6	b3b93f25-2072-4514-8820-74712a67ca64	4100	Service Revenue	REVENUE	CREDIT	\N	t	t	2026-06-05 04:06:10.985	2026-06-05 04:06:10.985
f33b3d69-da6a-4435-9636-b4adf0eb46dc	b3b93f25-2072-4514-8820-74712a67ca64	4900	Other Income	REVENUE	CREDIT	\N	t	t	2026-06-05 04:06:10.985	2026-06-05 04:06:10.985
02d5d614-7cd8-457e-a194-b54323976094	b3b93f25-2072-4514-8820-74712a67ca64	5000	Cost of Goods Sold	EXPENSE	DEBIT	\N	t	t	2026-06-05 04:06:10.985	2026-06-05 04:06:10.985
7576a6aa-18fb-44af-903b-3f292948c916	b3b93f25-2072-4514-8820-74712a67ca64	6000	Operating Expenses	EXPENSE	DEBIT	\N	t	t	2026-06-05 04:06:10.985	2026-06-05 04:06:10.985
\.


--
-- Data for Name: activities; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.activities (id, org_id, work_item_id, user_id, action, field, old_value, new_value, created_at) FROM stdin;
f1f008b0-89f2-4e66-859e-9a8fcd2a7fd4	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	cf9cd7f6-67ec-445c-9dc8-3cf149094c8c	f1244511-9f53-4a78-b4d0-91851b50de2e	created	\N	\N	\N	2026-05-30 21:05:54.537
f6e53fb6-a2fc-49cd-8d76-9d00b2a1ce38	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	cf9cd7f6-67ec-445c-9dc8-3cf149094c8c	f1244511-9f53-4a78-b4d0-91851b50de2e	updated	columnKey	backlog	todo	2026-06-02 23:46:47.722
2eac69bb-cb6d-4c2a-917d-ea43da07591c	b3b93f25-2072-4514-8820-74712a67ca64	27fe3905-f7d8-4b4e-a720-b6946a5a8ca4	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	status_changed	columnKey	todo	in-progress	2026-05-28 13:24:16.685
98b04f5e-5fae-4bb9-a130-8747f6821d1e	b3b93f25-2072-4514-8820-74712a67ca64	27fe3905-f7d8-4b4e-a720-b6946a5a8ca4	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	assignee_changed	assigneeId	\N	Dana Reyes	2026-05-28 13:24:16.685
163c2e37-23ed-4712-8903-84d0761bdc3f	b3b93f25-2072-4514-8820-74712a67ca64	de5a0237-0d31-488a-b201-5cc7cf4bfd00	241480b1-17de-4c30-975e-722aa992e640	commented	\N	\N	\N	2026-06-02 13:24:16.685
\.


--
-- Data for Name: allowed_emails; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.allowed_emails (id, email, added_by, created_at) FROM stdin;
seed-fightingsmartcyber	fightingsmartcyber@gmail.com	\N	2026-05-21 12:55:21.278
cmpn0my480000jx7ww38bk864	steve@fightingsmartcyber.com	jon@fightingsmartcyber.com	2026-05-26 19:16:01.209
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.api_keys (id, org_id, name, key_hash, prefix, scopes, expires_at, last_used, created_at) FROM stdin;
\.


--
-- Data for Name: assistant_conversations; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.assistant_conversations (id, org_id, user_id, title, archived, created_at, updated_at, cli_session_id) FROM stdin;
a67e4d27-1cd7-4805-8400-765a09e14e90	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	New conversation	f	2026-05-27 20:26:40.598	2026-05-27 20:27:12.215	\N
9a07a706-9edb-4ed9-8c56-fdb3d6cd748d	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	New conversation	f	2026-05-28 03:45:12.257	2026-05-28 03:45:45.855	\N
7e3a76d1-6b2b-4002-8773-f43b5462f931	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	New conversation	t	2026-05-28 04:34:55.715	2026-05-28 04:35:07.151	\N
78fc82c1-1cea-47b8-ba92-669a127022f2	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	hello	f	2026-05-28 04:35:14.157	2026-05-28 04:35:30.061	\N
4f6d9aea-9e1a-4eea-988c-f06f1b6f823b	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	New conversation	f	2026-05-28 17:51:07.192	2026-05-28 17:51:07.192	\N
de9710e7-8e48-411d-965f-f16417894e8c	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	New conversation	f	2026-05-30 03:37:30.568	2026-05-30 03:37:30.568	\N
94a27c05-cd26-413d-af73-fa32867afe74	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	New conversation	f	2026-05-31 03:19:34.307	2026-05-31 03:19:34.307	\N
9986712c-d2e9-44f6-8a2f-dcc6f807be09	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	Give me the brief for the active sprint in the Sentinel prog	f	2026-06-03 13:01:18.051	2026-06-05 04:15:59.11	\N
\.


--
-- Data for Name: assistant_messages; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.assistant_messages (id, conversation_id, role, content, tool_calls, tool_call_id, created_at) FROM stdin;
06e4125f-249e-4787-b1ca-4134a9c7b920	a67e4d27-1cd7-4805-8400-765a09e14e90	USER	hello	[]	\N	2026-05-27 20:26:55.722
7bf749e0-9e94-4fe1-a3b0-415b125cdb7c	a67e4d27-1cd7-4805-8400-765a09e14e90	ASSISTANT	Hello! I'm **COSMOS AI**, your assistant for the COSMOS project management platform. I can help you with:\n\n- 📋 **Work Items** — query, create, or update tasks and issues\n- 🔄 **Cycles/Sprints** — check velocity, burndown, and status briefs\n- 👥 **CRM** — search contacts and pipeline deals\n- 💰 **Finance** — revenue, expenses, and time tracking\n- 🗒️ **Meeting Transcripts** — extract action items and decisions\n\nWhat can I help you with today?	[]	\N	2026-05-27 20:27:12.214
54e8ee41-f311-47ef-b341-db57a83e6126	9a07a706-9edb-4ed9-8c56-fdb3d6cd748d	USER	what tool calls are you capable of making?	[]	\N	2026-05-28 03:45:22.716
1b3dfed1-d34a-496e-89e4-6509b2a034ea	9a07a706-9edb-4ed9-8c56-fdb3d6cd748d	ASSISTANT	Here's a full breakdown of the tools available to me:\n\n## COSMOS Platform Tools\n\n| Tool | What it does |\n|------|-------------|\n| `query_work_items` | Search/filter work items by status, assignee, priority, cycle, type, or text |\n| `create_work_item` | Create new work items with title, type, priority, assignee, cycle, parent, and story points |\n| `update_work_item` | Update any field on an existing work item (status, priority, assignee, column, etc.) |\n| `query_cycles` | Fetch sprint/cycle data including velocity, item counts, and burndown |\n| `query_crm` | Search CRM contacts and pipeline deals by stage or name |\n| `query_finance` | Retrieve revenue, expenses, and time tracking summaries for a date range |\n| `generate_cycle_brief` | Generate a full sprint status report (velocity, burndown, blockers, team workload) |\n| `process_transcript` | Parse a meeting transcript to extract action items, decisions, and follow-ups |\n\n## Other Available Tools\n\n- **Browser/Playwright** — Navigate pages, take screenshots, interact with web UIs\n- **LSP** — Code intelligence (go to definition, find references, hover info, etc.)\n- **Context7** — Fetch up-to-date library/framework documentation\n- **Vercel MCP** — Interact with Vercel deployments (requires auth)\n- **Cloudflare MCP** — Interact with Cloudflare services (requires auth)\n\nMost of your day-to-day COSMOS questions will use the first set. What would you like to do?	[]	\N	2026-05-28 03:45:45.855
413769a7-079f-4dc7-9490-3da8017913a5	78fc82c1-1cea-47b8-ba92-669a127022f2	USER	hello	[]	\N	2026-05-28 04:35:14.222
fbfbc783-05d0-4112-9d52-36409fd2cc60	78fc82c1-1cea-47b8-ba92-669a127022f2	ASSISTANT	Hello! I'm **COSMOS AI**, your assistant for the COSMOS project management platform. 👋\n\nI can help you with things like:\n\n- 📋 **Work items** — search, create, or update tasks and issues\n- 🔄 **Cycles/Sprints** — check velocity, burndown, and status briefs\n- 👥 **CRM** — look up contacts and pipeline deals\n- 💰 **Finance** — review revenue, expenses, and time tracking\n- 📝 **Meetings** — extract action items from transcripts\n\nWhat can I help you with today?	[]	\N	2026-05-28 04:35:30.06
07dca795-8a44-414b-bf6d-3875bc9c2e07	4f6d9aea-9e1a-4eea-988c-f06f1b6f823b	USER	say hi in 5 words	[]	\N	2026-05-28 17:51:15.28
02416f31-b572-4a82-9b51-75e4d2c87b78	9986712c-d2e9-44f6-8a2f-dcc6f807be09	USER	Give me the brief for the active sprint in the Sentinel program (project key SENTINEL).	[]	\N	2026-06-03 13:01:18.117
93dd40a1-571a-42a0-9506-2fb2ee6d522a	9986712c-d2e9-44f6-8a2f-dcc6f807be09	ASSISTANT	Invalid API key · Fix external API key	[]	\N	2026-06-03 13:01:59.754
20590631-3316-4065-9bd9-15da1dd99320	9986712c-d2e9-44f6-8a2f-dcc6f807be09	USER	Give me the brief for the active sprint in the Sentinel program (project key SENTINEL).	[]	\N	2026-06-05 04:15:17.498
6d520a6a-20d0-4eb0-a5a6-8105e16fbb19	9986712c-d2e9-44f6-8a2f-dcc6f807be09	ASSISTANT	Invalid API key · Fix external API key	[]	\N	2026-06-05 04:15:59.109
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.audit_logs (id, org_id, user_id, action, entity, entity_id, metadata, ip_address, created_at) FROM stdin;
c46fc681-95e8-4510-9f25-d2f7694dd1cc	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	org.created	organization	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	{}	2607:fb90:eaa6:c374:65fd:6b46:209a:85db	2026-05-22 16:53:29.694
ae56f137-35e1-4bd5-872e-a80605e266ba	5311b52b-ae85-4f92-95e9-ed9bb7b91b1f	8ec2805b-aaaf-4e66-9ab2-e03f49882cf4	time_entry.bulk_approved	time_entry	11111111-1111-4111-8111-111111111111	{"count": 0, "requestedCount": 1}	127.0.0.1	2026-05-22 17:16:15.612
e90f2c77-3533-4aff-b5e8-4f141eda47ee	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.conversation.created	chatConversation	4c066c9a-7f3a-4e6c-a15e-298cb998d3ba	{}	2603:6081:2e06:a730:20b8:6af5:29c5:f91a	2026-05-23 17:50:36.957
735329c5-a79f-474e-8595-86a6a45d5ecd	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.message.sent	chatMessage	9a63bdfb-b752-4bd3-94cc-04fced86de27	{"backend": "claude-cli", "toolCallCount": 0, "conversationId": "4c066c9a-7f3a-4e6c-a15e-298cb998d3ba"}	2603:6081:2e06:a730:20b8:6af5:29c5:f91a	2026-05-23 17:51:01.659
70347864-df95-4042-ac7b-9b7d98d8289e	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.conversation.deleted	chatConversation	4c066c9a-7f3a-4e6c-a15e-298cb998d3ba	{}	2603:6081:2e06:a730:20b8:6af5:29c5:f91a	2026-05-23 17:51:07.548
3e0d8862-47ee-411e-be9b-72128b1428d6	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	invitation.created	invitation	54295b10-ee3f-461d-bee4-afa54ce7c423	{"role": "MEMBER", "email": "audit-test@example.com", "emailSent": "false", "emailError": "Request had insufficient authentication scopes."}	::1	2026-05-25 23:34:43.973
f1ca0d43-3943-46a0-a5ae-41a7c9e1d2b9	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	invitation.created	invitation	476cff0c-5ba6-442c-a61e-a12c49336831	{"role": "VIEWER", "email": "audit-test@example.com", "emailSent": "false", "emailError": "Request had insufficient authentication scopes."}	::1	2026-05-25 23:34:54.288
2bb26d6c-cba5-4430-846d-cc6b6ade1ef5	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	note.created	note	247d9b02-bbe7-4bff-89f2-6bcce6af945d	{"title": "", "visibility": "PRIVATE"}	::1	2026-05-26 04:17:51.904
0c328d63-1d6d-4854-9cce-ec830b24003e	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	invitation.created	invitation	183f59a4-0aa1-49bb-b0a0-2ad371e0e496	{"role": "MEMBER", "email": "steve@fightingsmartcyber.com", "emailSent": "true"}	100.16.246.187	2026-05-26 19:16:12.299
53fae36f-2570-47e8-8e57-c0b0a4e68ce6	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	invitation.created	invitation	1a3c85a9-57cd-446e-b77f-2c719183a88a	{"role": "MEMBER", "email": "validation-test+2026@fightingsmartcyber.com", "emailSent": "true"}	100.16.246.187	2026-05-26 19:37:02.924
6a4fd939-aabd-405c-b907-645e2b63efb0	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	project.created	project	32fedd19-56fd-4836-9cbe-c6b4db05dd98	{"key": "VALIDA", "name": "Validation Software Demo"}	100.16.246.187	2026-05-26 19:40:17.812
e2c08510-9290-400e-8940-2f3ec2d33e36	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	project_template.cloned	project_template	ea852f22-7b5d-40e0-8936-83f9704ca3e6	{"name": "My Software Clone", "sourceTemplateId": "fc14e4a3-943f-479e-bce2-02978f290b5c", "sourceTemplateName": "Software Project"}	100.16.246.187	2026-05-26 19:43:16.713
20f7977a-16ca-449e-89ee-6960c1cdb8ff	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	note.created	note	47b7a435-eaa8-4235-ab69-f62fb5ba9209	{"title": "Validation suite note", "visibility": "PRIVATE"}	100.16.246.187	2026-05-26 19:44:52.994
50829b64-f1c6-4ca5-8bfa-7f6c5d953276	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	project.created	project	e43c464c-5785-4b90-9f17-af71d5458b7f	{"key": "SCRATC", "name": "Scratch v2"}	100.16.246.187	2026-05-27 01:11:09.154
298c51ab-d57c-4132-ab93-719d184d1692	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	project.created	project	dc9d2b44-1d8e-462f-8c9a-48990aa8fdbe	{"key": "AECVAL", "name": "AEC Validation"}	100.16.246.187	2026-05-27 01:12:50.399
5f9374d1-03a8-48fe-8ca5-5595da639204	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	project.created	project	fc2e08fc-8453-4177-bd45-e43fc7300945	{"key": "DIRECT", "name": "Direct API Test"}	100.16.246.187	2026-05-27 01:13:58.283
4ce78196-3942-403e-8b9f-30937fac2f17	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	project.created	project	4f7a8cab-4149-45e1-9578-30917fa7464c	{"key": "SCRATC", "name": "Scratch Retest"}	100.16.246.187	2026-05-27 01:34:32.46
0928bbc5-2e24-466e-ad77-a8b6758bf12c	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	project.created	project	20228e4c-ade8-485e-bc82-24c1b3be2958	{"key": "TEMPLA", "name": "Template Retest"}	100.16.246.187	2026-05-27 01:35:54.484
ac0370c9-183a-4be4-860a-cc5cf94e4c31	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	project.deleted	project	20228e4c-ade8-485e-bc82-24c1b3be2958	{"key": "TEMPLA", "name": "Template Retest"}	100.16.246.187	2026-05-27 01:41:09.145
b6defc4a-89b4-40c1-8b91-ca5358a98f75	5311b52b-ae85-4f92-95e9-ed9bb7b91b1f	8ec2805b-aaaf-4e66-9ab2-e03f49882cf4	project.created	project	b4f088da-772e-458b-8265-c1882aca2247	{"key": "DBGTS", "name": "Debug Test"}	::1	2026-05-27 01:47:26.938
2f75a4c2-1a5c-4808-a218-d78b230e59fb	5311b52b-ae85-4f92-95e9-ed9bb7b91b1f	8ec2805b-aaaf-4e66-9ab2-e03f49882cf4	project.created	project	701c52f0-bfd5-4d94-a24e-464e9abc5d21	{"key": "FIXVR", "name": "Fix Verify"}	::1	2026-05-27 01:48:13.593
78559f58-5114-4155-84c4-43049f450fa3	5311b52b-ae85-4f92-95e9-ed9bb7b91b1f	8ec2805b-aaaf-4e66-9ab2-e03f49882cf4	project.created	project	a9f94211-8fbd-42f5-aa64-65c168d81766	{"key": "TPLVR", "name": "Template Verify"}	::1	2026-05-27 01:48:30.844
812e62a5-2845-477d-8c31-dee5f0da6c6d	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	project.created	project	fe94ac13-3bea-4563-a511-b83227ae5e9d	{"key": "SCRATC", "name": "Scratch R4"}	151.196.127.157	2026-05-27 14:38:33.403
2c7787bd-84a7-46f3-8e1b-ae087bf416db	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	work_item.created	work_item	4306a669-1f27-4acf-83e1-33224b43db64	{"title": "First real work item", "ticketNumber": "1", "workItemTypeId": "a8ff2b31-4993-4421-938e-4b5acd36e98a"}	151.196.127.157	2026-05-27 14:39:14.256
1cf8ff9e-78b0-4511-b3b8-6f1d559c9b4d	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	project.created	project	8927a771-1411-417d-9187-a8df28c7dbf9	{"key": "TEMPLA", "name": "Template R4"}	151.196.127.157	2026-05-27 14:40:59.857
be26d8dc-1f7c-4a9a-96fa-84ecb5a5ce92	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	work_item.updated	work_item	4306a669-1f27-4acf-83e1-33224b43db64	{"changes": "columnKey, sortOrder"}	151.196.127.157	2026-05-27 14:56:52.696
dc3f5f92-9f80-49ab-9e88-07bff14e47f7	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	work_item.updated	work_item	4306a669-1f27-4acf-83e1-33224b43db64	{"changes": "columnKey, sortOrder"}	151.196.127.157	2026-05-27 14:56:53.729
32e731fc-9beb-4be0-8836-ff16c3713e7b	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	work_item.updated	work_item	4306a669-1f27-4acf-83e1-33224b43db64	{"changes": "columnKey, sortOrder"}	151.196.127.157	2026-05-27 14:56:55.217
f8cb77cd-459e-4262-9108-f661671424c7	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	work_item.created	work_item	08b55683-8e4f-4599-9076-9cbc7ca35fef	{"title": "test", "ticketNumber": "1", "workItemTypeId": "a8ff2b31-4993-4421-938e-4b5acd36e98a"}	151.196.127.157	2026-05-27 20:01:16.968
0b6d206e-b7df-425b-aa0e-83bd49afd98e	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	note.created	note	249926b0-15c6-4f8e-b0de-7a5b7c362432	{"title": "Validation Sweep Note", "visibility": "PRIVATE"}	151.196.127.157	2026-05-27 20:12:03.498
400e83a6-ce4b-40db-8b5a-4aeec1054c2b	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	note.deleted	note	249926b0-15c6-4f8e-b0de-7a5b7c362432	{"title": "Validation Sweep Note"}	151.196.127.157	2026-05-27 20:12:53.904
55d841f6-eecd-454a-9f92-2af3e344e6b4	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	crm_contact.created	crm_contact	64985071-a124-4118-bf0c-30c4adfbd817	{"name": "Test Lead R5"}	151.196.127.157	2026-05-27 20:13:41.179
40eee73c-164a-4605-b929-587a34aaa7ff	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	board.created	board	f2f5b643-436f-4645-bf94-bc32d196d820	{"name": "Table View", "type": "TABLE"}	151.196.127.157	2026-05-27 20:17:23.374
8b59c1a4-a9ad-4cc7-b820-6a6ee70e216e	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	board.created	board	f403834d-47db-4f53-8c6c-911ae5582423	{"name": "Kanban Board", "type": "KANBAN"}	151.196.127.157	2026-05-27 20:17:47.175
120cab80-b6b7-4a52-b5af-c1eed00f9ff4	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	board.updated	board	abc4caf9-4d6a-4c88-a02f-8d98386b81e0	{"changes": "name, config"}	151.196.127.157	2026-05-27 20:19:19.933
e0bbbb0d-1623-4562-8569-b4ad79f61929	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	project_template.cloned	project_template	a3524442-57c4-48ef-98ec-cb2e08698512	{"name": "R5 Clone", "sourceTemplateId": "fc14e4a3-943f-479e-bce2-02978f290b5c", "sourceTemplateName": "Software Project"}	151.196.127.157	2026-05-27 20:20:18.424
c789078f-191e-4867-82c0-d6df392af2e3	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	webhook.created	webhook	e7aa5402-9198-4df3-8a25-76803130f09d	{"url": "https://webhook.example.com/cosmos"}	151.196.127.157	2026-05-27 20:23:17.897
a065b2f3-9fa9-471f-9999-1d86c616428b	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.conversation.created	chatConversation	a67e4d27-1cd7-4805-8400-765a09e14e90	{}	151.196.127.157	2026-05-27 20:26:40.603
c6f8aeaa-2cf4-4d28-bfa7-dacf8f667afa	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.message.sent	chatMessage	7bf749e0-9e94-4fe1-a3b0-415b125cdb7c	{"backend": "claude-cli", "toolCallCount": 0, "conversationId": "a67e4d27-1cd7-4805-8400-765a09e14e90"}	151.196.127.157	2026-05-27 20:27:12.217
4d778ce0-dc0a-432e-b27f-5582da3193c7	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	meeting.created	sync_meeting	a475fd96-ff3e-4411-b83d-8dcce2178a3b	{"meetingType": "STANDUP", "attendeeCount": "0"}	151.196.127.157	2026-05-28 00:31:37.049
913e00b4-0673-49cb-b6ce-43ab5afc21af	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	time_entry.created	time_entry	157bfb9b-c0b5-4e7a-a220-a1866597034b	{"date": "2026-05-27", "hours": "1.5"}	151.196.127.157	2026-05-28 00:31:37.107
6bf154ac-a5cf-41ad-9128-713cd708d2f8	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	revenue.created	revenue	01a51e4e-caba-4480-a2a5-8a7b27f260d0	{"type": "ONE_TIME", "amount": "500"}	151.196.127.157	2026-05-28 00:31:37.165
2dfd800b-6e7f-406d-ae26-876fcfd038a6	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	custom_field.created	custom_field	822ef6d4-54dc-4c7a-ab3b-495a7890f180	{"key": "department", "name": "Department", "fieldType": "TEXT"}	151.196.127.157	2026-05-28 00:32:07.679
505dd828-70b4-4cc8-ba15-3436eeaeae88	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	board.created	board	17c7cfac-e553-433a-87de-a4a18bbf0c2c	{"name": "Roadmap", "type": "ROADMAP"}	151.196.127.157	2026-05-28 00:32:59.51
c525daea-94e0-420e-8b2b-69d4730ad834	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	work_item.updated	work_item	4306a669-1f27-4acf-83e1-33224b43db64	{"changes": "columnKey"}	151.196.127.157	2026-05-28 00:33:43.239
3a9513cc-9097-4186-864d-914c48aa4db4	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	project_template.deleted	project_template	a3524442-57c4-48ef-98ec-cb2e08698512	{"name": "R5 Clone"}	151.196.127.157	2026-05-28 00:35:14.674
aad9ae79-2305-41b5-b611-de41d3b26f0e	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	note.created	note	cd6c1a5c-5cee-4b96-b084-fab74648ae24	{"title": "R7 throwaway", "visibility": "PRIVATE"}	151.196.127.157	2026-05-28 01:43:29.131
80d312c6-d3d6-4628-b067-ced35ce21006	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	preferences.updated	user_preferences	cb6fc1da-3f34-42fe-b8ad-f563cee5f620	{}	151.196.127.157	2026-05-28 02:34:37.374
91bf24a6-2167-4d27-b24d-30a13fa16828	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	preferences.updated	user_preferences	cb6fc1da-3f34-42fe-b8ad-f563cee5f620	{}	151.196.127.157	2026-05-28 02:34:46.301
34e180f6-f93d-4165-8497-fb2fc9b8d43f	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	preferences.updated	user_preferences	cb6fc1da-3f34-42fe-b8ad-f563cee5f620	{}	151.196.127.157	2026-05-28 02:35:44.849
736d0338-e930-49e5-b62e-7f9098465c13	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	preferences.updated	user_preferences	cb6fc1da-3f34-42fe-b8ad-f563cee5f620	{}	151.196.127.157	2026-05-28 02:35:47.448
3475ea8b-0c7a-4b38-be4e-01ebefeaf2fd	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	preferences.updated	user_preferences	cb6fc1da-3f34-42fe-b8ad-f563cee5f620	{}	151.196.127.157	2026-05-28 02:48:43.02
5f52c055-749b-4d93-96cd-7af9d815979a	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	preferences.updated	user_preferences	cb6fc1da-3f34-42fe-b8ad-f563cee5f620	{}	151.196.127.157	2026-05-28 02:48:48.431
e6c8f4f7-1972-421d-898c-1b0985c66031	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	preferences.updated	user_preferences	cb6fc1da-3f34-42fe-b8ad-f563cee5f620	{}	151.196.127.157	2026-05-28 03:02:27.051
025f7138-0ad5-4c1a-9634-fb6d8e766583	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	preferences.updated	user_preferences	cb6fc1da-3f34-42fe-b8ad-f563cee5f620	{}	151.196.127.157	2026-05-28 03:03:04.79
401550e4-9dfc-499f-85be-949b0a8fafa3	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	preferences.updated	user_preferences	cb6fc1da-3f34-42fe-b8ad-f563cee5f620	{}	151.196.127.157	2026-05-28 03:03:04.852
42323b4f-85cd-4776-90f5-fd0b2024248b	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	preferences.updated	user_preferences	cb6fc1da-3f34-42fe-b8ad-f563cee5f620	{}	151.196.127.157	2026-05-28 03:03:04.905
9b27f46a-1730-440a-ab96-9acdc35aa1b8	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	preferences.updated	user_preferences	cb6fc1da-3f34-42fe-b8ad-f563cee5f620	{}	151.196.127.157	2026-05-28 03:03:04.955
13311af8-42bf-4189-8e6d-015f1a61dfd5	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	preferences.updated	user_preferences	cb6fc1da-3f34-42fe-b8ad-f563cee5f620	{}	151.196.127.157	2026-05-28 03:03:05.073
7018a691-c67c-4ddb-935c-4705dff7026f	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	ip_allowlist.created	ip_allowlist	c778efbc-5386-4a4c-acbe-8d2ac5d4d0a3	{"cidr": "192.168.1.1"}	151.196.127.157	2026-05-28 03:03:55.697
d5c5fc29-3b43-4629-83bc-ec5591161e49	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	ip_allowlist.created	ip_allowlist	63783317-7c12-4ae7-ab80-8c80dfce8fd3	{"cidr": "10.0.0.0/8"}	151.196.127.157	2026-05-28 03:03:55.764
2c9f55a3-087c-4aca-816f-606c7f9f9508	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	scim_token.created	scim_token	90ef823c-f2d7-4cc8-adab-592e06191985	{"prefix": "98c3ed39"}	151.196.127.157	2026-05-28 03:03:55.825
ff49a872-f897-4438-bdbe-520953af27d9	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	theme.created	theme	ba759234-897e-4669-80c1-bc901a44a68d	{"name": "R8 Test Theme", "slug": "r8-test"}	151.196.127.157	2026-05-28 03:04:18.04
48718e59-2667-4f0c-bded-7c92167f120f	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	compliance_control.created	compliance_control	5bdf9b38-c052-40ab-98c6-2a028c6229c4	{"controlId": "AC-1", "framework": "NIST_800_53"}	151.196.127.157	2026-05-28 03:04:18.108
ccd09b9f-3d2a-4300-84e6-f1529941889f	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	data_classification.upserted	data_classification	3d7719d4-3859-448b-a717-177d1c4ef28b	{"level": "CONFIDENTIAL", "projectId": "org-level"}	151.196.127.157	2026-05-28 03:04:18.165
c1be5e48-1de5-400e-acec-6e8f68bcacd2	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	custom_field.created	custom_field	37a1393d-76aa-4a74-a734-7d3dc603de8d	{"key": "r8_number", "name": "R8 NUMBER", "fieldType": "NUMBER"}	151.196.127.157	2026-05-28 03:04:34.781
5c2b6815-bc99-4e41-8ea3-fd56f285d3d8	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	custom_field.created	custom_field	f6b4a73e-d498-461b-88a2-702daac248d7	{"key": "r8_date", "name": "R8 DATE", "fieldType": "DATE"}	151.196.127.157	2026-05-28 03:04:34.844
d54db026-aa9d-451c-a0f8-50ed03b52e28	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	custom_field.created	custom_field	c2e467a5-5c2a-4172-9df2-38678fd6dafe	{"key": "r8_select", "name": "R8 SELECT", "fieldType": "SELECT"}	151.196.127.157	2026-05-28 03:04:34.907
473c2a6a-2fa9-4996-af1f-21a8d9f9e73b	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	custom_field.created	custom_field	2648f8a4-f511-4757-8620-a2def4b90280	{"key": "r8_multi_select", "name": "R8 MULTI_SELECT", "fieldType": "MULTI_SELECT"}	151.196.127.157	2026-05-28 03:04:34.974
e2329b60-f909-4df9-be66-21575846dae5	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	custom_field.created	custom_field	240da795-9315-447f-83e5-499ee85b7476	{"key": "r8_checkbox", "name": "R8 CHECKBOX", "fieldType": "CHECKBOX"}	151.196.127.157	2026-05-28 03:04:35.041
94c34dc3-373d-4ad6-b48f-d8d637d10a85	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	custom_field.created	custom_field	0a9c7d37-49e9-4313-a91c-250d7bcb800a	{"key": "r8_url", "name": "R8 URL", "fieldType": "URL"}	151.196.127.157	2026-05-28 03:04:35.109
e98ec3c9-e456-4db7-bf1f-e91e38033f7f	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	custom_field.created	custom_field	df35013b-f15c-4e6e-a1a2-47c58da137bd	{"key": "r8_email", "name": "R8 EMAIL", "fieldType": "EMAIL"}	151.196.127.157	2026-05-28 03:04:35.17
ace75c69-83b4-4f97-ba62-36a7c5b01aa2	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	custom_field.created	custom_field	09514f55-7ad1-4437-9bbb-7b81985d7a75	{"key": "r8_user", "name": "R8 USER", "fieldType": "USER"}	151.196.127.157	2026-05-28 03:04:35.24
6236c6e4-01d6-429b-b1a3-c3a907606595	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	custom_field.created	custom_field	e3929f82-761a-410b-a3b5-58178ded80da	{"key": "department", "name": "Dupe", "fieldType": "TEXT"}	151.196.127.157	2026-05-28 03:04:35.309
81270e95-9847-4374-a101-a8a7ed005ea1	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	webhook.created	webhook	bc3dccd0-5428-4a12-ba6d-7a20642ee284	{"url": "http://localhost/x"}	151.196.127.157	2026-05-28 03:04:54.464
6fdbae3a-9e6e-4229-9597-d4817f96b724	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	webhook.created	webhook	8f23b311-2ea7-4156-8c2d-f1532f8ca813	{"url": "file:///etc/passwd"}	151.196.127.157	2026-05-28 03:04:54.523
2b73c0fa-3a70-4497-b6f7-3fb5e3cf4039	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	webhook.created	webhook	a1215497-4b34-4c7b-aa8d-0824a112bc14	{"url": "https://example.com/r8"}	151.196.127.157	2026-05-28 03:04:54.583
47699157-650f-478d-88c4-386455e01c3e	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	webhook.tested	webhook	a1215497-4b34-4c7b-aa8d-0824a112bc14	{"status": "FAILED", "deliveryId": "5235463d-9a1f-4183-b93f-123c9d775c07"}	151.196.127.157	2026-05-28 03:05:20.429
89ef3e6e-f226-42df-b3d4-b63e14a116f3	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	theme.activated	theme	ba759234-897e-4669-80c1-bc901a44a68d	{"name": "R8 Test Theme"}	151.196.127.157	2026-05-28 03:05:20.822
92904a5b-68a8-4ad2-a0a6-aa82556c15fe	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	webhook.updated	webhook	a1215497-4b34-4c7b-aa8d-0824a112bc14	{"url": "https://example.com/r8"}	151.196.127.157	2026-05-28 03:05:50.422
7ec4ffda-5580-430d-b524-af6f52fc3202	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	theme.updated	theme	ba759234-897e-4669-80c1-bc901a44a68d	{"name": "R8 Edited"}	151.196.127.157	2026-05-28 03:06:08.65
a6c603e5-7bd4-4c32-a1d0-9e22d239c6a5	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	data_classification.updated	data_classification	3d7719d4-3859-448b-a717-177d1c4ef28b	{"changes": "level, handlingInstructions"}	151.196.127.157	2026-05-28 03:06:08.793
e20dd2d6-41e5-4bae-ab85-e30abc21c92a	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	theme.deleted	theme	ba759234-897e-4669-80c1-bc901a44a68d	{"name": "R8 Edited"}	151.196.127.157	2026-05-28 03:06:08.863
77086d42-382b-4975-806f-a401480c3d75	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	compliance_control.deleted	compliance_control	5bdf9b38-c052-40ab-98c6-2a028c6229c4	{"controlId": "AC-1", "framework": "NIST_800_53"}	151.196.127.157	2026-05-28 03:06:08.923
339da826-e0da-4491-b4e0-105e48c4212e	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	data_classification.deleted	data_classification	3d7719d4-3859-448b-a717-177d1c4ef28b	{"level": "CONFIDENTIAL"}	151.196.127.157	2026-05-28 03:06:08.979
5390ec46-17eb-4a1b-978f-39e41ae74929	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	custom_field.deleted	custom_field	37a1393d-76aa-4a74-a734-7d3dc603de8d	{"key": "r8_number", "name": "R8 NUMBER"}	151.196.127.157	2026-05-28 03:07:07.022
210784d0-d3b4-4d7e-9f04-3e135bed8f4a	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	custom_field.deleted	custom_field	f6b4a73e-d498-461b-88a2-702daac248d7	{"key": "r8_date", "name": "R8 DATE"}	151.196.127.157	2026-05-28 03:07:07.082
be138dd6-176a-4e31-a947-aea99b07dd97	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	custom_field.deleted	custom_field	c2e467a5-5c2a-4172-9df2-38678fd6dafe	{"key": "r8_select", "name": "R8 SELECT"}	151.196.127.157	2026-05-28 03:07:07.136
a68f0e52-f1e8-4c45-93f0-4863af796960	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	custom_field.deleted	custom_field	2648f8a4-f511-4757-8620-a2def4b90280	{"key": "r8_multi_select", "name": "R8 MULTI_SELECT"}	151.196.127.157	2026-05-28 03:07:07.191
8bc4ac0b-8dab-4e57-a28c-09cf19354821	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	custom_field.deleted	custom_field	240da795-9315-447f-83e5-499ee85b7476	{"key": "r8_checkbox", "name": "R8 CHECKBOX"}	151.196.127.157	2026-05-28 03:07:07.246
b40ae2a1-bd59-4e5e-a792-489c48aa2b6f	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	custom_field.deleted	custom_field	0a9c7d37-49e9-4313-a91c-250d7bcb800a	{"key": "r8_url", "name": "R8 URL"}	151.196.127.157	2026-05-28 03:07:07.309
d9e80553-dc38-4220-8b49-5d139bfd3d4a	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	custom_field.deleted	custom_field	df35013b-f15c-4e6e-a1a2-47c58da137bd	{"key": "r8_email", "name": "R8 EMAIL"}	151.196.127.157	2026-05-28 03:07:07.364
75fcc160-ab5a-4333-8052-efbf5b1f3dff	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	custom_field.deleted	custom_field	09514f55-7ad1-4437-9bbb-7b81985d7a75	{"key": "r8_user", "name": "R8 USER"}	151.196.127.157	2026-05-28 03:07:07.421
52ad4513-f46d-47e3-b3e1-6b4931eb8fc9	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	custom_field.deleted	custom_field	e3929f82-761a-410b-a3b5-58178ded80da	{"key": "department", "name": "Dupe"}	151.196.127.157	2026-05-28 03:07:07.473
96b9e664-5090-4e87-bf37-1b46025e9809	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	webhook.deleted	webhook	a1215497-4b34-4c7b-aa8d-0824a112bc14	{"url": "https://example.com/r8"}	151.196.127.157	2026-05-28 03:07:07.579
483fb71c-65d0-49a7-9bd2-ef7869118b96	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	webhook.deleted	webhook	8f23b311-2ea7-4156-8c2d-f1532f8ca813	{"url": "file:///etc/passwd"}	151.196.127.157	2026-05-28 03:07:07.628
a57a1511-4c1c-4c99-83d5-726aab9dd8a2	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	webhook.deleted	webhook	bc3dccd0-5428-4a12-ba6d-7a20642ee284	{"url": "http://localhost/x"}	151.196.127.157	2026-05-28 03:07:07.686
c70cdf95-5432-4d5f-97cf-bee5dd9a2938	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	ip_allowlist.deleted	ip_allowlist	63783317-7c12-4ae7-ab80-8c80dfce8fd3	{"cidr": "10.0.0.0/8"}	151.196.127.157	2026-05-28 03:07:07.798
a27a966a-fb73-431a-80e6-62359bf0ed51	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	ip_allowlist.deleted	ip_allowlist	c778efbc-5386-4a4c-acbe-8d2ac5d4d0a3	{"cidr": "192.168.1.1"}	151.196.127.157	2026-05-28 03:07:07.856
6abb0bbe-5dbb-4dc6-8c90-474f805e99cc	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	scim_token.deleted	scim_token	90ef823c-f2d7-4cc8-adab-592e06191985	{"prefix": "98c3ed39"}	151.196.127.157	2026-05-28 03:07:07.975
6b174bbb-9d9e-4448-8c20-76fd5db201cd	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	preferences.updated	user_preferences	cb6fc1da-3f34-42fe-b8ad-f563cee5f620	{}	151.196.127.157	2026-05-28 03:23:26.293
2e005c4b-e325-4411-8717-057a1b72c143	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	preferences.updated	user_preferences	cb6fc1da-3f34-42fe-b8ad-f563cee5f620	{}	151.196.127.157	2026-05-28 03:23:53.522
16be5461-d8a8-4f18-89a6-7700bd098262	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	custom_field.created	custom_field	78373bb8-a176-49a9-b02b-b295889e380b	{"key": "r9_priority", "name": "R9 Priority", "fieldType": "TEXT"}	151.196.127.157	2026-05-28 03:24:48.204
21dc1595-7c8f-4f76-adc4-fc6bea168626	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	custom_field.deleted	custom_field	78373bb8-a176-49a9-b02b-b295889e380b	{"key": "r9_priority", "name": "R9 Priority"}	151.196.127.157	2026-05-28 03:25:47.992
38ce5b44-0e64-44f2-8cc2-9bfc3888a544	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	webhook.created	webhook	fb1b9b9b-b9e0-4cf0-a5c6-3ef85e503414	{"url": "https://example.com/r9"}	151.196.127.157	2026-05-28 03:27:46.455
46e555e2-58ea-4021-ba96-591bf9255b0b	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	webhook.tested	webhook	fb1b9b9b-b9e0-4cf0-a5c6-3ef85e503414	{"status": "FAILED", "deliveryId": "a7685f4c-9e28-4dab-b88a-1b904e963bd3"}	151.196.127.157	2026-05-28 03:28:49.244
30433776-caf3-49d2-8815-59f07b75701c	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	webhook.updated	webhook	fb1b9b9b-b9e0-4cf0-a5c6-3ef85e503414	{"url": "https://example.com/r9"}	151.196.127.157	2026-05-28 03:29:21.83
40a905a5-b7eb-4a88-86a7-c5aeb533c3e9	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	webhook.deleted	webhook	fb1b9b9b-b9e0-4cf0-a5c6-3ef85e503414	{"url": "https://example.com/r9"}	151.196.127.157	2026-05-28 03:29:54.383
97d4ae82-1828-4158-b8e0-ad06fc591ed8	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.conversation.created	chatConversation	9a07a706-9edb-4ed9-8c56-fdb3d6cd748d	{}	151.196.127.157	2026-05-28 03:45:12.259
59e52642-b56e-4ab8-9493-42d1493204d1	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.message.sent	chatMessage	1b3dfed1-d34a-496e-89e4-6509b2a034ea	{"backend": "claude-cli", "toolCallCount": 0, "conversationId": "9a07a706-9edb-4ed9-8c56-fdb3d6cd748d"}	151.196.127.157	2026-05-28 03:45:45.857
be031431-d553-44a6-ad01-fe3de13301df	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.conversation.created	chatConversation	7e3a76d1-6b2b-4002-8773-f43b5462f931	{}	151.196.127.157	2026-05-28 04:34:55.72
6aa440ec-d7ec-4b2c-8cd6-6510ce264e7e	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.conversation.created	chatConversation	c8bbaa10-ad21-4098-b1a5-6a2b93e3bfd9	{}	151.196.127.157	2026-05-28 04:35:00.838
a2326de0-9921-4bd0-8411-a0454fc71d34	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.conversation.deleted	chatConversation	c8bbaa10-ad21-4098-b1a5-6a2b93e3bfd9	{}	151.196.127.157	2026-05-28 04:35:03.343
2dc33b36-9c02-430e-8114-4f3d76f3c5fd	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.conversation.updated	chatConversation	7e3a76d1-6b2b-4002-8773-f43b5462f931	{"changes": "archived"}	151.196.127.157	2026-05-28 04:35:07.152
be81f9d7-440f-4d8f-8e02-f0214153ba8c	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.conversation.created	chatConversation	78fc82c1-1cea-47b8-ba92-669a127022f2	{}	151.196.127.157	2026-05-28 04:35:14.158
4ffd9fdb-ae15-40ad-ac75-f870fff64ad5	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.message.sent	chatMessage	fbfbc783-05d0-4112-9d52-36409fd2cc60	{"backend": "claude-cli", "toolCallCount": 0, "conversationId": "78fc82c1-1cea-47b8-ba92-669a127022f2"}	151.196.127.157	2026-05-28 04:35:30.063
60fac5a8-bc25-478a-94e2-c268cce24ceb	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.conversation.created	chatConversation	9c784f13-ba13-4cff-a30a-26dd959b9de2	{}	151.196.127.157	2026-05-28 13:41:17.87
e2e96fc6-e9cc-489d-b4de-88f206e3c8eb	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.message.sent	chatMessage	19e1cf26-3b67-4260-b4d9-eb42d5c8ced5	{"pool": "one-shot", "backend": "claude-cli", "toolCallCount": 0, "conversationId": "9c784f13-ba13-4cff-a30a-26dd959b9de2"}	151.196.127.157	2026-05-28 13:43:28.292
277a969b-f419-4303-8b88-c94ae2dd9505	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.conversation.created	assistantConversation	1e70ec05-0dcd-4275-8a25-3669ad238b9c	{}	151.196.127.157	2026-05-28 14:17:01.058
b3380032-e06d-4f0c-ae8b-b0edfa4549e5	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.conversation.deleted	assistantConversation	1e70ec05-0dcd-4275-8a25-3669ad238b9c	{}	151.196.127.157	2026-05-28 14:17:02.667
070b01d9-3f3d-43dc-a8cf-118bb07f85b8	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.conversation.deleted	assistantConversation	9c784f13-ba13-4cff-a30a-26dd959b9de2	{}	151.196.127.157	2026-05-28 14:17:04.969
1944a931-b9cd-4cbd-ae4b-9ac937dcfd4b	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.conversation.created	assistantConversation	4f6d9aea-9e1a-4eea-988c-f06f1b6f823b	{}	151.196.127.157	2026-05-28 17:51:07.196
b7c42e06-3a10-448d-9b17-df888fc6bf9c	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	mcp_server.created	mcpServer	ecad1a33-d44f-4e41-b0df-f72f4d1245bf	{"name": "R10 Test stdio", "transport": "stdio"}	151.196.127.157	2026-05-28 17:55:18.126
70970908-b174-49f1-9c9a-f19639e6d4e0	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	mcp_server.updated	mcpServer	ecad1a33-d44f-4e41-b0df-f72f4d1245bf	{"name": "R10 Test stdio"}	151.196.127.157	2026-05-28 17:55:39.874
8a3f834e-e650-4e62-aff5-d808f041df4e	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	mcp_server.updated	mcpServer	ecad1a33-d44f-4e41-b0df-f72f4d1245bf	{"name": "R10 Renamed"}	151.196.127.157	2026-05-28 17:56:17.36
efb1b692-051a-4d68-94e1-b581d71decc2	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	mcp_server.created	mcpServer	1d3b6ad6-4b5d-4f95-899c-7f1d295c3e05	{"name": "R10 HTTP", "transport": "http"}	151.196.127.157	2026-05-28 17:57:32.791
5f96d9b1-5345-443c-9fe4-9b4fdccb15e3	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	mcp_server.deleted	mcpServer	1d3b6ad6-4b5d-4f95-899c-7f1d295c3e05	{"name": "R10 HTTP"}	151.196.127.157	2026-05-28 17:57:52.219
8a37a2fd-dbbc-4098-9d79-4270c4c808c3	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	mcp_server.deleted	mcpServer	ecad1a33-d44f-4e41-b0df-f72f4d1245bf	{"name": "R10 Renamed"}	151.196.127.157	2026-05-28 17:57:52.286
b475c15b-52b2-4cac-a2fc-adc437d8c1be	0a086635-a2f4-47d1-a160-7437402b5973	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	chat.channel.created	chat_channel	f3387ed3-eef3-4543-a2b1-3c9d84c6d704	{"name": "smoke-u4cui", "slug": "smoke-u4cui"}	\N	2026-05-28 18:36:54.758
7342cb93-541a-450c-87d7-728af16ce758	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	preferences.updated	user_preferences	cb6fc1da-3f34-42fe-b8ad-f563cee5f620	{}	151.196.127.157	2026-05-30 03:37:11.164
b112c3c8-00b8-4670-8ea2-a00014096438	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.conversation.created	assistantConversation	de9710e7-8e48-411d-965f-f16417894e8c	{}	151.196.127.157	2026-05-30 03:37:30.57
3cf4322b-9e8b-4a0c-be98-0d9f71bcccb6	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.conversation.created	assistantConversation	0b5ea941-938b-45ff-b5f9-b29ea8857bc5	{}	151.196.127.157	2026-05-30 03:37:52.677
06651274-3f36-4ff3-8960-f1abbe8dd7f6	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.conversation.deleted	assistantConversation	0b5ea941-938b-45ff-b5f9-b29ea8857bc5	{}	151.196.127.157	2026-05-30 03:37:54.548
5cea09b1-eccd-4dc9-8bee-617b8a4d65c0	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	project.created	project	d816eefb-9664-4e3e-ba50-f4fbb255d61d	{"key": "R11", "name": "R11 UI Audit"}	151.196.127.157	2026-05-30 21:04:37.665
c493ce65-b79e-4b2a-baff-e71d4a15efd5	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	work_item.created	work_item	cf9cd7f6-67ec-445c-9dc8-3cf149094c8c	{"title": "Audit work item", "ticketNumber": "1", "workItemTypeId": "a8ff2b31-4993-4421-938e-4b5acd36e98a"}	151.196.127.157	2026-05-30 21:05:54.541
6149c337-fd16-437a-aeb8-f94a29cb2dfc	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.conversation.created	assistantConversation	94a27c05-cd26-413d-af73-fa32867afe74	{}	::1	2026-05-31 03:19:34.309
e1b6cedd-6cfa-439d-ba6d-639c7fc95fff	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	crm_contact.created	crm_contact	edde104b-37d0-45ee-8015-3258743d4eab	{"name": "R18VERIFY-lower"}	::1	2026-05-31 15:24:41.477
e6664d71-327a-4b98-b7e8-d7e826e558fb	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	crm_contact.created	crm_contact	9af4fc60-38b9-4251-b118-dc7f5d5a1834	{"name": "R18VERIFY-none"}	::1	2026-05-31 15:24:41.541
451e4254-4538-4062-85d2-3517a1a36b06	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	work_item.updated	work_item	cf9cd7f6-67ec-445c-9dc8-3cf149094c8c	{"changes": "columnKey, sortOrder"}	151.196.127.157	2026-06-02 23:46:46.281
a86ce0c2-8642-4d45-b9ff-791cc89a676e	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	work_item.updated	work_item	cf9cd7f6-67ec-445c-9dc8-3cf149094c8c	{"changes": "columnKey, sortOrder"}	151.196.127.157	2026-06-02 23:46:47.723
a57bbe3c-ee9d-425e-9518-b76b5032f18b	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	work_item.updated	work_item	cf9cd7f6-67ec-445c-9dc8-3cf149094c8c	{"changes": "columnKey, sortOrder"}	151.196.127.157	2026-06-02 23:46:49.014
8296325b-df2a-4c4a-9ae9-54a6f6ecfcd3	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	project_template.created	project_template	67ae1d4f-2c17-4e07-af56-1b68535b2397	{"name": "New Template", "sector": "tech"}	151.196.127.157	2026-06-03 01:56:25.603
695f4ad1-318b-4e51-b8d9-8f2a66079813	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	project_template.deleted	project_template	67ae1d4f-2c17-4e07-af56-1b68535b2397	{"name": "New Template"}	151.196.127.157	2026-06-03 01:56:40.317
c3ee6b62-a235-4b45-8b6e-de3b9ccc0157	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	organization.created	organization	b3b93f25-2072-4514-8820-74712a67ca64	{"plan": "GOV"}	\N	2026-05-24 02:37:49.039
71758900-e695-4931-8d15-f357521663a8	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	org_member.invited	org_member	\N	{"role": "ADMIN", "email": "dana.reyes@apex-defense.local"}	\N	2026-05-24 02:37:49.039
da89067b-8a05-4e3b-b4d8-8aae3e30b3d7	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	org_member.invited	org_member	\N	{"role": "MEMBER", "email": "priya.nair@apex-defense.local"}	\N	2026-05-25 02:37:49.039
e8ac0d61-ef5b-4472-8c7f-61849d044866	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	data_classification.upserted	data_classification	\N	{"level": "CUI", "project": "SENTINEL"}	\N	2026-05-25 02:37:49.039
a1b560b6-b90b-44eb-a58f-7684c55a7ab1	b3b93f25-2072-4514-8820-74712a67ca64	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	compliance_control.created	compliance_control	\N	{"status": "IMPLEMENTED", "controlId": "3.13.11", "framework": "NIST_800_171"}	\N	2026-05-26 02:37:49.039
145607ff-ef44-4084-bdbb-142e945a17f8	b3b93f25-2072-4514-8820-74712a67ca64	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	compliance_control.updated	compliance_control	\N	{"status": "FAILED", "controlId": "3.11.2", "framework": "NIST_800_171"}	\N	2026-05-31 02:37:49.039
7f137326-7980-4234-ab6d-da0fd0933e14	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	expense.approved	expense	\N	{"amount": 128400, "vendor": "Vector Systems LLC"}	\N	2026-05-27 02:37:49.039
4fe11cf4-186e-4749-bccd-36b055b32755	b3b93f25-2072-4514-8820-74712a67ca64	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	security_settings.updated	org_security_settings	\N	{"mfaRequired": true}	\N	2026-05-27 02:37:49.039
605e4745-3f9c-446d-b959-7b026349b5f2	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	note.updated	note	cc005334-0703-4c7f-8a7c-9a6d95dd2433	{"changes": "title, content, visibility"}	100.16.246.187	2026-06-03 12:54:49.43
d8466aff-58b2-497c-9a39-99932f6ef60b	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	note.updated	note	cc005334-0703-4c7f-8a7c-9a6d95dd2433	{"changes": "title, content, visibility"}	100.16.246.187	2026-06-03 12:54:54.427
51f41bfb-539b-410d-b633-c6d16d4d9f6e	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.conversation.created	assistantConversation	9986712c-d2e9-44f6-8a2f-dcc6f807be09	{}	100.16.246.187	2026-06-03 13:01:18.053
c48a7817-1aa6-4ba6-a92e-e256fd0ec574	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.message.sent	assistantMessage	93dd40a1-571a-42a0-9506-2fb2ee6d522a	{"pool": "one-shot", "backend": "claude-cli", "toolCallCount": 0, "conversationId": "9986712c-d2e9-44f6-8a2f-dcc6f807be09"}	100.16.246.187	2026-06-03 13:01:59.757
3591f121-32fd-41bb-acad-d307a6d5f37f	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	data_classification.upserted	data_classification	54cdfba6-6d30-4fe8-9a7d-bff644c1ff15	{"level": "CUI", "projectId": "org-level"}	100.16.246.187	2026-06-03 13:38:03.353
f5d27d04-61f2-4f53-a780-e9b8e391db0b	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	data_classification.deleted	data_classification	54cdfba6-6d30-4fe8-9a7d-bff644c1ff15	{"level": "CUI"}	100.16.246.187	2026-06-03 13:38:07.372
e9a069c5-a54f-42a0-9139-df79b557f4a4	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	data_classification.updated	data_classification	5e4429d1-dc89-4698-b836-aa581d75c3fd	{"changes": "level, markings, handlingInstructions"}	100.16.246.187	2026-06-03 14:41:58.368
006221b4-f61f-4d86-b6ff-f96af09763a7	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	chat.message.sent	assistantMessage	6d520a6a-20d0-4eb0-a5a6-8105e16fbb19	{"pool": "one-shot", "backend": "claude-cli", "toolCallCount": 0, "conversationId": "9986712c-d2e9-44f6-8a2f-dcc6f807be09"}	151.196.127.157	2026-06-05 04:15:59.113
\.


--
-- Data for Name: bank_accounts; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.bank_accounts (id, org_id, name, institution, mask, currency, provider, ledger_account_id, is_active, created_by_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bank_rules; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.bank_rules (id, org_id, name, description_contains, direction, amount_min, amount_max, category, priority, is_active, created_by_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bank_transactions; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.bank_transactions (id, org_id, bank_account_id, external_id, fingerprint, posted_date, amount, description, pending, status, matched_expense_id, category, created_at, matched_revenue_id) FROM stdin;
\.


--
-- Data for Name: board_columns; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.board_columns (id, board_id, name, key, color, wip_limit, sort_order, category) FROM stdin;
3baf72e1-ea81-4939-8b7f-820f9ac9684d	6e95b5ea-8ca6-4084-a5bb-0b538eb668e9	Backlog	backlog	#94a3b8	\N	0	TODO
56e4376e-ba44-4caf-b5cf-4bb0e341b258	6e95b5ea-8ca6-4084-a5bb-0b538eb668e9	To Do	todo	#60a5fa	\N	1	TODO
7af8ae9f-b997-4de8-bd2c-4aa327fd584d	6e95b5ea-8ca6-4084-a5bb-0b538eb668e9	In Progress	in-progress	#fbbf24	\N	2	IN_PROGRESS
00dfc280-145a-41a9-8f8c-3bcf37a9104a	6e95b5ea-8ca6-4084-a5bb-0b538eb668e9	Review	review	#a78bfa	\N	3	IN_PROGRESS
a1f37b33-ceaa-4ef6-9671-f62ce1fc874a	6e95b5ea-8ca6-4084-a5bb-0b538eb668e9	Done	done	#34d399	\N	4	DONE
59b24c41-e6de-4a17-abbb-401c1903b4dd	4efcfc43-f68e-4d1f-b8d2-5351ff5b6288	Backlog	backlog	#94a3b8	\N	0	TODO
a266b10b-732f-46d2-8e1c-2f6980b15fcc	4efcfc43-f68e-4d1f-b8d2-5351ff5b6288	To Do	todo	#60a5fa	\N	1	TODO
213a896d-81df-471e-bec8-8d2f6585634d	4efcfc43-f68e-4d1f-b8d2-5351ff5b6288	In Progress	in-progress	#fbbf24	\N	2	IN_PROGRESS
dac22396-8ffc-4685-b749-fa5647c7f610	4efcfc43-f68e-4d1f-b8d2-5351ff5b6288	Review	review	#a78bfa	\N	3	IN_PROGRESS
6ff58a64-59b5-4d51-9a44-bc23d19ce1d2	4efcfc43-f68e-4d1f-b8d2-5351ff5b6288	Done	done	#34d399	\N	4	DONE
\.


--
-- Data for Name: board_template_widgets; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.board_template_widgets (id, template_id, widget_slug, parent_widget_id, config, layout, sort_order) FROM stdin;
\.


--
-- Data for Name: board_templates; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.board_templates (id, org_id, slug, name, category, methodology, description, thumbnail_url, is_built_in, is_published, default_config, created_at, project_template_id, sector, source_template_id, board_type, sort_order) FROM stdin;
6a748c90-6330-4b4b-9218-654898d855d0	\N	consulting.closeout	Closeout Checklist	tracking	\N		\N	t	t	{"columns": [{"key": "pending", "name": "Pending", "color": "#94a3b8", "category": "TODO"}, {"key": "in-review", "name": "In Review", "color": "#fbbf24", "category": "IN_PROGRESS"}, {"key": "signed-off", "name": "Signed Off", "color": "#34d399", "category": "DONE"}]}	2026-05-26 02:58:17.493	0ee9a904-51ed-4db6-a0d3-d5fd6530ca95	consulting	\N	KANBAN	4
3f54966a-8e39-4c43-9904-89934f2a6332	\N	manufacturing.work-orders	Work-Order Kanban	tracking	\N		\N	t	t	{"columns": [{"key": "queued", "name": "Queued", "color": "#94a3b8", "category": "TODO"}, {"key": "in-setup", "name": "In Setup", "color": "#fbbf24", "category": "IN_PROGRESS"}, {"key": "running", "name": "Running", "color": "#3b82f6", "category": "IN_PROGRESS"}, {"key": "qc-hold", "name": "QC Hold", "color": "#ef4444", "category": "IN_PROGRESS"}, {"key": "complete", "name": "Complete", "color": "#34d399", "category": "DONE"}]}	2026-05-26 02:58:17.506	26ee8183-f1b9-4bc0-b8b0-4128a119769b	manufacturing	\N	KANBAN	0
bcbfd627-0797-4e51-a322-4d7bf0fdff1f	\N	manufacturing.ncr-tracker	Quality NCR Tracker	tracking	\N		\N	t	t	{}	2026-05-26 02:58:17.508	26ee8183-f1b9-4bc0-b8b0-4128a119769b	manufacturing	\N	TABLE	1
595a5720-f0d2-4aee-a953-d8a7f2445a20	\N	manufacturing.downtime	Downtime Calendar	planning	\N		\N	t	t	{}	2026-05-26 02:58:17.51	26ee8183-f1b9-4bc0-b8b0-4128a119769b	manufacturing	\N	CALENDAR	2
cec0e9c0-d533-4c00-bb04-28c4e030e27f	\N	manufacturing.bom	BOM Table	tracking	\N		\N	t	t	{}	2026-05-26 02:58:17.511	26ee8183-f1b9-4bc0-b8b0-4128a119769b	manufacturing	\N	TABLE	3
27f8fb77-9d7d-4ffc-859e-1f1cd1d7e1e1	\N	software.sprint-board	Sprint Board	agile	\N		\N	t	t	{}	2026-05-26 02:52:54.89	fc14e4a3-943f-479e-bce2-02978f290b5c	software	\N	SCRUM	0
fe4da9df-a32f-47ad-9797-a21c13dc5900	\N	software.kanban	Kanban	agile	\N		\N	t	t	{}	2026-05-26 02:52:54.9	fc14e4a3-943f-479e-bce2-02978f290b5c	software	\N	KANBAN	1
5f17729e-eb20-4db2-bcf0-c04dc312d070	\N	software.backlog	Backlog	agile	\N		\N	t	t	{}	2026-05-26 02:52:54.901	fc14e4a3-943f-479e-bce2-02978f290b5c	software	\N	BACKLOG	2
b8c3acd9-fc56-4635-90c1-ade9197647f8	\N	software.bug-tracker	Bug Tracker	tracking	\N		\N	t	t	{}	2026-05-26 02:52:54.903	fc14e4a3-943f-479e-bce2-02978f290b5c	software	\N	TABLE	3
1c740b29-f5f7-4b31-9ce8-150395267cb8	\N	software.release-timeline	Release Timeline	planning	\N		\N	t	t	{}	2026-05-26 02:52:54.905	fc14e4a3-943f-479e-bce2-02978f290b5c	software	\N	TIMELINE	4
d59b721d-131d-4bfc-b1fe-bf7b5e3a40c3	\N	software.raid	RAID Log	tracking	\N		\N	t	t	{}	2026-05-26 02:52:54.906	fc14e4a3-943f-479e-bce2-02978f290b5c	software	\N	RAID	5
e599c32d-9818-4d74-be96-0b6cfd0d8ae6	\N	software.dashboard	Sprint Dashboard	analytics	\N		\N	t	t	{}	2026-05-26 02:52:54.908	fc14e4a3-943f-479e-bce2-02978f290b5c	software	\N	DASHBOARD	6
5977f0ba-79e6-4db8-bfde-2cc50d400cfa	\N	aec.submittal-log	Submittal Log	tracking	\N		\N	t	t	{}	2026-05-26 02:58:17.446	a0fe1a00-bf03-4a1d-87b1-dbe4e816bc2a	aec	\N	TABLE	1
cc0fd329-560b-4b04-82c2-cd60d926c443	\N	aec.rfi-tracker	RFI Tracker	tracking	\N		\N	t	t	{}	2026-05-26 02:58:17.447	a0fe1a00-bf03-4a1d-87b1-dbe4e816bc2a	aec	\N	TABLE	2
2685bc72-347a-421e-b034-2a80d722bb03	\N	aec.change-orders	Change Orders	tracking	\N		\N	t	t	{}	2026-05-26 02:58:17.449	a0fe1a00-bf03-4a1d-87b1-dbe4e816bc2a	aec	\N	TABLE	3
bc5282be-503d-42d6-a446-7a368042df77	\N	aec.daily-logs	Daily Logs	tracking	\N		\N	t	t	{}	2026-05-26 02:58:17.45	a0fe1a00-bf03-4a1d-87b1-dbe4e816bc2a	aec	\N	TABLE	4
b576959e-45db-47a8-ab6d-35f7af980902	\N	aec.punch-list	Punch List	tracking	\N		\N	t	t	{"columns": [{"key": "open", "name": "Open", "color": "#ef4444", "category": "TODO"}, {"key": "in-progress", "name": "In Progress", "color": "#fbbf24", "category": "IN_PROGRESS"}, {"key": "verified", "name": "Verified", "color": "#34d399", "category": "DONE"}]}	2026-05-26 02:58:17.452	a0fe1a00-bf03-4a1d-87b1-dbe4e816bc2a	aec	\N	KANBAN	5
29d9a4b8-1112-4771-8539-94ca155b3bd1	\N	aec.safety	Safety Incidents	tracking	\N		\N	t	t	{}	2026-05-26 02:58:17.454	a0fe1a00-bf03-4a1d-87b1-dbe4e816bc2a	aec	\N	TABLE	6
e9f1124a-2462-4e5b-98b7-50360931f6ad	\N	ops.incident-board	Incident Board	tracking	\N		\N	t	t	{"columns": [{"key": "new", "name": "New", "color": "#ef4444", "category": "TODO"}, {"key": "triaged", "name": "Triaged", "color": "#f59e0b", "category": "TODO"}, {"key": "in-progress", "name": "In Progress", "color": "#3b82f6", "category": "IN_PROGRESS"}, {"key": "resolved", "name": "Resolved", "color": "#34d399", "category": "DONE"}, {"key": "closed", "name": "Closed", "color": "#64748b", "category": "DONE"}]}	2026-05-26 02:58:17.467	00dac83c-c871-4da5-a5ab-1ab2a1357bd9	ops	\N	KANBAN	0
523eeff7-8451-4fae-93c7-13ed88f9966c	\N	ops.change-queue	Change Request Queue	tracking	\N		\N	t	t	{}	2026-05-26 02:58:17.469	00dac83c-c871-4da5-a5ab-1ab2a1357bd9	ops	\N	TABLE	1
74bea02f-38f5-4284-850c-7043502c0290	\N	ops.runbooks	Runbook Checklist	tracking	\N		\N	t	t	{}	2026-05-26 02:58:17.471	00dac83c-c871-4da5-a5ab-1ab2a1357bd9	ops	\N	TABLE	2
fced0f97-0607-4ab0-9e17-03708968a6ac	\N	ops.sla-dashboard	SLA Dashboard	analytics	\N		\N	t	t	{}	2026-05-26 02:58:17.472	00dac83c-c871-4da5-a5ab-1ab2a1357bd9	ops	\N	DASHBOARD	3
d9556aaa-2b67-4430-b752-43e208853a0b	\N	ops.oncall	On-Call Rotation	planning	\N		\N	t	t	{}	2026-05-26 02:58:17.474	00dac83c-c871-4da5-a5ab-1ab2a1357bd9	ops	\N	CALENDAR	4
bafde9b7-5f54-4316-9de9-ca66d8ce3195	\N	ops.postmortems	Postmortem Tracker	tracking	\N		\N	t	t	{}	2026-05-26 02:58:17.475	00dac83c-c871-4da5-a5ab-1ab2a1357bd9	ops	\N	TABLE	5
0ee39d90-e3b2-400c-93a8-ae38196f39a2	\N	consulting.phases	Engagement Phases	planning	\N		\N	t	t	{}	2026-05-26 02:58:17.485	0ee9a904-51ed-4db6-a0d3-d5fd6530ca95	consulting	\N	TIMELINE	0
1da762ed-27f9-4c73-98cc-da7ad7cddc6b	\N	consulting.deliverables	Deliverable Tracker	tracking	\N		\N	t	t	{}	2026-05-26 02:58:17.487	0ee9a904-51ed-4db6-a0d3-d5fd6530ca95	consulting	\N	TABLE	1
83e577b1-98f0-4cdc-8cac-92e6d08fb7fc	\N	consulting.timesheet	Billable Timesheet	tracking	\N		\N	t	t	{}	2026-05-26 02:58:17.49	0ee9a904-51ed-4db6-a0d3-d5fd6530ca95	consulting	\N	TABLE	2
d32071ee-4dea-4b7d-9aaf-40e4fc29488d	\N	consulting.checkpoints	Checkpoint Calendar	planning	\N		\N	t	t	{}	2026-05-26 02:58:17.492	0ee9a904-51ed-4db6-a0d3-d5fd6530ca95	consulting	\N	CALENDAR	3
265b002d-25bf-460b-8f08-77c7a4965cb9	\N	aec.phase-gantt	Phase Gantt	planning	\N		\N	t	t	{}	2026-05-26 02:58:17.443	a0fe1a00-bf03-4a1d-87b1-dbe4e816bc2a	aec	\N	TIMELINE	0
80a2630b-9c16-49f7-8f4a-e1477ef8982c	\N	education.gradebook	Grading Board	analytics	\N		\N	t	t	{}	2026-05-26 02:58:17.53	caf35d32-77e2-4e67-a801-9bfebebe4744	education	\N	DASHBOARD	3
8ac73d31-569a-4c11-afbd-dd29b63be6eb	\N	education.curriculum	Curriculum Roadmap	planning	\N		\N	t	t	{}	2026-05-26 02:58:17.532	caf35d32-77e2-4e67-a801-9bfebebe4744	education	\N	ROADMAP	4
48032e97-5ed8-4054-87da-80969a48ce29	\N	education.conferences	Student Conferences	planning	\N		\N	t	t	{}	2026-05-26 02:58:17.533	caf35d32-77e2-4e67-a801-9bfebebe4744	education	\N	CALENDAR	5
669728c4-b756-4d3c-bdc1-ec80aed38012	\N	event.run-of-show	Run-of-Show Timeline	planning	\N		\N	t	t	{}	2026-05-26 02:58:17.548	d6b39e2d-ba22-4481-a616-7496e1e8c24a	event	\N	TIMELINE	0
f0066f6f-42d4-459d-a863-5d2e2455e084	\N	event.vendors	Vendor Tracker	tracking	\N		\N	t	t	{}	2026-05-26 02:58:17.55	d6b39e2d-ba22-4481-a616-7496e1e8c24a	event	\N	TABLE	1
bad3874e-95c2-4f99-a7e9-d102eaf605eb	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	sprint-dashboard-2	Sprint Dashboard	analytics	\N		\N	f	t	{}	2026-05-27 20:20:18.42	\N	software	e599c32d-9818-4d74-be96-0b6cfd0d8ae6	DASHBOARD	6
71eb1f27-2d7c-4f91-8972-6c409ce821b0	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	sprint-board-2	Sprint Board	agile	\N		\N	f	t	{}	2026-05-27 20:20:18.4	\N	software	27f8fb77-9d7d-4ffc-859e-1f1cd1d7e1e1	SCRUM	0
b6ffe3c1-d660-400f-929e-475e80f274bd	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	kanban-2	Kanban	agile	\N		\N	f	t	{}	2026-05-27 20:20:18.404	\N	software	fe4da9df-a32f-47ad-9797-a21c13dc5900	KANBAN	1
0e8ac7e5-74a9-4c43-add4-08619461d464	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	backlog-2	Backlog	agile	\N		\N	f	t	{}	2026-05-27 20:20:18.406	\N	software	5f17729e-eb20-4db2-bcf0-c04dc312d070	BACKLOG	2
4c7847df-21ac-49f7-97ac-57deb4cebfaf	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	bug-tracker-2	Bug Tracker	tracking	\N		\N	f	t	{}	2026-05-27 20:20:18.41	\N	software	b8c3acd9-fc56-4635-90c1-ade9197647f8	TABLE	3
a458d8a5-a5d4-43ab-b180-869ee60981df	\N	event.logistics	Logistics Checklist	tracking	\N		\N	t	t	{"columns": [{"key": "to-do", "name": "To Do", "color": "#94a3b8", "category": "TODO"}, {"key": "in-progress", "name": "In Progress", "color": "#fbbf24", "category": "IN_PROGRESS"}, {"key": "confirmed", "name": "Confirmed", "color": "#34d399", "category": "DONE"}]}	2026-05-26 02:58:17.553	d6b39e2d-ba22-4481-a616-7496e1e8c24a	event	\N	KANBAN	2
63fd6c14-4358-4992-89aa-2ec133438a12	\N	event.risk	Risk + Contingency	tracking	\N		\N	t	t	{}	2026-05-26 02:58:17.555	d6b39e2d-ba22-4481-a616-7496e1e8c24a	event	\N	RAID	3
27730ef4-1257-4157-8643-20ec448d3c65	\N	event.attendees	Attendee CRM	tracking	\N		\N	t	t	{}	2026-05-26 02:58:17.558	d6b39e2d-ba22-4481-a616-7496e1e8c24a	event	\N	TABLE	4
0c704ad3-a760-4b31-b438-c51011f551e4	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	sprint-board	Sprint Board	agile	\N		\N	f	t	{}	2026-05-26 19:43:16.699	\N	software	27f8fb77-9d7d-4ffc-859e-1f1cd1d7e1e1	SCRUM	0
0d040ae6-d01d-46af-8662-be9708066de0	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	kanban	Kanban	agile	\N		\N	f	t	{}	2026-05-26 19:43:16.701	\N	software	fe4da9df-a32f-47ad-9797-a21c13dc5900	KANBAN	1
f799e76a-1255-4106-b32a-0800a6ca0925	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	backlog	Backlog	agile	\N		\N	f	t	{}	2026-05-26 19:43:16.703	\N	software	5f17729e-eb20-4db2-bcf0-c04dc312d070	BACKLOG	2
299a0749-4008-40d9-835c-ded81bd4dfb6	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	bug-tracker	Bug Tracker	tracking	\N		\N	f	t	{}	2026-05-26 19:43:16.705	\N	software	b8c3acd9-fc56-4635-90c1-ade9197647f8	TABLE	3
0900d0a2-5163-4397-b1a4-9529f7c78bac	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	release-timeline	Release Timeline	planning	\N		\N	f	t	{}	2026-05-26 19:43:16.706	\N	software	1c740b29-f5f7-4b31-9ce8-150395267cb8	TIMELINE	4
7f6a4d3d-9b0e-4f04-b8da-216ca173cb96	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	raid-log	RAID Log	tracking	\N		\N	f	t	{}	2026-05-26 19:43:16.708	\N	software	d59b721d-131d-4bfc-b1fe-bf7b5e3a40c3	RAID	5
0de3fc9b-24f1-4c06-a452-306287e9783e	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	sprint-dashboard	Sprint Dashboard	analytics	\N		\N	f	t	{}	2026-05-26 19:43:16.71	\N	software	e599c32d-9818-4d74-be96-0b6cfd0d8ae6	DASHBOARD	6
010d484c-6705-4b47-9f22-48a79a530e8d	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	release-timeline-2	Release Timeline	planning	\N		\N	f	t	{}	2026-05-27 20:20:18.413	\N	software	1c740b29-f5f7-4b31-9ce8-150395267cb8	TIMELINE	4
f5910181-69d0-46ed-a8a1-bdd0ca7853f3	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	raid-log-2	RAID Log	tracking	\N		\N	f	t	{}	2026-05-27 20:20:18.416	\N	software	d59b721d-131d-4bfc-b1fe-bf7b5e3a40c3	RAID	5
cb7cd0bf-884c-403c-b34c-64f3f7fd060f	\N	manufacturing.inspections	Inspection Checklist	tracking	\N		\N	t	t	{}	2026-05-26 02:58:17.513	26ee8183-f1b9-4bc0-b8b0-4128a119769b	manufacturing	\N	TABLE	4
4841cd11-dea8-4b5b-b3c3-5e27ebdd50e4	\N	education.outline	Course Outline	planning	\N		\N	t	t	{}	2026-05-26 02:58:17.525	caf35d32-77e2-4e67-a801-9bfebebe4744	education	\N	TABLE	0
f4495d71-b757-475b-bbd6-a0bcb699e76e	\N	education.assignments	Assignment Tracker	tracking	\N		\N	t	t	{"columns": [{"key": "draft", "name": "Draft", "color": "#94a3b8", "category": "TODO"}, {"key": "published", "name": "Published", "color": "#3b82f6", "category": "IN_PROGRESS"}, {"key": "grading", "name": "Grading", "color": "#fbbf24", "category": "IN_PROGRESS"}, {"key": "graded", "name": "Graded", "color": "#34d399", "category": "DONE"}]}	2026-05-26 02:58:17.527	caf35d32-77e2-4e67-a801-9bfebebe4744	education	\N	KANBAN	1
4c47c065-925c-42a9-b1e2-da39c7551a1c	\N	education.calendar	Lesson Calendar	planning	\N		\N	t	t	{}	2026-05-26 02:58:17.529	caf35d32-77e2-4e67-a801-9bfebebe4744	education	\N	CALENDAR	2
\.


--
-- Data for Name: boards; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.boards (id, org_id, project_id, name, type, config, sort_order, created_at) FROM stdin;
6e95b5ea-8ca6-4084-a5bb-0b538eb668e9	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	d816eefb-9664-4e3e-ba50-f4fbb255d61d	Board	KANBAN	{}	0	2026-05-30 21:04:37.657
4efcfc43-f68e-4d1f-b8d2-5351ff5b6288	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Board	KANBAN	{}	0	2026-06-03 02:37:49.169
\.


--
-- Data for Name: chat_alert_keywords; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.chat_alert_keywords (id, user_id, keyword, created_at) FROM stdin;
\.


--
-- Data for Name: chat_bot_channels; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.chat_bot_channels (id, bot_id, channel_id, auto_respond, enabled, created_at) FROM stdin;
\.


--
-- Data for Name: chat_bot_runs; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.chat_bot_runs (id, bot_id, message_id, triggered_by_user_id, status, created_at) FROM stdin;
\.


--
-- Data for Name: chat_bots; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.chat_bots (id, org_id, key, display_name, persona, model, tool_scope, enabled_mcp, schedule_cron, user_id, created_at, updated_at) FROM stdin;
1ecec2ce-8df8-4aa8-b173-af59f9856446	b3b93f25-2072-4514-8820-74712a67ca64	assistant	Assistant	A helpful AI teammate that can query and modify project/work data using its tools and the org's connected MCP servers.	sonnet	FULL	f	\N	405c6daf-aaf3-4ef6-8af4-c5076e2106f6	2026-06-05 04:11:55.21	2026-06-05 04:11:55.21
63269234-3454-4549-8665-e4ea38f0b953	b3b93f25-2072-4514-8820-74712a67ca64	notetaker	Note-taker	Summarizes the recent conversation into Decisions and Action items, and creates work items for action items in project-linked channels.	sonnet	READONLY	f	\N	a53d65bc-a02d-4c44-a4cb-20c2c4bb03c7	2026-06-05 04:11:55.215	2026-06-05 04:11:55.215
8220fb20-8a32-4578-b8ef-d9b713287f80	b3b93f25-2072-4514-8820-74712a67ca64	answerer	Answerer	A cited-answer assistant. When a teammate asks a question it searches the org's knowledge (notes, work items, docs) and replies concisely WITH the source it used. If it has no grounded answer it stays silent rather than guessing.	sonnet	READONLY	f	\N	f662c298-69e3-4352-b6d1-66ca2a6307d4	2026-06-05 04:11:55.224	2026-06-05 04:11:55.224
32d6edae-bd22-48dc-a68c-f690ed0b6143	b3b93f25-2072-4514-8820-74712a67ca64	standup	Standup	Posts a daily standup for the channel's linked project: Yesterday / Today / Blockers plus a one-line burndown, built from the last 24h of activity and the active cycle's work items.	sonnet	READONLY	f	\N	f32a094e-3b86-45aa-a2ce-fbe8edf2d360	2026-06-05 04:11:55.229	2026-06-05 04:11:55.229
\.


--
-- Data for Name: chat_channel_members; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.chat_channel_members (id, channel_id, user_id, role, notification_pref, last_read_message_id, last_read_at, muted_until, joined_at) FROM stdin;
f0295028-8ca8-455e-8147-c10b84a05eba	1a15649b-4464-4da3-b74c-68c8b8271b09	8ec2805b-aaaf-4e66-9ab2-e03f49882cf4	ADMIN	MENTIONS	\N	\N	\N	2026-05-28 11:31:39.179
0ef48962-d5d1-4d6d-a05d-4c63c393c773	645bb72c-92b1-431b-8d7e-bc2c8cb659a6	f1244511-9f53-4a78-b4d0-91851b50de2e	ADMIN	MENTIONS	\N	\N	\N	2026-05-28 11:31:39.179
586b8617-aae3-4fb3-9f48-48f22a664f8f	645bb72c-92b1-431b-8d7e-bc2c8cb659a6	83e86a90-6e51-498b-b8b8-c6ef124058d2	MEMBER	MENTIONS	\N	\N	\N	2026-05-28 11:31:39.179
fa95d71b-6572-44f0-bf75-a019c996001c	1a15649b-4464-4da3-b74c-68c8b8271b09	0c7db1b0-6842-4f34-a845-84f41b1bf498	ADMIN	MENTIONS	\N	\N	\N	2026-05-28 11:31:39.179
1c8f441e-96ae-4039-971d-872214593d44	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	ADMIN	MENTIONS	a88c6ca5-c150-4014-a8a4-cd3354bf78c2	2026-05-29 05:15:42.925	\N	2026-05-28 17:47:16.155
ba5c435f-2422-4331-9d8a-552ea703128b	d86f0ab2-dae0-4308-b5d0-e8172626b55c	47ed672c-c15d-41e4-ab63-08fb039d08d2	MEMBER	MENTIONS	a88c6ca5-c150-4014-a8a4-cd3354bf78c2	2026-05-29 05:15:42.929	\N	2026-05-28 17:47:16.158
4f3c473e-51b4-42e3-b716-9b35c2aaba9d	69289fe9-7dcc-4196-b331-6b5ae5b54684	f1244511-9f53-4a78-b4d0-91851b50de2e	MEMBER	MENTIONS	b27f6c9e-0fc9-44db-ba18-ee0b94fcfba2	2026-06-03 01:31:52.145	\N	2026-06-03 01:27:21.38
d8d71cc1-8b7a-4ef1-854e-7a479f958ffa	6faa6ab7-55ca-41bd-b281-b7b568b03f87	f1244511-9f53-4a78-b4d0-91851b50de2e	ADMIN	MENTIONS	\N	\N	\N	2026-06-03 02:37:49.231
ecd682c2-4e5a-4e4f-af86-be497c1b0133	6faa6ab7-55ca-41bd-b281-b7b568b03f87	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	MEMBER	MENTIONS	\N	\N	\N	2026-06-03 02:37:49.234
4ba14c14-2b1b-4f81-873a-625fa84cdcd6	b72c65ed-eb09-4e22-a94a-6ef19ce6cc81	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	MEMBER	MENTIONS	\N	\N	\N	2026-06-03 02:37:49.237
5ee64049-3d2e-4d2e-8c80-49e9aaf6fd58	fde50771-0fd8-41d2-a09c-00946b0ae5e1	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	MEMBER	MENTIONS	\N	\N	\N	2026-06-03 02:37:49.239
c3a72fa3-a8f2-476b-bb63-7df251eb43e8	69289fe9-7dcc-4196-b331-6b5ae5b54684	83e86a90-6e51-498b-b8b8-c6ef124058d2	MEMBER	MENTIONS	b9e6faf6-118d-4ce5-addc-952325d66eae	2026-06-04 22:02:57.609	\N	2026-06-03 01:27:21.38
e013d2e7-ffac-4fc4-92d5-22c34d9f920d	f3387ed3-eef3-4543-a2b1-3c9d84c6d704	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	ADMIN	MENTIONS	\N	\N	\N	2026-05-28 18:36:54.754
2399cc37-af73-452b-b7c5-8e33d1b780cd	fde50771-0fd8-41d2-a09c-00946b0ae5e1	f1244511-9f53-4a78-b4d0-91851b50de2e	ADMIN	MENTIONS	c95a95f2-9483-49e1-8afc-408c4d7c8d8a	2026-06-05 04:12:19.401	\N	2026-06-03 02:37:49.238
f0e5a106-cc15-44c4-81d6-33a8d7ee8376	b72c65ed-eb09-4e22-a94a-6ef19ce6cc81	f1244511-9f53-4a78-b4d0-91851b50de2e	ADMIN	MENTIONS	788510fe-4fe1-426b-bf06-4a0b584bf367	2026-06-05 04:13:15.842	\N	2026-06-03 02:37:49.235
\.


--
-- Data for Name: chat_channels; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.chat_channels (id, org_id, kind, name, slug, description, topic, is_private, is_general, project_id, created_by_id, dm_key, last_message_at, archived_at, created_at, updated_at) FROM stdin;
645bb72c-92b1-431b-8d7e-bc2c8cb659a6	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	CHANNEL	general	general	\N	\N	f	t	\N	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	\N	\N	2026-05-28 11:31:39.179	2026-05-28 11:31:39.179
1a15649b-4464-4da3-b74c-68c8b8271b09	5311b52b-ae85-4f92-95e9-ed9bb7b91b1f	CHANNEL	general	general	\N	\N	f	t	\N	8ec2805b-aaaf-4e66-9ab2-e03f49882cf4	\N	\N	\N	2026-05-28 11:31:39.179	2026-05-28 11:31:39.179
f3387ed3-eef3-4543-a2b1-3c9d84c6d704	0a086635-a2f4-47d1-a160-7437402b5973	CHANNEL	smoke-u4cui	smoke-u4cui	\N	\N	f	f	\N	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	\N	\N	\N	2026-05-28 18:36:54.75	2026-05-28 18:36:54.75
d86f0ab2-dae0-4308-b5d0-e8172626b55c	0a086635-a2f4-47d1-a160-7437402b5973	CHANNEL	general	general	\N	\N	f	t	\N	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	\N	2026-05-29 05:15:42.681	\N	2026-05-28 17:47:16.152	2026-05-29 05:15:42.684
69289fe9-7dcc-4196-b331-6b5ae5b54684	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	DM	\N	\N	\N	\N	t	f	\N	f1244511-9f53-4a78-b4d0-91851b50de2e	83e86a90-6e51-498b-b8b8-c6ef124058d2:f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 01:32:04.97	\N	2026-06-03 01:27:21.379	2026-06-03 01:32:04.972
6faa6ab7-55ca-41bd-b281-b7b568b03f87	b3b93f25-2072-4514-8820-74712a67ca64	CHANNEL	general	general	\N	\N	f	t	\N	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	\N	\N	2026-06-03 02:37:49.227	2026-06-03 02:37:49.227
b72c65ed-eb09-4e22-a94a-6ef19ce6cc81	b3b93f25-2072-4514-8820-74712a67ca64	CHANNEL	sentinel-eng	sentinel-eng	\N	Sentinel engineering	f	f	\N	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	\N	\N	2026-06-03 02:37:49.229	2026-06-03 02:37:49.229
fde50771-0fd8-41d2-a09c-00946b0ae5e1	b3b93f25-2072-4514-8820-74712a67ca64	CHANNEL	security-compliance	security-compliance	\N	ISSO / CMMC / ATO	f	f	\N	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-05 04:12:19.328	\N	2026-06-03 02:37:49.231	2026-06-05 04:12:19.329
\.


--
-- Data for Name: chat_message_attachments; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.chat_message_attachments (id, message_id, kind, url, storage_key, filename, content_type, size, width, height, uploaded_by_id, created_at, classification_level) FROM stdin;
\.


--
-- Data for Name: chat_message_mentions; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.chat_message_mentions (id, message_id, user_id, created_at) FROM stdin;
a026e9bb-55bd-4f20-8ae6-436aeaa268a7	3bb9195d-2c55-4144-a2d0-b74374d2dff9	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-05-28 18:03:28.249
ba3cf144-88bb-487a-8354-7711470afd49	0113a1f2-949d-48af-b980-ca470fc8dd4c	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-05-28 18:05:44.555
1892b11f-8946-4183-b0b8-65bbecb3e047	6dfd82d2-9141-4977-8830-c2e89acdda09	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-05-28 18:06:10.978
1b28e558-269d-4b62-8160-3ddff7e5b33b	12cac8cd-e3b6-49a0-9200-dc73d285aa1d	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-05-28 18:06:38.311
c0b76b22-e101-45f6-b74a-6c2cb951bdbc	0e662dcf-e19c-49f6-b7c3-af973a3b839f	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-05-28 18:07:02.984
793104b8-91c1-40da-b944-c712ff9e2b3b	3ac557e7-a593-4bc1-9cfd-362efa242665	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-05-28 18:07:21.166
ebc5ed79-0c5a-4e37-836d-0bb166c5191f	e2ba7551-6140-43a1-bde0-3a5bcab23eb4	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-05-28 18:33:52.334
a311e446-5af6-4a6a-a7f9-59d31722e587	ac47ca71-2e83-44b6-b5b3-1abf76bdc20f	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-05-28 18:37:58.68
fc3909c3-f269-4221-8a71-a36fcde03083	9c4b3824-8a23-410e-ba99-91ddc84fe3c9	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-05-28 18:39:49.775
727feab2-841c-4bbf-b117-d55af428b23c	03d3db38-935d-4b7c-b448-ca70ea248d11	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-05-28 19:09:01.593
d7ea4978-a00a-4591-b482-6e0ae49c7e41	5d112b6c-23b4-436a-878b-c67d60778505	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-05-28 20:26:06.689
e6ca1695-e241-4386-997c-9ea2776a9c11	608f0c84-d834-4ddb-9d9c-365cef284136	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-05-29 01:03:33.146
338e9516-62a7-4261-ad7a-f4754fbc43fb	281e5e12-d2a8-4bc8-ab66-9fa7b36d99dd	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-05-29 01:10:45.163
33ca9014-ccb4-4f23-be34-c1a29537a8cb	77fb0a31-a6f4-4b40-a559-05066cfaf735	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-05-29 01:11:20.486
\.


--
-- Data for Name: chat_message_reactions; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.chat_message_reactions (id, message_id, user_id, emoji, created_at) FROM stdin;
cca938b5-a09c-4036-aea6-0d45e9b5420f	5d112b6c-23b4-436a-878b-c67d60778505	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	👍	2026-05-28 20:26:08.39
\.


--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.chat_messages (id, channel_id, author_id, content, parent_message_id, edited_at, deleted_at, created_at, kind) FROM stdin;
3bb9195d-2c55-4144-a2d0-b74374d2dff9	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Hello <@47ed672c-c15d-41e4-ab63-08fb039d08d2>!	\N	\N	\N	2026-05-28 18:03:28.239	USER
0113a1f2-949d-48af-b980-ca470fc8dd4c	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Hello <@47ed672c-c15d-41e4-ab63-08fb039d08d2>!	\N	\N	\N	2026-05-28 18:05:44.553	USER
6dfd82d2-9141-4977-8830-c2e89acdda09	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Hello <@47ed672c-c15d-41e4-ab63-08fb039d08d2>!	\N	\N	\N	2026-05-28 18:06:10.972	USER
12cac8cd-e3b6-49a0-9200-dc73d285aa1d	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Hello <@47ed672c-c15d-41e4-ab63-08fb039d08d2>!	\N	\N	\N	2026-05-28 18:06:38.294	USER
0e662dcf-e19c-49f6-b7c3-af973a3b839f	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Hello <@47ed672c-c15d-41e4-ab63-08fb039d08d2>!	\N	\N	\N	2026-05-28 18:07:02.972	USER
3ac557e7-a593-4bc1-9cfd-362efa242665	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Hello <@47ed672c-c15d-41e4-ab63-08fb039d08d2>!	\N	\N	\N	2026-05-28 18:07:21.15	USER
e2ba7551-6140-43a1-bde0-3a5bcab23eb4	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Hello <@47ed672c-c15d-41e4-ab63-08fb039d08d2>!	\N	\N	\N	2026-05-28 18:33:52.326	USER
4ce4eaa1-4600-4684-958b-95047336bd8e	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	smoke-realtime-mppu4nq1	\N	\N	\N	2026-05-28 18:37:09.123	USER
ac47ca71-2e83-44b6-b5b3-1abf76bdc20f	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	smoke-mention-mppu5q36 <@47ed672c-c15d-41e4-ab63-08fb039d08d2>	\N	\N	\N	2026-05-28 18:37:58.676	USER
a707e1f4-2218-4abe-a29a-a78f6220c125	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	realtime-mppu71rp	\N	\N	\N	2026-05-28 18:39:00.529	USER
9c4b3824-8a23-410e-ba99-91ddc84fe3c9	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Hello <@47ed672c-c15d-41e4-ab63-08fb039d08d2>!	\N	\N	\N	2026-05-28 18:39:49.769	USER
f00b8b94-52bd-446f-8975-25d680897f5d	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	bingo-mppu9vec	\N	\N	\N	2026-05-28 18:41:12.237	USER
030268b4-dfce-4a38-81b3-3695da42db24	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	bingo-mppuaaxs	\N	\N	\N	2026-05-28 18:41:32.379	USER
0d7e417d-7f87-47fe-8823-7ebf0b9b86fd	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	evprobe-mppucb82	\N	\N	\N	2026-05-28 18:43:05.985	USER
5a117dc8-7d17-46e1-b5d8-4e74af95d51d	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	cachetest-mppuec52	\N	\N	\N	2026-05-28 18:44:40.485	USER
30cd48e2-a1be-4055-9df6-ef961b79e548	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	proof-mppuf1dw	\N	\N	\N	2026-05-28 18:45:13.355	USER
ae75624e-d0a9-4306-b3ea-dfccc0db1239	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	dbg-mppuxzve	\N	\N	\N	2026-05-28 18:59:57.75	USER
525ca6e5-cf41-4f42-a3c8-765bb989c25c	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	dbg-mppuytaa	\N	\N	\N	2026-05-28 19:00:35.882	USER
c88ca12a-3bc0-4ae6-9d73-2b371d4f57ca	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	dbg-mppuzrt9	\N	\N	\N	2026-05-28 19:01:20.633	USER
c32fc3cd-59ea-4a0a-8006-f6a44d64e5f4	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	BIG-mppv0k0z-UNIQUE	\N	\N	\N	2026-05-28 19:01:57.129	USER
8253cc0f-924d-432b-a33c-52a2c83a9e99	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	MARK-mppv1982-X	\N	\N	\N	2026-05-28 19:02:29.78	USER
d1853520-8c4e-4844-b305-af752a090812	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Z-mppv3u1m-Z	\N	\N	\N	2026-05-28 19:04:30.069	USER
94a10774-d432-4f23-9695-176e75d942b8	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Z-mppv4zoi-Z	\N	\N	\N	2026-05-28 19:05:24.067	USER
a65c8ae3-eb25-4c07-9ffb-ef2e1c9ac632	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17		\N	2026-05-28 19:08:10.813	2026-05-28 19:08:11.39	2026-05-28 19:08:08.364	USER
03d3db38-935d-4b7c-b448-ca70ea248d11	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Hello <@47ed672c-c15d-41e4-ab63-08fb039d08d2>!	\N	\N	\N	2026-05-28 19:09:01.529	USER
5d112b6c-23b4-436a-878b-c67d60778505	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Reactions test mppy0rlc <@47ed672c-c15d-41e4-ab63-08fb039d08d2>	\N	\N	\N	2026-05-28 20:26:06.686	USER
442ec205-7407-4d79-9251-2c73ad849cb4	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Thread parent mppy0ye8	\N	\N	\N	2026-05-28 20:26:14.71	USER
eaac56e7-2df7-45ca-bfd2-5e7d897cc3d4	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Reply mppy0ye8	442ec205-7407-4d79-9251-2c73ad849cb4	\N	\N	2026-05-28 20:26:15.179	USER
6e77d76a-be2b-4fcb-80b8-73385e8114af	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Receipt test mpq7d45n	\N	\N	\N	2026-05-29 00:47:39.602	USER
4d66605b-9011-475e-b105-d8c48fd99923	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Receipt test mpq7eunr	\N	\N	\N	2026-05-29 00:49:00.47	USER
feb1ba14-39cc-4459-9c3f-71a676411619	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	test-bus-1780016569997	\N	\N	\N	2026-05-29 01:02:50.265	USER
608f0c84-d834-4ddb-9d9c-365cef284136	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Hello <@47ed672c-c15d-41e4-ab63-08fb039d08d2>!	\N	\N	\N	2026-05-29 01:03:33.13	USER
ef6e4374-f617-4b22-a36f-99a36f677276	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Receipt test mpq86cfm	\N	\N	\N	2026-05-29 01:10:23.127	USER
281e5e12-d2a8-4bc8-ab66-9fa7b36d99dd	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Hello <@47ed672c-c15d-41e4-ab63-08fb039d08d2>!	\N	\N	\N	2026-05-29 01:10:45.155	USER
d33038f5-7d60-4d5e-8723-beda75206621	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Receipt test mpq879bq	\N	\N	\N	2026-05-29 01:11:05.581	USER
77fb0a31-a6f4-4b40-a559-05066cfaf735	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Reactions test mpq87l5d <@47ed672c-c15d-41e4-ab63-08fb039d08d2>	\N	\N	\N	2026-05-29 01:11:20.476	USER
85bddca1-a65c-4864-91fa-49ecfd017929	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Thread parent mpq87s6r	\N	\N	\N	2026-05-29 01:11:29.506	USER
349117d2-5564-47a5-89f5-b64c75e33554	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	waves mpqgx7sg	\N	\N	\N	2026-05-29 05:15:13.377	ACTION
e8e06020-e033-49f5-8e1c-26a340993389	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	say hello mpqgxb7h	\N	\N	\N	2026-05-29 05:15:21.861	USER
a1435a37-e374-4f10-886c-4bc8c9d5b8b6	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Hello! 👋	\N	\N	\N	2026-05-29 05:15:30.258	ASSISTANT
3ef50d5c-0506-47aa-9c8f-f00a779f5dd6	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	Pin me mpqgxo3h	\N	\N	\N	2026-05-29 05:15:36.29	USER
a88c6ca5-c150-4014-a8a4-cd3354bf78c2	d86f0ab2-dae0-4308-b5d0-e8172626b55c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	📌 Alice pinned a message	\N	\N	\N	2026-05-29 05:15:42.681	SYSTEM
b27f6c9e-0fc9-44db-ba18-ee0b94fcfba2	69289fe9-7dcc-4196-b331-6b5ae5b54684	f1244511-9f53-4a78-b4d0-91851b50de2e	hey	\N	\N	\N	2026-06-03 01:31:52.15	USER
b9e6faf6-118d-4ce5-addc-952325d66eae	69289fe9-7dcc-4196-b331-6b5ae5b54684	f1244511-9f53-4a78-b4d0-91851b50de2e	📌 Jon Rannabargar pinned a message	\N	\N	\N	2026-06-03 01:32:04.97	SYSTEM
45f45ac6-5711-49a7-9dc5-3bbc73af8bdd	fde50771-0fd8-41d2-a09c-00946b0ae5e1	f1244511-9f53-4a78-b4d0-91851b50de2e	Reminder: the C3PAO assessment window opens in ~3 weeks. ATO evidence for the AC/AU/SC families needs to be closed out.	\N	\N	\N	2026-06-01 02:37:49.039	USER
7bd7f700-a81b-4fac-a62e-29328f8a14fb	fde50771-0fd8-41d2-a09c-00946b0ae5e1	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	STIG CAT I findings on the RHEL baseline are remediated and evidence is uploaded. CAT II Nessus items are still open — tracked in SENTINEL-6.	\N	\N	\N	2026-06-01 14:37:49.039	USER
359d9d22-432e-4b1f-b9b0-33415af7c841	fde50771-0fd8-41d2-a09c-00946b0ae5e1	f1244511-9f53-4a78-b4d0-91851b50de2e	Good. Let's get the SSP package (SENTINEL-4) over the line — it's our biggest overdue item this sprint.	\N	\N	\N	2026-06-02 02:37:49.039	USER
950ea1ba-e7ac-4f9f-bb5a-43336146a926	b72c65ed-eb09-4e22-a94a-6ef19ce6cc81	241480b1-17de-4c30-975e-722aa992e640	FIPS module is validated and merged — data-at-rest is green. Updating SENTINEL-1.	\N	\N	\N	2026-05-29 13:24:16.685	USER
c400e08f-ba39-445c-9120-c9617786c1bc	b72c65ed-eb09-4e22-a94a-6ef19ce6cc81	118ec485-9938-4146-9d0b-943c007ffc64	CI security gates are blocking on 2 high CVEs in a base image. Rebuilding from the hardened UBI.	\N	\N	\N	2026-05-30 13:24:16.685	USER
73773e1f-3569-41f2-8578-36aa727f2c88	b72c65ed-eb09-4e22-a94a-6ef19ce6cc81	7789efda-ce1b-4f2d-bec5-edf32f52e443	mTLS gateway is up in the IL4 enclave. Latency looks good (<15ms p95).	\N	\N	\N	2026-05-31 13:24:16.685	USER
6b8c1341-b2e8-41d0-9358-d2b4b1182ba5	b72c65ed-eb09-4e22-a94a-6ef19ce6cc81	18198088-f46b-420d-a37e-0b7d8d968855	Regression suite green except the cross-domain test — flaky, looking into it.	\N	\N	\N	2026-06-01 13:24:16.685	USER
788510fe-4fe1-426b-bf06-4a0b584bf367	b72c65ed-eb09-4e22-a94a-6ef19ce6cc81	f1244511-9f53-4a78-b4d0-91851b50de2e	Great progress team. Sprint 5 review Friday — let's make the ATO package the headline.	\N	\N	\N	2026-06-02 13:24:16.685	USER
74a451f2-2981-4776-a32d-64c29e20fb81	fde50771-0fd8-41d2-a09c-00946b0ae5e1	f1244511-9f53-4a78-b4d0-91851b50de2e	📌 Jon Rannabargar pinned a message	\N	\N	\N	2026-06-05 04:12:14.013	SYSTEM
a2e98c83-8e42-45cd-852c-3517a7b52d2e	fde50771-0fd8-41d2-a09c-00946b0ae5e1	f1244511-9f53-4a78-b4d0-91851b50de2e	📌 Jon Rannabargar pinned a message	\N	\N	\N	2026-06-05 04:12:17.205	SYSTEM
c95a95f2-9483-49e1-8afc-408c4d7c8d8a	fde50771-0fd8-41d2-a09c-00946b0ae5e1	f1244511-9f53-4a78-b4d0-91851b50de2e	📌 Jon Rannabargar pinned a message	\N	\N	\N	2026-06-05 04:12:19.328	SYSTEM
\.


--
-- Data for Name: chat_pinned_messages; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.chat_pinned_messages (id, channel_id, message_id, pinned_by_id, pinned_at) FROM stdin;
b44a1029-6e68-45ad-bb1e-8147574cedc4	d86f0ab2-dae0-4308-b5d0-e8172626b55c	3ef50d5c-0506-47aa-9c8f-f00a779f5dd6	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-05-29 05:15:42.678
ee3d5efb-96e1-41c5-91bd-63af7675bfde	69289fe9-7dcc-4196-b331-6b5ae5b54684	b27f6c9e-0fc9-44db-ba18-ee0b94fcfba2	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 01:32:04.967
17fb0feb-53f6-4694-b484-368156b9821a	fde50771-0fd8-41d2-a09c-00946b0ae5e1	7bd7f700-a81b-4fac-a62e-29328f8a14fb	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-05 04:12:19.324
\.


--
-- Data for Name: chat_thread_followers; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.chat_thread_followers (id, user_id, channel_id, parent_message_id, last_read_at, created_at) FROM stdin;
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.comments (id, org_id, work_item_id, author_id, content, created_at, updated_at) FROM stdin;
b2d50753-367d-4bca-b346-c47e60f2384b	b3b93f25-2072-4514-8820-74712a67ca64	27fe3905-f7d8-4b4e-a720-b6946a5a8ca4	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	AC and AU families are drafted. SC needs the boundary diagram from Priya before I can close it out.	2026-05-31 13:24:16.685	2026-06-03 13:24:16.827
d0cdd96c-4b6e-4455-87f9-1889fd37efd6	b3b93f25-2072-4514-8820-74712a67ca64	27fe3905-f7d8-4b4e-a720-b6946a5a8ca4	f1244511-9f53-4a78-b4d0-91851b50de2e	This is our critical path for the C3PAO. Let's pair on it Thursday.	2026-06-01 13:24:16.685	2026-06-03 13:24:16.827
198c5246-d8c0-4b1e-87d4-2b342cb6ec10	b3b93f25-2072-4514-8820-74712a67ca64	de5a0237-0d31-488a-b201-5cc7cf4bfd00	241480b1-17de-4c30-975e-722aa992e640	3 CAT II findings left — patching the RHEL hosts this week, then re-scan.	2026-06-02 13:24:16.685	2026-06-03 13:24:16.83
\.


--
-- Data for Name: compliance_controls; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.compliance_controls (id, org_id, framework, control_id, title, description, status, evidence, notes, assessed_at, assessed_by_id, due_date, created_at, updated_at) FROM stdin;
4f91dbb3-d725-412c-b705-35f177413e02	b3b93f25-2072-4514-8820-74712a67ca64	CMMC_L2	AC.L2-3.1.3	Control the flow of CUI in accordance with approved authorizations		PARTIALLY_IMPLEMENTED	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 02:37:49.209	2026-06-03 02:37:49.209
2b43f746-3af2-4c31-a3a6-8cdb32ee1319	b3b93f25-2072-4514-8820-74712a67ca64	CMMC_L2	IR.L2-3.6.1	Establish an operational incident-handling capability		IN_PROGRESS	[]	CUI spillage runbook in review — SENTINEL-8.	\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 02:37:49.039	2026-06-03 02:37:49.211	2026-06-03 02:37:49.211
213f3a24-f0c2-4236-9bd1-a28db7ae774b	b3b93f25-2072-4514-8820-74712a67ca64	CMMC_L2	SI.L2-3.14.6	Monitor organizational systems including inbound/outbound traffic		NOT_ASSESSED	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 02:37:49.212	2026-06-03 02:37:49.212
3a6048ec-4ec1-4e0f-b0f9-54f04a170d11	b3b93f25-2072-4514-8820-74712a67ca64	CMMC_L2	RA.L2-3.11.3	Remediate vulnerabilities in accordance with risk assessments		IN_PROGRESS	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-06 02:37:49.039	2026-06-03 02:37:49.213	2026-06-03 02:37:49.213
c9ac1a36-18de-4b11-b109-5510d7b8f25e	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.1.1	Limit system access to authorized users and devices		IMPLEMENTED	[]		2026-05-27 02:37:49.039	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 02:37:49.184	2026-06-03 13:24:16.896
28f02a31-3e24-4d50-bcc0-0f202d8cf282	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.1.2	Limit access to permitted transactions and functions		IMPLEMENTED	[]		2026-05-27 02:37:49.039	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 02:37:49.187	2026-06-03 13:24:16.898
e91bc54a-7256-434a-8106-06b567352413	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.1.3	Control the flow of CUI in accordance with approved authorizations		PARTIALLY_IMPLEMENTED	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-17 13:24:16.685	2026-06-03 13:24:16.899	2026-06-03 13:24:16.899
c1448bd3-097a-44f2-9416-1a7658297992	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.1.4	Separate the duties of individuals to reduce risk		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.9	2026-06-03 13:24:16.9
43a4bc3c-d80d-449b-9afb-8222880ab014	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.1.5	Employ the principle of least privilege		IMPLEMENTED	[]		2026-05-27 02:37:49.039	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 02:37:49.188	2026-06-03 13:24:16.901
242dba9d-e9a5-4d0b-b94e-272cde6d2e4d	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.1.6	Use non-privileged accounts for non-security functions		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.902	2026-06-03 13:24:16.902
b1b40b8d-f32d-4f4b-9083-bd8ff76aea20	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.1.7	Prevent non-privileged users from executing privileged functions		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.904	2026-06-03 13:24:16.904
ca9fe5bc-afd7-48da-ac32-5f6a6eb22609	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.1.8	Limit unsuccessful logon attempts		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.905	2026-06-03 13:24:16.905
2654ab1a-f57c-41c0-bee2-126e79d4c687	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.1.9	Provide privacy and security notices consistent with CUI rules		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.906	2026-06-03 13:24:16.906
2a104610-f65e-42ef-9417-3965f3ba4275	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.1.10	Use session lock with pattern-hiding displays		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.907	2026-06-03 13:24:16.907
a3f0a043-ac93-45c4-921f-4d0d3113f8a6	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.1.11	Terminate user sessions after a defined condition		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.908	2026-06-03 13:24:16.908
cd695972-93ae-4a8a-8cc1-62aede3cc368	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.1.12	Monitor and control remote access sessions		IN_PROGRESS	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-17 02:37:49.039	2026-06-03 02:37:49.19	2026-06-03 13:24:16.91
6539f93d-2fbf-45b7-b2f5-b8d3b7a9ff65	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.1.13	Employ cryptographic mechanisms to protect remote access		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.911	2026-06-03 13:24:16.911
1ce0bcfe-39d7-425d-aceb-25fab7489c2f	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.1.14	Route remote access via managed access control points		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.912	2026-06-03 13:24:16.912
de811c33-fb87-41c0-91a2-b1ab8a3d55aa	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.1.15	Authorize remote execution of privileged commands		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.913	2026-06-03 13:24:16.913
482ea950-12db-4767-a3fb-cec729306c56	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.1.16	Authorize wireless access prior to allowing connections		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.915	2026-06-03 13:24:16.915
020377d6-48ee-4d7f-aa18-5cd63fe3858e	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.1.17	Protect wireless access using authentication and encryption		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.916	2026-06-03 13:24:16.916
0d1a9777-aae0-451c-b814-130d95bfc4d1	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.1.18	Control connection of mobile devices		IN_PROGRESS	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-17 13:24:16.685	2026-06-03 13:24:16.917	2026-06-03 13:24:16.917
a0b34ea6-dfd6-4fbc-b6f0-5e5476c1b3c2	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.1.19	Encrypt CUI on mobile devices and platforms		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.918	2026-06-03 13:24:16.918
f5c54c68-b6ce-4e91-a6a9-20a4f436fffd	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.1.20	Verify and control connections to external systems		IMPLEMENTED	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 02:37:49.191	2026-06-03 13:24:16.919
30d36ffb-59a3-4d59-ab41-05bf3b9520d6	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.1.21	Limit use of portable storage devices on external systems		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.92	2026-06-03 13:24:16.92
56cc6d34-ab8c-4465-a7dc-e7b58eb2008c	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.1.22	Control CUI posted or processed on publicly accessible systems		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.921	2026-06-03 13:24:16.921
a5d633f9-4a6e-4b90-a043-51425e267a0d	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.2.1	Ensure personnel are trained on security risks and policies		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.922	2026-06-03 13:24:16.922
fa5618e5-faf8-4357-a3c4-2b50715cb938	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.3.1	Create and retain system audit logs and records		IMPLEMENTED	[]		2026-05-27 02:37:49.039	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 02:37:49.192	2026-06-03 13:24:16.925
da4305a5-d20d-4d15-82f2-c80effdaa165	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.3.2	Ensure actions are traceable to individual users		IMPLEMENTED	[]		2026-05-27 02:37:49.039	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 02:37:49.194	2026-06-03 13:24:16.926
fa044931-773d-4dd2-9712-57e29169aae7	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.4.1	Establish and maintain baseline configurations and inventories		IMPLEMENTED	[]		2026-05-27 02:37:49.039	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 02:37:49.195	2026-06-03 13:24:16.934
d5c9627f-bb9f-4501-80f2-e02d32639334	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.4.2	Establish and enforce security configuration settings		IMPLEMENTED	[]		2026-05-27 02:37:49.039	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 02:37:49.197	2026-06-03 13:24:16.935
3aba89df-b1af-4c45-a23d-96a612a2b863	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.5.3	Use multifactor authentication for access		IN_PROGRESS	[]	CAC/PIV integration in progress — see SENTINEL-5.	\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-13 02:37:49.039	2026-06-03 02:37:49.198	2026-06-03 13:24:16.946
956ca2a2-10bf-41e7-a7c8-b9a969624c55	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.5.10	Store and transmit only cryptographically-protected passwords		IMPLEMENTED	[]		2026-05-27 02:37:49.039	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 02:37:49.199	2026-06-03 13:24:16.953
56388b29-fa93-4558-8495-39809d813e4f	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.8.3	Sanitize or destroy system media before disposal or reuse		IMPLEMENTED	[]		2026-05-27 02:37:49.039	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 02:37:49.201	2026-06-03 13:24:16.966
bad443b8-1e3a-4b73-98b9-f4dad790bcd8	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.13.1	Monitor and control communications at system boundaries		PARTIALLY_IMPLEMENTED	[]	Cross-domain boundary rules deployed; egress monitoring pending.	\N	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 02:37:49.203	2026-06-03 13:24:16.992
6228bacf-ab16-4379-bcf9-d3d347725c11	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.13.11	Employ FIPS-validated cryptography to protect CUI		IMPLEMENTED	[]	FIPS 140-3 module deployed for data-at-rest (SENTINEL-1).	2026-05-27 02:37:49.039	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 02:37:49.204	2026-06-03 13:24:17.002
fe023e23-8774-433e-af29-b74686483ca5	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.13.16	Protect the confidentiality of CUI at rest		IMPLEMENTED	[]		2026-05-27 02:37:49.039	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 02:37:49.206	2026-06-03 13:24:17.007
e720f959-30d0-45c4-bfd7-da8d7f052ec8	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.14.1	Identify, report, and correct system flaws in a timely manner		IN_PROGRESS	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-10 02:37:49.039	2026-06-03 02:37:49.207	2026-06-03 13:24:17.007
6df579c7-fb9c-418c-81c4-6fd4b2d67657	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.14.2	Provide protection from malicious code		IMPLEMENTED	[]		2026-05-27 02:37:49.039	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 02:37:49.208	2026-06-03 13:24:17.008
62476cf8-827e-43d2-aa43-980f942ff80e	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.2.2	Train personnel to carry out their security duties		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.923	2026-06-03 13:24:16.923
c0977cc9-effe-4926-b283-4c1b7db2a884	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.2.3	Provide security awareness training on insider threat		NOT_ASSESSED	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-17 13:24:16.685	2026-06-03 13:24:16.924	2026-06-03 13:24:16.924
5fb3b7f2-a04e-4ce2-82c8-98f3c914bffa	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.3.3	Review and update logged events		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.927	2026-06-03 13:24:16.927
089b41e8-5d2e-4a2c-8c6f-d64af1425b0f	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.3.4	Alert on audit logging process failures		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.928	2026-06-03 13:24:16.928
21751994-1260-4997-b482-06a5f7e9801f	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.3.5	Correlate audit review, analysis, and reporting		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.929	2026-06-03 13:24:16.929
dd7bf5c4-e953-4aa6-b56a-f809c378e124	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.3.6	Provide audit record reduction and report generation		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.93	2026-06-03 13:24:16.93
4e2e9f73-8917-4891-adf0-17991bb2e88a	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.3.7	Synchronize system clocks to an authoritative source		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.931	2026-06-03 13:24:16.931
19d5bad6-6892-4d85-af03-25f29090649a	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.3.8	Protect audit information and tools from unauthorized access		IN_PROGRESS	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-17 13:24:16.685	2026-06-03 13:24:16.932	2026-06-03 13:24:16.932
71a06b50-43ce-4f8d-9258-393fd3cfe103	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.3.9	Limit management of audit logging to a privileged subset		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.933	2026-06-03 13:24:16.933
dc05911e-9aab-4248-8536-46b35d21a846	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.4.3	Track, review, approve, and log configuration changes		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.936	2026-06-03 13:24:16.936
3bb339e4-523c-4f2a-9ab9-f76597008d07	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.4.4	Analyze the security impact of changes prior to implementation		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.937	2026-06-03 13:24:16.937
dd37aff5-9e74-48fd-8ad7-068a2ab89b44	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.4.5	Define, document, and enforce access restrictions for changes		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.938	2026-06-03 13:24:16.938
1e99cf1d-0a91-4e67-b227-06c5ae8a7da0	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.4.6	Employ the principle of least functionality		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.939	2026-06-03 13:24:16.939
49f99333-57e0-40e4-a0d4-82ada808c9e3	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.4.7	Restrict nonessential programs, ports, protocols, and services		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.94	2026-06-03 13:24:16.94
05c62397-7efb-4648-b6e7-9ae264fe6fab	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.4.8	Apply deny-by-exception (blacklist/whitelist) for software		PARTIALLY_IMPLEMENTED	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-17 13:24:16.685	2026-06-03 13:24:16.942	2026-06-03 13:24:16.942
9b7c44bb-0471-4747-9a77-3f7087964137	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.4.9	Control and monitor user-installed software		IN_PROGRESS	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-17 13:24:16.685	2026-06-03 13:24:16.943	2026-06-03 13:24:16.943
177363e0-db27-4ee6-b9a7-a4636694596b	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.5.1	Identify system users, processes, and devices		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.944	2026-06-03 13:24:16.944
815b854a-412e-4522-9b7a-55ce98810f63	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.5.2	Authenticate identities before granting access		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.945	2026-06-03 13:24:16.945
6ef36f6e-8d12-4ed5-a41c-3e1fe098d1df	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.5.4	Employ replay-resistant authentication mechanisms		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.947	2026-06-03 13:24:16.947
10629683-6111-42ce-a974-7aa869263521	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.5.5	Prevent reuse of identifiers for a defined period		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.948	2026-06-03 13:24:16.948
f249cc63-94c7-47f5-8488-13b5cf0e3f7d	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.5.6	Disable identifiers after a period of inactivity		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.949	2026-06-03 13:24:16.949
33855dc6-bb47-4725-9841-845589453c3a	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.5.7	Enforce a minimum password complexity		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.95	2026-06-03 13:24:16.95
6ee7d86c-4491-48f7-8f67-44d6f9df7929	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.5.8	Prohibit password reuse for a number of generations		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.951	2026-06-03 13:24:16.951
b283e170-7a2f-4b41-9dc2-5d804d6eee10	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.5.9	Allow temporary password use with immediate change		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.952	2026-06-03 13:24:16.952
7f1d5fb4-ee92-4b1e-9f21-0b3e56c5da94	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.5.11	Obscure feedback of authentication information		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.954	2026-06-03 13:24:16.954
33beeb72-5c24-4ad5-8f81-88163923c1e5	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.6.1	Establish an operational incident-handling capability		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.955	2026-06-03 13:24:16.955
ba302700-d714-41f3-93ee-a78f43e6095f	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.6.2	Track, document, and report incidents to officials		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.956	2026-06-03 13:24:16.956
672e3d13-3dee-446e-9a41-a90472d8b4d0	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.6.3	Test the organizational incident response capability		IN_PROGRESS	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-17 13:24:16.685	2026-06-03 13:24:16.957	2026-06-03 13:24:16.957
530a8120-2931-44c4-89fd-49b98527f051	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.7.1	Perform maintenance on organizational systems		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.958	2026-06-03 13:24:16.958
5436048a-e4f1-4876-8719-334618eadf07	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.7.2	Provide controls on tools, techniques, and personnel for maintenance		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.959	2026-06-03 13:24:16.959
319ba151-f6c8-4e03-bddf-71bfc78b6d69	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.7.3	Sanitize equipment removed for off-site maintenance		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.96	2026-06-03 13:24:16.96
a73d6e5c-7907-4240-9e3c-c9ad6c222e93	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.7.4	Check media containing diagnostic programs for malicious code		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.961	2026-06-03 13:24:16.961
e6e7aeb1-e51e-4c67-927c-447fabd3707f	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.7.5	Require MFA to establish nonlocal maintenance sessions		IN_PROGRESS	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-17 13:24:16.685	2026-06-03 13:24:16.962	2026-06-03 13:24:16.962
b6da106c-c432-417a-ad32-e1129bced2c0	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.7.6	Supervise maintenance activities of personnel without access		NOT_ASSESSED	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-17 13:24:16.685	2026-06-03 13:24:16.963	2026-06-03 13:24:16.963
123bfe66-c8ed-46ba-80b4-29b5323fc963	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.8.1	Protect system media containing CUI		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.964	2026-06-03 13:24:16.964
0763e6bc-5eb7-48ac-b028-4b127759daba	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.8.2	Limit access to CUI on system media to authorized users		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.965	2026-06-03 13:24:16.965
7487c0f3-fbdc-44e6-b53e-014213c8271e	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.8.4	Mark media with necessary CUI markings and distribution limits		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.967	2026-06-03 13:24:16.967
406297b7-aaf4-48b9-9c5e-7cbb841d54d4	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.8.5	Control access to media and maintain accountability during transport		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.968	2026-06-03 13:24:16.968
55eec9ac-5a77-49cf-a1d5-1c58bbf844f8	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.8.6	Implement cryptographic protection of CUI on media in transport		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.969	2026-06-03 13:24:16.969
13981f43-9299-49e0-a7ad-47168c55622b	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.8.7	Control the use of removable media on system components		PARTIALLY_IMPLEMENTED	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-17 13:24:16.685	2026-06-03 13:24:16.971	2026-06-03 13:24:16.971
22ac3664-deb7-4dbc-ac2f-aa0d09ce3418	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.8.8	Prohibit use of portable storage with no identifiable owner		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.972	2026-06-03 13:24:16.972
8e0dcdc8-1360-43b4-9ad3-5f54c60b5432	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.8.9	Protect the confidentiality of backup CUI at storage locations		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.973	2026-06-03 13:24:16.973
ab1bd808-5161-4b66-bc58-be01446e3161	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.9.1	Screen individuals prior to authorizing access to CUI		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.974	2026-06-03 13:24:16.974
ad625bbc-02db-4f70-bd42-cd78e65c1efe	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.9.2	Protect CUI during personnel actions (termination/transfer)		NOT_ASSESSED	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-17 13:24:16.685	2026-06-03 13:24:16.977	2026-06-03 13:24:16.977
f5f9a17e-6949-4f50-bdf0-9be018982377	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.10.1	Limit physical access to systems and equipment		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.979	2026-06-03 13:24:16.979
ffb3e063-d409-41b2-ac7a-154bc53ed4b8	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.10.2	Protect and monitor the physical facility and infrastructure		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.98	2026-06-03 13:24:16.98
a82a68e5-9736-4b3b-b153-83d6ca733d95	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.10.3	Escort visitors and monitor visitor activity		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.981	2026-06-03 13:24:16.981
f5055965-f2ae-4b6f-ac96-5d94502cc0c1	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.10.4	Maintain audit logs of physical access		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.982	2026-06-03 13:24:16.982
eeba614e-0b23-4d65-852f-5d1ebbf54a6a	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.10.5	Control and manage physical access devices		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.983	2026-06-03 13:24:16.983
ce76bfa5-5831-415b-bc28-0f9dba126906	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.10.6	Enforce safeguarding measures for CUI at alternate work sites		PARTIALLY_IMPLEMENTED	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-17 13:24:16.685	2026-06-03 13:24:16.984	2026-06-03 13:24:16.984
37840046-ead4-43da-937c-09a79aa66975	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.11.1	Periodically assess risk to operations and assets		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.985	2026-06-03 13:24:16.985
2f235a01-14db-47d5-b897-2b00bfabfccb	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.11.3	Remediate vulnerabilities in accordance with risk assessments		IN_PROGRESS	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-17 13:24:16.685	2026-06-03 13:24:16.987	2026-06-03 13:24:16.987
54a2c6fb-a54a-4475-b096-6ec4ea9b50ef	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.12.1	Periodically assess the security controls for effectiveness		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.988	2026-06-03 13:24:16.988
a6bfde93-6579-4d56-bd5e-a46ccc7be9e7	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.12.2	Develop and implement plans of action (POA&M)		IN_PROGRESS	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-17 13:24:16.685	2026-06-03 13:24:16.989	2026-06-03 13:24:16.989
5b485aa8-4c9d-4672-94ac-9a71d85a65bc	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.12.3	Monitor security controls on an ongoing basis		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.99	2026-06-03 13:24:16.99
99033999-f94c-4c48-9e70-aa2a2dd8aee2	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.12.4	Develop, document, and update System Security Plans		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.991	2026-06-03 13:24:16.991
85c0949c-1c3d-4995-841a-d1b0a978b0c9	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.13.2	Employ architectural designs promoting effective security		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.993	2026-06-03 13:24:16.993
25e67dab-23fa-472d-92f6-bb592446ad2b	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.13.3	Separate user functionality from system management functionality		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.994	2026-06-03 13:24:16.994
fdc20e95-8526-4569-8214-edbb49ba9df0	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.13.4	Prevent unauthorized information transfer via shared resources		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.995	2026-06-03 13:24:16.995
4aeba367-7889-4c0b-adc7-0af33f2e34d7	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.13.5	Implement subnetworks for publicly accessible components		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.996	2026-06-03 13:24:16.996
93cb0203-784c-4926-8f50-3cde8bf164d1	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.13.6	Deny network traffic by default and allow by exception		PARTIALLY_IMPLEMENTED	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-17 13:24:16.685	2026-06-03 13:24:16.997	2026-06-03 13:24:16.997
28957af7-6455-486f-8924-5cb5de9de5c6	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.13.7	Prevent remote devices from split tunneling		IN_PROGRESS	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-17 13:24:16.685	2026-06-03 13:24:16.998	2026-06-03 13:24:16.998
408358ba-ecc7-488c-93a7-56b6de4e8ed5	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.13.8	Use cryptography to protect CUI during transmission		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:16.999	2026-06-03 13:24:16.999
998c5b2f-93f4-4af3-9fc3-1204b6003f2b	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.13.9	Terminate network connections at the end of sessions		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:17	2026-06-03 13:24:17
45761dc7-87ba-4263-add3-e83b34245878	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.13.10	Establish and manage cryptographic keys		IN_PROGRESS	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-17 13:24:16.685	2026-06-03 13:24:17.001	2026-06-03 13:24:17.001
f2a0356e-c2e0-4356-8c9b-f77bef46ecfd	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.13.12	Prohibit remote activation of collaborative computing devices		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:17.003	2026-06-03 13:24:17.003
f18d37f0-1029-4ae2-805c-62f497fc086e	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.13.13	Control and monitor use of mobile code		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:17.004	2026-06-03 13:24:17.004
6cf87ca0-f112-4a68-abe4-f3f5f78bfe56	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.13.14	Control and monitor use of VoIP technologies		NOT_ASSESSED	[]		\N	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-17 13:24:16.685	2026-06-03 13:24:17.005	2026-06-03 13:24:17.005
12a7257c-90cc-4e31-910c-d6da810330a9	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.13.15	Protect the authenticity of communications sessions		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:17.006	2026-06-03 13:24:17.006
32bc3062-630c-4989-a2c8-098b492dbabb	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.14.3	Monitor security alerts and advisories and take action		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:17.01	2026-06-03 13:24:17.01
1b91f6fa-ff70-40b7-9d5b-bbe0ddaff875	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.14.4	Update malicious code protection mechanisms		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:17.011	2026-06-03 13:24:17.011
53cb00bc-5b7c-4d0d-8849-72648c67a952	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.14.5	Perform periodic and real-time scans of the system		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:17.012	2026-06-03 13:24:17.012
ac1290ea-8349-42db-be8c-c49757d28f4c	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.14.6	Monitor systems including inbound/outbound traffic		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:17.013	2026-06-03 13:24:17.013
ff69efa3-b7bc-4c7d-96fe-ed15520a1792	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.14.7	Identify unauthorized use of organizational systems		IMPLEMENTED	[]		2026-05-14 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	2026-06-03 13:24:17.014	2026-06-03 13:24:17.014
38d2de1a-c88a-4390-be1e-d47c4b7dc2be	b3b93f25-2072-4514-8820-74712a67ca64	NIST_800_171	3.11.2	Scan for vulnerabilities and remediate in a timely manner		FAILED	[]	Q2 Nessus scan surfaced 3 open CAT II findings past SLA — remediation tracked in SENTINEL-6.	2026-06-03 13:40:08.407	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-02 13:40:08.646	2026-06-03 02:37:49.202	2026-06-03 13:40:08.647
\.


--
-- Data for Name: contracts; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.contracts (id, org_id, partner_id, product_id, title, value, currency, status, start_date, end_date, terms, notes, created_at, updated_at, docusign_envelope_id, docusign_status, signed_at, search_vector) FROM stdin;
c6c84a90-55a9-47a5-aecf-99d9d73e1fbf	b3b93f25-2072-4514-8820-74712a67ca64	\N	\N	Prime Contract FA8750-25-C-0142 — Sentinel Program	4450000.0000	USD	active	2026-02-03 02:37:49.039	2027-02-03 02:37:49.039	\N	Firm-fixed-price + CPFF CLINs. CDRLs per DD1423. CUI per DFARS 252.204-7012.	2026-06-03 02:37:49.225	2026-06-03 02:37:49.225	\N	\N	\N	\N
538517e3-0e9b-4182-8938-232a184f5458	b3b93f25-2072-4514-8820-74712a67ca64	e463f5bd-4ca6-4dd1-9427-dccca836976e	\N	Subcontract SUB-0142-001 — Vector Systems LLC	1200000.0000	USD	active	2026-03-05 02:37:49.039	2026-11-30 02:37:49.039	\N	Software engineering subcontract. Flowdowns: 7012, 7019, 7020.	2026-06-03 02:37:49.225	2026-06-03 02:37:49.225	\N	\N	\N	\N
\.


--
-- Data for Name: crm_contacts; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.crm_contacts (id, org_id, name, stage, value, deal_value, contact_info, owner_id, notes, custom_fields, created_at, updated_at) FROM stdin;
3ea0c571-6077-4987-9e87-7718ee68f1f5	b3b93f25-2072-4514-8820-74712a67ca64	Lt Col Sarah Mitchell — PM, USAF AFLCMC	CLOSED_WON	\N	4450000.0000	s.mitchell@us.af.mil	919f24b6-1143-4f55-b96b-067f50a59619	Sentinel program manager (customer).	{}	2026-06-03 13:24:16.846	2026-06-03 13:24:16.846
b9b7da98-9568-434c-b937-5934475a559d	b3b93f25-2072-4514-8820-74712a67ca64	Maria Gonzalez — Contracting Officer, AFLCMC/PK	CLOSED_WON	\N	4450000.0000	maria.gonzalez@us.af.mil	919f24b6-1143-4f55-b96b-067f50a59619	KO of record on FA8750-25-C-0142.	{}	2026-06-03 13:24:16.846	2026-06-03 13:24:16.846
d4afc6bc-1c69-437c-8709-d7e50bc0be1a	b3b93f25-2072-4514-8820-74712a67ca64	MDA — Sentinel sustainment (Option Year 2)	NEGOTIATION	\N	4450000.0000	acq@mda.mil	f1244511-9f53-4a78-b4d0-91851b50de2e	OY2 sustainment — in negotiation.	{}	2026-06-03 13:24:16.846	2026-06-03 13:24:16.846
1eadddaf-4d93-4a30-b5a2-7836cc4681b4	b3b93f25-2072-4514-8820-74712a67ca64	Navy PMW-160 — Cyber SA follow-on	PROPOSAL	\N	5200000.0000	pmw160.bd@navy.mil	919f24b6-1143-4f55-b96b-067f50a59619	Proposal submitted; orals next month.	{}	2026-06-03 13:24:16.846	2026-06-03 13:24:16.846
f89559e6-7dae-41a4-aaa3-08d6ec9a30a0	b3b93f25-2072-4514-8820-74712a67ca64	Army PEO C3T — RMF automation	QUALIFIED	\N	3100000.0000	peoc3t.bd@army.mil	919f24b6-1143-4f55-b96b-067f50a59619	RFI responded; awaiting draft RFP.	{}	2026-06-03 13:24:16.846	2026-06-03 13:24:16.846
4b7c8973-efb8-42e6-8c8e-454ee1ab1f3f	b3b93f25-2072-4514-8820-74712a67ca64	DISA — Zero Trust pilot	LEAD	\N	2400000.0000	ztp@disa.mil	f1244511-9f53-4a78-b4d0-91851b50de2e	Early shaping via SBIR.	{}	2026-06-03 13:24:16.846	2026-06-03 13:24:16.846
7fa6a255-bdec-418b-bf44-be825f9df477	b3b93f25-2072-4514-8820-74712a67ca64	DARPA — AI4Cyber BAA	LEAD	\N	1800000.0000	i2o@darpa.mil	241480b1-17de-4c30-975e-722aa992e640	White paper in draft.	{}	2026-06-03 13:24:16.846	2026-06-03 13:24:16.846
65c29237-584a-4492-8cbd-216225c813ba	b3b93f25-2072-4514-8820-74712a67ca64	DHS CISA — CDM task order	CLOSED_LOST	\N	2900000.0000	cdm@cisa.dhs.gov	919f24b6-1143-4f55-b96b-067f50a59619	Lost to incumbent on price.	{}	2026-06-03 13:24:16.846	2026-06-03 13:24:16.846
\.


--
-- Data for Name: custom_fields; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.custom_fields (id, org_id, project_id, name, key, field_type, options, required, sort_order, created_at) FROM stdin;
\.


--
-- Data for Name: cycle_capacities; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.cycle_capacities (id, cycle_id, user_id, capacity, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cycles; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.cycles (id, org_id, project_id, cycle_kind, number, name, sector_label, goal, start_date, end_date, status, report, created_at) FROM stdin;
25cb73c5-f1ca-48e4-a2a3-e305e6bf7739	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	SPRINT	5	Increment 2 · Sprint 5	Sprint	Close ATO evidence for the AC/AU/SC control families and clear CAT I/II findings ahead of the C3PAO assessment.	2026-05-24 02:37:49.039	2026-06-08 02:37:49.039	ACTIVE	\N	2026-06-03 02:37:49.175
7a9c71dd-c7fa-4305-bdce-c587c5526292	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	SPRINT	1	Increment 1 · Sprint 1	Sprint	Increment delivery + control implementation.	2026-03-15 13:24:16.685	2026-03-29 13:24:16.685	COMPLETED	\N	2026-06-03 13:24:16.805
4301fadb-47ad-42ea-b1a1-051f175d0058	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	SPRINT	2	Increment 1 · Sprint 2	Sprint	Increment delivery + control implementation.	2026-03-30 13:24:16.685	2026-04-13 13:24:16.685	COMPLETED	\N	2026-06-03 13:24:16.81
8bfc5efb-4c06-4dbe-a4a8-d68c7092030a	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	SPRINT	3	Increment 1 · Sprint 3	Sprint	Increment delivery + control implementation.	2026-04-14 13:24:16.685	2026-04-28 13:24:16.685	COMPLETED	\N	2026-06-03 13:24:16.813
19337766-db98-4ae9-bcd3-1dcd1215d310	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	SPRINT	4	Increment 2 · Sprint 4	Sprint	Increment delivery + control implementation.	2026-04-29 13:24:16.685	2026-05-13 13:24:16.685	COMPLETED	\N	2026-06-03 13:24:16.816
\.


--
-- Data for Name: dashboard_widgets; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.dashboard_widgets (id, board_id, type, config, "position") FROM stdin;
\.


--
-- Data for Name: data_classifications; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.data_classifications (id, org_id, project_id, level, markings, handling_instructions, applied_by_id, created_at, updated_at) FROM stdin;
5e4429d1-dc89-4698-b836-aa581d75c3fd	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	CUI	{CUI//SP-PROP,CUI//SP-EXPT}	Controlled Unclassified Information. Handle per 32 CFR Part 2002 and DFARS 252.204-7012. Store only on the GovCloud enclave; encrypt at rest (FIPS 140-3) and in transit. No dissemination outside the program without ISSO approval.	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 02:37:49.183	2026-06-03 14:41:58.367
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.documents (id, org_id, project_id, title, classification_level, storage_key, filename, content_type, size, uploaded_by_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.expenses (id, org_id, amount, currency, date, category, vendor, description, recurring, created_by_id, created_at, updated_at, approved_at, approved_by_id, status, submitted_at) FROM stdin;
0c40b99f-bebe-485e-a521-27985dd36c44	b3b93f25-2072-4514-8820-74712a67ca64	128400.0000	USD	2026-05-26	Subcontractor Labor	Vector Systems LLC	May subcontract labor (SUB-0142-001)	f	919f24b6-1143-4f55-b96b-067f50a59619	2026-06-03 02:37:49.218	2026-06-03 02:37:49.218	2026-05-27 02:37:49.039	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2026-05-26 02:37:49.039
e1fceca6-e732-4afd-b72e-33d61c8ad8ef	b3b93f25-2072-4514-8820-74712a67ca64	18750.0000	USD	2026-05-27	Cloud Hosting	CloudHarbor	AWS GovCloud hosting — May	f	241480b1-17de-4c30-975e-722aa992e640	2026-06-03 02:37:49.218	2026-06-03 02:37:49.218	2026-05-28 02:37:49.039	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2026-05-27 02:37:49.039
0e158b56-8ae3-4be2-bf1a-bf35188d148c	b3b93f25-2072-4514-8820-74712a67ca64	42000.0000	USD	2026-06-01	Security Assessment	SecureScan Inc.	Independent penetration test — pre-assessment	f	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	2026-06-03 02:37:49.218	2026-06-03 02:37:49.218	\N	\N	SUBMITTED	2026-06-01 02:37:49.039
fc209a11-a082-4e97-b651-fd3d0ca857c4	b3b93f25-2072-4514-8820-74712a67ca64	24000.0000	USD	2026-06-02	Facilities	Sentinel SCIF Holdings	SCIF lease — May	f	919f24b6-1143-4f55-b96b-067f50a59619	2026-06-03 02:37:49.218	2026-06-03 02:37:49.218	\N	\N	DRAFT	\N
0f399afe-a245-45c3-8403-80de09e64aa9	b3b93f25-2072-4514-8820-74712a67ca64	320028.0000	USD	2025-06-08	Direct Labor	Apex Defense Systems	Direct labor — month -12	f	919f24b6-1143-4f55-b96b-067f50a59619	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2025-06-08 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2025-06-08 13:24:16.685
25e5a036-7d29-4f83-8f48-18615e46598d	b3b93f25-2072-4514-8820-74712a67ca64	20232.0000	USD	2025-06-08	Cloud Hosting	CloudHarbor	AWS GovCloud — month -12	f	241480b1-17de-4c30-975e-722aa992e640	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2025-06-08 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2025-06-08 13:24:16.685
3d574a0b-5c37-4b0d-a8ed-8a1e7c9e1ab2	b3b93f25-2072-4514-8820-74712a67ca64	128400.0000	USD	2025-06-08	Subcontractor Labor	Vector Systems LLC	Subcontract — month -12	f	919f24b6-1143-4f55-b96b-067f50a59619	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2025-06-08 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2025-06-08 13:24:16.685
1de540c8-366f-4010-ab17-889da8c21927	b3b93f25-2072-4514-8820-74712a67ca64	312109.0000	USD	2025-07-08	Direct Labor	Apex Defense Systems	Direct labor — month -11	f	919f24b6-1143-4f55-b96b-067f50a59619	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2025-07-08 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2025-07-08 13:24:16.685
a219b343-bb32-420b-8f02-444586019283	b3b93f25-2072-4514-8820-74712a67ca64	19921.0000	USD	2025-07-08	Cloud Hosting	CloudHarbor	AWS GovCloud — month -11	f	241480b1-17de-4c30-975e-722aa992e640	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2025-07-08 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2025-07-08 13:24:16.685
6c9a6569-9edb-4408-9ece-81e02d9dfe14	b3b93f25-2072-4514-8820-74712a67ca64	304190.0000	USD	2025-08-07	Direct Labor	Apex Defense Systems	Direct labor — month -10	f	919f24b6-1143-4f55-b96b-067f50a59619	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2025-08-07 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2025-08-07 13:24:16.685
daae361e-f193-4c53-b9de-c17cae827626	b3b93f25-2072-4514-8820-74712a67ca64	19610.0000	USD	2025-08-07	Cloud Hosting	CloudHarbor	AWS GovCloud — month -10	f	241480b1-17de-4c30-975e-722aa992e640	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2025-08-07 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2025-08-07 13:24:16.685
f2c31aaf-5902-4d5a-8a95-e1870b97e250	b3b93f25-2072-4514-8820-74712a67ca64	296271.0000	USD	2025-09-06	Direct Labor	Apex Defense Systems	Direct labor — month -9	f	919f24b6-1143-4f55-b96b-067f50a59619	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2025-09-06 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2025-09-06 13:24:16.685
033da2fb-5b0d-4dc9-afd3-c357fa203797	b3b93f25-2072-4514-8820-74712a67ca64	19299.0000	USD	2025-09-06	Cloud Hosting	CloudHarbor	AWS GovCloud — month -9	f	241480b1-17de-4c30-975e-722aa992e640	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2025-09-06 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2025-09-06 13:24:16.685
6e730ddf-2777-4595-92b9-2fbd7a4d53e0	b3b93f25-2072-4514-8820-74712a67ca64	128400.0000	USD	2025-09-06	Subcontractor Labor	Vector Systems LLC	Subcontract — month -9	f	919f24b6-1143-4f55-b96b-067f50a59619	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2025-09-06 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2025-09-06 13:24:16.685
f1df05f6-aa06-410e-9eb9-d828162fa9ca	b3b93f25-2072-4514-8820-74712a67ca64	288352.0000	USD	2025-10-06	Direct Labor	Apex Defense Systems	Direct labor — month -8	f	919f24b6-1143-4f55-b96b-067f50a59619	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2025-10-06 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2025-10-06 13:24:16.685
2b2e44b6-9e01-472c-bba1-7b6a69ea9b80	b3b93f25-2072-4514-8820-74712a67ca64	18988.0000	USD	2025-10-06	Cloud Hosting	CloudHarbor	AWS GovCloud — month -8	f	241480b1-17de-4c30-975e-722aa992e640	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2025-10-06 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2025-10-06 13:24:16.685
5d8c39c2-853c-46c5-9150-e256aec9faf4	b3b93f25-2072-4514-8820-74712a67ca64	340433.0000	USD	2025-11-05	Direct Labor	Apex Defense Systems	Direct labor — month -7	f	919f24b6-1143-4f55-b96b-067f50a59619	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2025-11-05 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2025-11-05 13:24:16.685
45095cca-bbf8-454a-87c6-edac7bfac36d	b3b93f25-2072-4514-8820-74712a67ca64	18677.0000	USD	2025-11-05	Cloud Hosting	CloudHarbor	AWS GovCloud — month -7	f	241480b1-17de-4c30-975e-722aa992e640	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2025-11-05 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2025-11-05 13:24:16.685
721938ce-9b01-4095-b1af-4f0145ae1bc3	b3b93f25-2072-4514-8820-74712a67ca64	332514.0000	USD	2025-12-05	Direct Labor	Apex Defense Systems	Direct labor — month -6	f	919f24b6-1143-4f55-b96b-067f50a59619	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2025-12-05 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2025-12-05 13:24:16.685
7bb61a01-e71a-4383-9065-7e3a60d53081	b3b93f25-2072-4514-8820-74712a67ca64	18366.0000	USD	2025-12-05	Cloud Hosting	CloudHarbor	AWS GovCloud — month -6	f	241480b1-17de-4c30-975e-722aa992e640	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2025-12-05 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2025-12-05 13:24:16.685
52888b9e-489f-4f36-9d4d-1f3300df199f	b3b93f25-2072-4514-8820-74712a67ca64	128400.0000	USD	2025-12-05	Subcontractor Labor	Vector Systems LLC	Subcontract — month -6	f	919f24b6-1143-4f55-b96b-067f50a59619	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2025-12-05 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2025-12-05 13:24:16.685
f7d5d4ff-9a24-48ae-8b58-726a2013ddf5	b3b93f25-2072-4514-8820-74712a67ca64	324595.0000	USD	2026-01-04	Direct Labor	Apex Defense Systems	Direct labor — month -5	f	919f24b6-1143-4f55-b96b-067f50a59619	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2026-01-04 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2026-01-04 13:24:16.685
3758b76a-b857-468e-864b-f26cc91a43d3	b3b93f25-2072-4514-8820-74712a67ca64	18055.0000	USD	2026-01-04	Cloud Hosting	CloudHarbor	AWS GovCloud — month -5	f	241480b1-17de-4c30-975e-722aa992e640	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2026-01-04 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2026-01-04 13:24:16.685
eef7b35d-0192-4d31-859e-791a6f88bbfa	b3b93f25-2072-4514-8820-74712a67ca64	316676.0000	USD	2026-02-03	Direct Labor	Apex Defense Systems	Direct labor — month -4	f	919f24b6-1143-4f55-b96b-067f50a59619	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2026-02-03 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2026-02-03 13:24:16.685
31352ebb-c653-4884-83bc-ff0e5acab7d4	b3b93f25-2072-4514-8820-74712a67ca64	17744.0000	USD	2026-02-03	Cloud Hosting	CloudHarbor	AWS GovCloud — month -4	f	241480b1-17de-4c30-975e-722aa992e640	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2026-02-03 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2026-02-03 13:24:16.685
b6221343-23cc-4c3a-9921-9ae5bcb44894	b3b93f25-2072-4514-8820-74712a67ca64	308757.0000	USD	2026-03-05	Direct Labor	Apex Defense Systems	Direct labor — month -3	f	919f24b6-1143-4f55-b96b-067f50a59619	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2026-03-05 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2026-03-05 13:24:16.685
2936febc-bbf1-4d17-b0c5-2cce7158ad41	b3b93f25-2072-4514-8820-74712a67ca64	17433.0000	USD	2026-03-05	Cloud Hosting	CloudHarbor	AWS GovCloud — month -3	f	241480b1-17de-4c30-975e-722aa992e640	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2026-03-05 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2026-03-05 13:24:16.685
30e35134-e4dd-4108-9c19-10e1f1e9d47c	b3b93f25-2072-4514-8820-74712a67ca64	128400.0000	USD	2026-03-05	Subcontractor Labor	Vector Systems LLC	Subcontract — month -3	f	919f24b6-1143-4f55-b96b-067f50a59619	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2026-03-05 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2026-03-05 13:24:16.685
d872d568-e3ce-4a21-be91-add8efe1e31f	b3b93f25-2072-4514-8820-74712a67ca64	300838.0000	USD	2026-04-04	Direct Labor	Apex Defense Systems	Direct labor — month -2	f	919f24b6-1143-4f55-b96b-067f50a59619	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2026-04-04 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2026-04-04 13:24:16.685
8de93e88-aae2-4bb3-82ff-9237050bf11c	b3b93f25-2072-4514-8820-74712a67ca64	17122.0000	USD	2026-04-04	Cloud Hosting	CloudHarbor	AWS GovCloud — month -2	f	241480b1-17de-4c30-975e-722aa992e640	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2026-04-04 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2026-04-04 13:24:16.685
4211e938-f79e-4bee-9fb3-022b079b9ddd	b3b93f25-2072-4514-8820-74712a67ca64	292919.0000	USD	2026-05-04	Direct Labor	Apex Defense Systems	Direct labor — month -1	f	919f24b6-1143-4f55-b96b-067f50a59619	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2026-05-04 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2026-05-04 13:24:16.685
034d8c3f-ea46-43ac-94ff-4ca79185b165	b3b93f25-2072-4514-8820-74712a67ca64	16811.0000	USD	2026-05-04	Cloud Hosting	CloudHarbor	AWS GovCloud — month -1	f	241480b1-17de-4c30-975e-722aa992e640	2026-06-03 13:24:16.883	2026-06-03 13:24:16.883	2026-05-04 13:24:16.685	f1244511-9f53-4a78-b4d0-91851b50de2e	APPROVED	2026-05-04 13:24:16.685
\.


--
-- Data for Name: feedback_items; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.feedback_items (id, org_id, author_id, type, title, description, status, vote_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: feedback_votes; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.feedback_votes (id, feedback_item_id, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: home_widgets; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.home_widgets (id, org_id, owner_id, type, config, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: integrations; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.integrations (id, org_id, provider, display_name, config, status, installed_by_id, last_sync_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: invitations; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.invitations (id, org_id, email, role, token, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: ip_allowlists; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.ip_allowlists (id, org_id, cidr, label, created_at) FROM stdin;
\.


--
-- Data for Name: journal_entries; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.journal_entries (id, org_id, entry_number, date, memo, status, source, source_id, reverses_id, posted_at, created_by_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: journal_lines; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.journal_lines (id, org_id, journal_entry_id, account_id, direction, amount, description, sort_order, project_id, contract_id, cost_objective_id, cost_pool_id) FROM stdin;
\.


--
-- Data for Name: key_results; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.key_results (id, objective_id, title, description, start_value, current_value, target_value, unit, status, owner_id, sort_order, created_at, updated_at) FROM stdin;
f52ecd50-c19a-48ad-a226-50063db28f6e	f507c188-16bd-4dbf-b6a7-0cca11977b61	NIST 800-171 controls implemented	\N	0	84	110	controls	ON_TRACK	\N	0	2026-06-03 13:24:16.871	2026-06-03 13:24:16.871
1725da3d-3a9c-46ab-b558-02f620ed1ca5	f507c188-16bd-4dbf-b6a7-0cca11977b61	Open POA&M items closed	\N	40	31	0	items	AT_RISK	\N	1	2026-06-03 13:24:16.871	2026-06-03 13:24:16.871
20029bc3-83ac-46c9-a71e-b8a7b76bc774	f507c188-16bd-4dbf-b6a7-0cca11977b61	C3PAO assessment scheduled	\N	0	0	1		IN_PROGRESS	\N	2	2026-06-03 13:24:16.871	2026-06-03 13:24:16.871
87c59f66-1253-461b-9b70-2ec80258665c	34f61348-2cba-419b-9d74-5a957bc6129f	Average sprint velocity	\N	30	42	45	pts	ON_TRACK	\N	0	2026-06-03 13:24:16.878	2026-06-03 13:24:16.878
008385fa-63cc-49dc-b504-82770166aea1	34f61348-2cba-419b-9d74-5a957bc6129f	Increment 2 features delivered	\N	0	7	12	features	IN_PROGRESS	\N	1	2026-06-03 13:24:16.878	2026-06-03 13:24:16.878
904f0e5e-a7ea-4378-bdad-23bd4c90f390	34f61348-2cba-419b-9d74-5a957bc6129f	Defect escape rate	\N	8	3	2	%	ON_TRACK	\N	2	2026-06-03 13:24:16.878	2026-06-03 13:24:16.878
6a4811e1-53d0-4e71-a57a-0d6f20505126	c064d549-18f4-456a-818f-323ff3899c14	Qualified pipeline value	\N	4	11	15	$M	ON_TRACK	\N	0	2026-06-03 13:24:16.88	2026-06-03 13:24:16.88
4dd0afdb-473b-4714-ba56-f8ff8c936c7a	c064d549-18f4-456a-818f-323ff3899c14	Proposals submitted	\N	0	2	4		IN_PROGRESS	\N	1	2026-06-03 13:24:16.88	2026-06-03 13:24:16.88
\.


--
-- Data for Name: mcp_servers; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.mcp_servers (id, org_id, name, transport, command, args, env, url, headers, enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: meeting_attendees; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.meeting_attendees (id, meeting_id, user_id, done_since_last, working_on, blockers, notes) FROM stdin;
6e818564-2ae0-445e-b49e-b4b6101ff9c9	fb36761c-c8b3-4495-b037-6e1a88e2b365	f1244511-9f53-4a78-b4d0-91851b50de2e				
cfb91f19-bf51-47c7-ba33-44414a885104	fb36761c-c8b3-4495-b037-6e1a88e2b365	33f5b603-e18d-4a3e-87c5-3cf39f7173c4				
15a10f16-5bcf-4847-a93c-31944c3defbd	fb36761c-c8b3-4495-b037-6e1a88e2b365	241480b1-17de-4c30-975e-722aa992e640				
42a2bef2-ec3d-4d85-ba7b-5798445efc85	fb36761c-c8b3-4495-b037-6e1a88e2b365	919f24b6-1143-4f55-b96b-067f50a59619				
1b111131-08f6-4931-b92e-c34417114232	34a67f84-c190-4b0f-ac5c-b2788003c85a	f1244511-9f53-4a78-b4d0-91851b50de2e				
173156d3-70db-49bb-ba50-68f8911911d3	34a67f84-c190-4b0f-ac5c-b2788003c85a	33f5b603-e18d-4a3e-87c5-3cf39f7173c4				
6d4abf4a-31e0-4c72-a9eb-e264eb08aed7	34a67f84-c190-4b0f-ac5c-b2788003c85a	241480b1-17de-4c30-975e-722aa992e640				
c956e2ac-ecf7-4887-a166-1c60c36565ea	34a67f84-c190-4b0f-ac5c-b2788003c85a	919f24b6-1143-4f55-b96b-067f50a59619				
52c82a55-f333-4d44-a866-0b708e770354	3a980533-6fc3-4dfb-94ae-34182b155612	f1244511-9f53-4a78-b4d0-91851b50de2e				
7dfd87e0-c207-4949-80f8-8bcb32ff7f58	3a980533-6fc3-4dfb-94ae-34182b155612	33f5b603-e18d-4a3e-87c5-3cf39f7173c4				
61638777-e9c6-4893-b532-09d9f3171a18	3a980533-6fc3-4dfb-94ae-34182b155612	241480b1-17de-4c30-975e-722aa992e640				
684af80b-a913-4caf-bb77-ed235f8c3e7c	3a980533-6fc3-4dfb-94ae-34182b155612	919f24b6-1143-4f55-b96b-067f50a59619				
97f2d2da-b5d5-40e8-8212-26bd0c3e7d1f	cb64f567-34a0-4a8f-88f3-587f5c1948f2	f1244511-9f53-4a78-b4d0-91851b50de2e				
4fcc8ee0-ddb4-4edf-96eb-20235c18bd02	cb64f567-34a0-4a8f-88f3-587f5c1948f2	33f5b603-e18d-4a3e-87c5-3cf39f7173c4				
001c173e-da2e-4743-92d4-a9e9c26625c6	cb64f567-34a0-4a8f-88f3-587f5c1948f2	241480b1-17de-4c30-975e-722aa992e640				
a164a71e-a37b-4511-ab1d-1d16d73e0fc3	cb64f567-34a0-4a8f-88f3-587f5c1948f2	919f24b6-1143-4f55-b96b-067f50a59619				
d33d7c61-2671-4c08-9e34-7d3ad63f007d	2a0a7ec5-6930-41b1-87bb-524d936a4abb	f1244511-9f53-4a78-b4d0-91851b50de2e				
6fe64daa-b9aa-41d2-9a0d-f7e7692a5a9b	2a0a7ec5-6930-41b1-87bb-524d936a4abb	33f5b603-e18d-4a3e-87c5-3cf39f7173c4				
c9bc47e8-7931-4e8d-8e8e-96cbaaa7ba55	2a0a7ec5-6930-41b1-87bb-524d936a4abb	241480b1-17de-4c30-975e-722aa992e640				
2b378c46-81cc-4e93-bd6a-d7afaaf81e99	2a0a7ec5-6930-41b1-87bb-524d936a4abb	919f24b6-1143-4f55-b96b-067f50a59619				
e2a43c5e-2110-474e-bd10-2c202c80c1ad	ec42c6aa-c8aa-4333-a734-ab74c9253f1c	f1244511-9f53-4a78-b4d0-91851b50de2e				
cc7e4013-9d49-46e5-9ddc-4aa2ba606913	ec42c6aa-c8aa-4333-a734-ab74c9253f1c	33f5b603-e18d-4a3e-87c5-3cf39f7173c4				
7517e4be-2ca3-4504-9014-849030c512ea	ec42c6aa-c8aa-4333-a734-ab74c9253f1c	241480b1-17de-4c30-975e-722aa992e640				
af55f836-e097-4dca-b87e-056f45d463e8	ec42c6aa-c8aa-4333-a734-ab74c9253f1c	919f24b6-1143-4f55-b96b-067f50a59619				
6ebd8264-61ae-4c37-9e41-3d97feb5c413	f7aeba09-b4c9-4de6-8f21-3c984d9be63a	f1244511-9f53-4a78-b4d0-91851b50de2e				
41620043-821e-473d-98f1-f4ff2784b3d3	f7aeba09-b4c9-4de6-8f21-3c984d9be63a	33f5b603-e18d-4a3e-87c5-3cf39f7173c4				
3aff67c0-0aee-4f67-9f6a-ac210471d4d3	f7aeba09-b4c9-4de6-8f21-3c984d9be63a	241480b1-17de-4c30-975e-722aa992e640				
557087bf-0dcc-495f-a809-d32581bc3a0b	f7aeba09-b4c9-4de6-8f21-3c984d9be63a	919f24b6-1143-4f55-b96b-067f50a59619				
89bb09ca-9131-4c99-8c5f-5908e7912210	402c72d3-7c52-4a97-89ae-95c0cb701580	f1244511-9f53-4a78-b4d0-91851b50de2e				
5b7d7f11-0f53-46b7-802b-ebbc298b9a28	402c72d3-7c52-4a97-89ae-95c0cb701580	33f5b603-e18d-4a3e-87c5-3cf39f7173c4				
9c32b5fe-60df-412d-8e2a-cda74493ed4c	402c72d3-7c52-4a97-89ae-95c0cb701580	241480b1-17de-4c30-975e-722aa992e640				
bd81a48c-5fa5-429e-b1ca-6b39d0b39095	402c72d3-7c52-4a97-89ae-95c0cb701580	919f24b6-1143-4f55-b96b-067f50a59619				
481c3916-14f8-488e-843e-8b931a40a739	b2ea5bac-700b-46ed-aa1b-efcd815f2e2e	f1244511-9f53-4a78-b4d0-91851b50de2e				
7c86a153-74c1-4334-bfef-c1f3eb7b1436	b2ea5bac-700b-46ed-aa1b-efcd815f2e2e	33f5b603-e18d-4a3e-87c5-3cf39f7173c4				
74d68de2-ad8d-461e-95b2-a05ffb67a979	b2ea5bac-700b-46ed-aa1b-efcd815f2e2e	241480b1-17de-4c30-975e-722aa992e640				
802a7d75-027e-4e12-97b4-ca01f4cebcc8	b2ea5bac-700b-46ed-aa1b-efcd815f2e2e	919f24b6-1143-4f55-b96b-067f50a59619				
7404f0a0-40f2-40d3-9d08-071ba08858c4	0dd8707d-aa09-4149-afac-c2c53d9c1715	f1244511-9f53-4a78-b4d0-91851b50de2e				
fd44f7d4-d963-4ea0-8357-fff2e622c63b	0dd8707d-aa09-4149-afac-c2c53d9c1715	33f5b603-e18d-4a3e-87c5-3cf39f7173c4				
28ff2f98-dbc1-4c18-9f02-5ef55a72dee1	0dd8707d-aa09-4149-afac-c2c53d9c1715	241480b1-17de-4c30-975e-722aa992e640				
65663fe1-55b7-4669-b143-e2797e1337c5	0dd8707d-aa09-4149-afac-c2c53d9c1715	919f24b6-1143-4f55-b96b-067f50a59619				
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.notes (id, org_id, author_id, title, content, visibility, created_at, updated_at, search_vector) FROM stdin;
cd6c1a5c-5cee-4b96-b084-fab74648ae24	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	R7 throwaway		PRIVATE	2026-05-28 01:43:29.129	2026-05-28 13:02:13.783	{"tf": [1, 1], "tokens": ["r7", "throwaway"]}
ed5ab38e-bef4-4933-9d7e-0894e78e7fe3	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	CUI Handling Procedures (DFARS 252.204-7012)	All CUI stays on the GovCloud enclave. Mark documents CUI//SP-PROP. Encrypt at rest and in transit. Report spillage to the ISSO within 1 hour per the incident-response runbook.	PRIVATE	2026-06-03 02:37:49.247	2026-06-03 02:37:49.247	\N
cdf309a3-072f-4514-ab3c-919962091c89	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	Sprint 5 Retro Notes	ATO SSP package is the long pole and is now overdue. CAT II vuln remediation slipped. Subcontractor supply-chain assessment not yet started.	PRIVATE	2026-06-03 02:37:49.247	2026-06-03 02:37:49.247	\N
cc005334-0703-4c7f-8a7c-9a6d95dd2433	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	CMMC L2 — SSP Evidence Checklist	Evidence to close before the C3PAO assessment: AC/AU/SC control families, FIPS 140-3 crypto module validation cert, CAC/PIV MFA screenshots, Nessus remediation report, CUI handling SOP.	PRIVATE	2026-06-03 02:37:49.247	2026-06-03 12:54:54.426	{"tf": [2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], "tokens": ["evidence", "cmmc", "l2", "ssp", "checklist", "close", "before", "c3pao", "assessment", "ac", "au", "sc", "control", "families", "fips", "140", "crypto", "module", "validation", "cert", "cac", "piv", "mfa", "screenshots", "nessus", "remediation", "report", "cui", "handling", "sop"]}
46cb197e-006a-48aa-bfa7-f56897acbef3	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	System Security Plan (SSP) — Section 3.1 Access Control	Documents AC family implementation: least privilege, separation of duties, remote-access control, CUI flow enforcement. Evidence linked to SENTINEL work items.	PRIVATE	2026-06-03 13:24:16.889	2026-06-03 13:24:16.889	\N
a2944ab9-0626-4825-926d-ff6755994bd5	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	POA&M — Open Items Tracker	Open: 3.11.2 vulnerability scanning (CAT II remediation), 3.5.3 MFA rollout to remaining hosts, 3.13.1 egress monitoring. Target closure before the C3PAO window.	PRIVATE	2026-06-03 13:24:16.889	2026-06-03 13:24:16.889	\N
488d34f6-7ba1-42c4-9806-b20f2ce89aea	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	Increment 2 — Architecture Decision Record	Boundary architecture: cross-domain solution + mTLS API gateway. Data-at-rest via FIPS 140-3 module on the GovCloud enclave.	PRIVATE	2026-06-03 13:24:16.889	2026-06-03 13:24:16.889	\N
f108b818-00a2-4015-87a9-25740d8fe798	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	Subcontractor Flowdown Matrix	DFARS 252.204-7012 / -7019 / -7020 flowed down to Vector Systems LLC. SPRS scores tracked.	PRIVATE	2026-06-03 13:24:16.889	2026-06-03 13:24:16.889	\N
4ae14324-bfd9-43c7-af6b-c93ac8749687	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	C3PAO Assessment Readiness Plan	Evidence package owners, control walkthrough schedule, and SSP/POA&M freeze date.	PRIVATE	2026-06-03 13:24:16.889	2026-06-03 13:24:16.889	\N
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.notifications (id, org_id, user_id, type, title, body, ref_type, ref_id, read, created_at, url) FROM stdin;
a80ac190-2f3f-48c3-a75b-f024a6d9f608	0a086635-a2f4-47d1-a160-7437402b5973	47ed672c-c15d-41e4-ab63-08fb039d08d2	chat.mentioned	Alice mentioned you in #general	Hello @user!	chat_message	3bb9195d-2c55-4144-a2d0-b74374d2dff9	f	2026-05-28 18:03:28.265	/test-org/chat/d86f0ab2-dae0-4308-b5d0-e8172626b55c#msg-3bb9195d-2c55-4144-a2d0-b74374d2dff9
c8ddb9a8-73f2-425f-8dde-498d0dfc8489	0a086635-a2f4-47d1-a160-7437402b5973	47ed672c-c15d-41e4-ab63-08fb039d08d2	chat.mentioned	Alice mentioned you in #general	Hello @user!	chat_message	0113a1f2-949d-48af-b980-ca470fc8dd4c	f	2026-05-28 18:05:44.569	/test-org/chat/d86f0ab2-dae0-4308-b5d0-e8172626b55c#msg-0113a1f2-949d-48af-b980-ca470fc8dd4c
c748ba35-648f-4ed1-a7df-1b15cf8ae095	0a086635-a2f4-47d1-a160-7437402b5973	47ed672c-c15d-41e4-ab63-08fb039d08d2	chat.mentioned	Alice mentioned you in #general	Hello @user!	chat_message	6dfd82d2-9141-4977-8830-c2e89acdda09	f	2026-05-28 18:06:11.019	/test-org/chat/d86f0ab2-dae0-4308-b5d0-e8172626b55c#msg-6dfd82d2-9141-4977-8830-c2e89acdda09
f91845b3-c8cc-452d-a8a4-b835632a5972	0a086635-a2f4-47d1-a160-7437402b5973	47ed672c-c15d-41e4-ab63-08fb039d08d2	chat.mentioned	Alice mentioned you in #general	Hello @user!	chat_message	12cac8cd-e3b6-49a0-9200-dc73d285aa1d	f	2026-05-28 18:06:38.346	/test-org/chat/d86f0ab2-dae0-4308-b5d0-e8172626b55c#msg-12cac8cd-e3b6-49a0-9200-dc73d285aa1d
1e70a93b-be6f-47a8-9451-b2adf57a3ccf	0a086635-a2f4-47d1-a160-7437402b5973	47ed672c-c15d-41e4-ab63-08fb039d08d2	chat.mentioned	Alice mentioned you in #general	Hello @user!	chat_message	0e662dcf-e19c-49f6-b7c3-af973a3b839f	f	2026-05-28 18:07:03.054	/test-org/chat/d86f0ab2-dae0-4308-b5d0-e8172626b55c#msg-0e662dcf-e19c-49f6-b7c3-af973a3b839f
4c8ebfb5-ff58-466b-ad89-5cc36b4ca019	0a086635-a2f4-47d1-a160-7437402b5973	47ed672c-c15d-41e4-ab63-08fb039d08d2	chat.mentioned	Alice mentioned you in #general	Hello @user!	chat_message	3ac557e7-a593-4bc1-9cfd-362efa242665	f	2026-05-28 18:07:21.195	/test-org/chat/d86f0ab2-dae0-4308-b5d0-e8172626b55c#msg-3ac557e7-a593-4bc1-9cfd-362efa242665
b6c87be0-998a-42cd-a02a-fe6685544cd9	0a086635-a2f4-47d1-a160-7437402b5973	47ed672c-c15d-41e4-ab63-08fb039d08d2	chat.mentioned	Alice mentioned you in #general	Hello @user!	chat_message	e2ba7551-6140-43a1-bde0-3a5bcab23eb4	f	2026-05-28 18:33:52.363	/test-org/chat/d86f0ab2-dae0-4308-b5d0-e8172626b55c#msg-e2ba7551-6140-43a1-bde0-3a5bcab23eb4
a8012454-6408-4058-9f36-37eec8b8b572	0a086635-a2f4-47d1-a160-7437402b5973	47ed672c-c15d-41e4-ab63-08fb039d08d2	chat.mentioned	Alice mentioned you in #general	smoke-mention-mppu5q36 @user	chat_message	ac47ca71-2e83-44b6-b5b3-1abf76bdc20f	f	2026-05-28 18:37:58.718	/test-org/chat/d86f0ab2-dae0-4308-b5d0-e8172626b55c#msg-ac47ca71-2e83-44b6-b5b3-1abf76bdc20f
8c44f0ac-b533-4272-9d47-72e78a328532	0a086635-a2f4-47d1-a160-7437402b5973	47ed672c-c15d-41e4-ab63-08fb039d08d2	chat.mentioned	Alice mentioned you in #general	Hello @user!	chat_message	9c4b3824-8a23-410e-ba99-91ddc84fe3c9	f	2026-05-28 18:39:50.002	/test-org/chat/d86f0ab2-dae0-4308-b5d0-e8172626b55c#msg-9c4b3824-8a23-410e-ba99-91ddc84fe3c9
4358e8b5-3e09-43d9-ab63-acc3f6f34989	0a086635-a2f4-47d1-a160-7437402b5973	47ed672c-c15d-41e4-ab63-08fb039d08d2	chat.mentioned	Alice mentioned you in #general	Hello @user!	chat_message	03d3db38-935d-4b7c-b448-ca70ea248d11	f	2026-05-28 19:09:01.693	/test-org/chat/d86f0ab2-dae0-4308-b5d0-e8172626b55c#msg-03d3db38-935d-4b7c-b448-ca70ea248d11
a4e2d1f4-d9bb-4f15-a55f-85960f010aab	0a086635-a2f4-47d1-a160-7437402b5973	47ed672c-c15d-41e4-ab63-08fb039d08d2	chat.mentioned	Alice mentioned you in #general	Reactions test mppy0rlc @user	chat_message	5d112b6c-23b4-436a-878b-c67d60778505	f	2026-05-28 20:26:06.707	/test-org/chat/d86f0ab2-dae0-4308-b5d0-e8172626b55c#msg-5d112b6c-23b4-436a-878b-c67d60778505
8fa4cfe2-dc26-4e8a-bbcd-44d8e04c523d	0a086635-a2f4-47d1-a160-7437402b5973	47ed672c-c15d-41e4-ab63-08fb039d08d2	chat.mentioned	Alice mentioned you in #general	Hello @user!	chat_message	608f0c84-d834-4ddb-9d9c-365cef284136	f	2026-05-29 01:03:33.173	/test-org/chat/d86f0ab2-dae0-4308-b5d0-e8172626b55c#msg-608f0c84-d834-4ddb-9d9c-365cef284136
0eda1175-83e5-42ed-ab5d-45f126a16be5	0a086635-a2f4-47d1-a160-7437402b5973	47ed672c-c15d-41e4-ab63-08fb039d08d2	chat.mentioned	Alice mentioned you in #general	Hello @user!	chat_message	281e5e12-d2a8-4bc8-ab66-9fa7b36d99dd	f	2026-05-29 01:10:45.427	/test-org/chat/d86f0ab2-dae0-4308-b5d0-e8172626b55c#msg-281e5e12-d2a8-4bc8-ab66-9fa7b36d99dd
a89bcf8f-ab06-44d9-aa28-9170140e57e2	0a086635-a2f4-47d1-a160-7437402b5973	47ed672c-c15d-41e4-ab63-08fb039d08d2	chat.mentioned	Alice mentioned you in #general	Reactions test mpq87l5d @user	chat_message	77fb0a31-a6f4-4b40-a559-05066cfaf735	f	2026-05-29 01:11:20.54	/test-org/chat/d86f0ab2-dae0-4308-b5d0-e8172626b55c#msg-77fb0a31-a6f4-4b40-a559-05066cfaf735
092ab527-64a9-4bd1-b376-8036710978bf	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	83e86a90-6e51-498b-b8b8-c6ef124058d2	chat.dm	New message from Jon Rannabargar	hey	chat_message	b27f6c9e-0fc9-44db-ba18-ee0b94fcfba2	t	2026-06-03 01:31:52.158	/test/chat/69289fe9-7dcc-4196-b331-6b5ae5b54684#msg-b27f6c9e-0fc9-44db-ba18-ee0b94fcfba2
\.


--
-- Data for Name: objectives; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.objectives (id, org_id, project_id, title, description, owner_id, period, status, progress, created_at, updated_at) FROM stdin;
f507c188-16bd-4dbf-b6a7-0cca11977b61	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Achieve CMMC Level 2 certification	\N	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	Q3 2026	ACTIVE	78	2026-06-03 13:24:16.869	2026-06-03 13:24:16.869
34f61348-2cba-419b-9d74-5a957bc6129f	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Deliver Increment 2 on schedule	\N	919f24b6-1143-4f55-b96b-067f50a59619	Q3 2026	ACTIVE	65	2026-06-03 13:24:16.877	2026-06-03 13:24:16.877
c064d549-18f4-456a-818f-323ff3899c14	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Grow the defense backlog to $15M	\N	f1244511-9f53-4a78-b4d0-91851b50de2e	FY26	ACTIVE	52	2026-06-03 13:24:16.879	2026-06-03 13:24:16.879
\.


--
-- Data for Name: org_member_work_roles; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.org_member_work_roles (org_member_id, work_role_id, scope, created_at) FROM stdin;
\.


--
-- Data for Name: org_members; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.org_members (id, org_id, user_id, role, permissions, abac_rules, joined_at) FROM stdin;
88984c97-d67d-4603-9f55-72b7afc29599	5311b52b-ae85-4f92-95e9-ed9bb7b91b1f	8ec2805b-aaaf-4e66-9ab2-e03f49882cf4	OWNER	0	{}	2026-05-21 14:58:46.784
823440e3-9749-4388-a6c3-bf866bdcd0b0	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	OWNER	0	{}	2026-05-22 16:53:29.69
a63089ec-0940-4923-b354-5345151ffb61	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	83e86a90-6e51-498b-b8b8-c6ef124058d2	MEMBER	0	{}	2026-05-26 19:16:37.985
4b7afde3-6107-4cab-8aa3-b3be75694af9	5311b52b-ae85-4f92-95e9-ed9bb7b91b1f	0c7db1b0-6842-4f34-a845-84f41b1bf498	OWNER	0	{}	2026-05-28 13:09:26.134
03bb29b6-878e-4e79-b681-77025b30a30c	0a086635-a2f4-47d1-a160-7437402b5973	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	ADMIN	0	{}	2026-05-28 17:47:16.145
46e867e2-b365-428f-839e-2f746d5694d0	0a086635-a2f4-47d1-a160-7437402b5973	47ed672c-c15d-41e4-ab63-08fb039d08d2	MEMBER	0	{}	2026-05-28 17:47:16.147
07bf9c74-129a-4b87-9987-800a8a3eda7a	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	OWNER	0	{}	2026-06-03 02:37:49.158
c8ac6928-83d4-4c88-a8c6-79b763b09003	b3b93f25-2072-4514-8820-74712a67ca64	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	ADMIN	0	{}	2026-06-03 02:37:49.16
9cc3e083-b361-43c0-95ad-5afe8b2f879a	b3b93f25-2072-4514-8820-74712a67ca64	919f24b6-1143-4f55-b96b-067f50a59619	MEMBER	0	{}	2026-06-03 02:37:49.161
5d327878-ffe5-486a-9c24-8d6a6afdcca0	b3b93f25-2072-4514-8820-74712a67ca64	241480b1-17de-4c30-975e-722aa992e640	MEMBER	0	{}	2026-06-03 02:37:49.162
0fccd3ba-d6c0-4f72-a42c-7e4e81317a5e	b3b93f25-2072-4514-8820-74712a67ca64	59d381c3-1431-4a07-bc42-57b1d6cac472	VIEWER	0	{}	2026-06-03 02:37:49.163
a49e4d5d-52ed-4119-8393-6f99fb25cecb	b3b93f25-2072-4514-8820-74712a67ca64	7789efda-ce1b-4f2d-bec5-edf32f52e443	MEMBER	0	{}	2026-06-03 13:24:16.795
4c7537eb-8133-4e90-8fef-389a5c8b178c	b3b93f25-2072-4514-8820-74712a67ca64	118ec485-9938-4146-9d0b-943c007ffc64	MEMBER	0	{}	2026-06-03 13:24:16.797
514db8aa-957d-4901-89dd-9d6696d2228e	b3b93f25-2072-4514-8820-74712a67ca64	18198088-f46b-420d-a37e-0b7d8d968855	MEMBER	0	{}	2026-06-03 13:24:16.798
\.


--
-- Data for Name: org_security_settings; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.org_security_settings (id, org_id, mfa_required, session_timeout_mins, ip_allowlist_enabled, scim_enabled, sso_enforced, sso_connection_id, allowed_domains, audit_retention_days, created_at, updated_at) FROM stdin;
f536bf7a-7c20-4e23-bf20-d82f4d2e9064	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f	480	f	f	f	\N	{}	365	2026-05-23 17:51:42.135	2026-05-23 17:51:42.135
252b1bb0-ebfa-4506-9ecb-a7d505c13edd	b3b93f25-2072-4514-8820-74712a67ca64	f	480	f	f	f	\N	{}	365	2026-06-05 04:33:29.42	2026-06-05 04:33:29.42
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.organizations (id, name, slug, auth0_org_id, plan, logo_url, settings, db_connection_id, created_at, updated_at, theme_mode, theme_primary) FROM stdin;
5311b52b-ae85-4f92-95e9-ed9bb7b91b1f	Fighting Smart Cyber	fsc	\N	FREE	\N	{}	\N	2026-05-21 14:58:46.784	2026-05-22 16:43:29.013	\N	\N
7977bb8b-71a5-4117-8e09-f2313d7f7c4e	test	test	\N	FREE	\N	{}	\N	2026-05-22 16:53:29.69	2026-05-28 12:29:17.057	auto	#3B82F6
0a086635-a2f4-47d1-a160-7437402b5973	Test Org	test-org	\N	FREE	\N	{}	\N	2026-05-28 17:46:54.721	2026-05-28 17:46:54.721	\N	\N
b3b93f25-2072-4514-8820-74712a67ca64	Apex Defense Systems	apex-defense	\N	GOV	\N	{}	\N	2026-06-03 02:37:49.146	2026-06-03 02:37:49.146	\N	#1f3a5f
\.


--
-- Data for Name: partners; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.partners (id, org_id, name, type, status, website, contact_name, contact_email, contact_phone, notes, created_at, updated_at) FROM stdin;
e463f5bd-4ca6-4dd1-9427-dccca836976e	b3b93f25-2072-4514-8820-74712a67ca64	Vector Systems LLC	subcontractor	active	\N	R. Vector	contracts@vectorsystems.example	\N	Cleared software subcontractor (Secret). Teamed on SSEB.	2026-06-03 02:37:49.22	2026-06-03 02:37:49.22
7cdf94e8-dc83-4520-ad22-d37cc66ab1e8	b3b93f25-2072-4514-8820-74712a67ca64	SecureScan Inc.	vendor	active	\N	M. Okafor	engagements@securescan.example	\N	Independent pentest / assessment vendor.	2026-06-03 02:37:49.22	2026-06-03 02:37:49.22
8cf9350b-d239-4eb4-a495-e27ec6916785	b3b93f25-2072-4514-8820-74712a67ca64	CloudHarbor	vendor	active	\N	Sales	gov@cloudharbor.example	\N	AWS GovCloud reseller / hosting.	2026-06-03 02:37:49.22	2026-06-03 02:37:49.22
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.products (id, org_id, name, description, sku, price, currency, status, category, created_at, updated_at) FROM stdin;
b7c52ac5-5411-44d3-be7a-aa8b38d76632	b3b93f25-2072-4514-8820-74712a67ca64	Sentinel Cyber Situational-Awareness Platform	Real-time cyber SA platform delivered under the Sentinel program.	SCSAP	\N	USD	active	Capability	2026-06-03 02:37:49.223	2026-06-03 02:37:49.223
\.


--
-- Data for Name: project_members; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.project_members (id, project_id, org_member_id, role) FROM stdin;
39f1f9ba-a408-4735-ad43-5a244c7bbba8	d816eefb-9664-4e3e-ba50-f4fbb255d61d	823440e3-9749-4388-a6c3-bf866bdcd0b0	MANAGER
ddfd7927-69b8-4b55-a788-1b68372911fe	b1140265-ef3e-4146-857b-61d14d039b88	07bf9c74-129a-4b87-9987-800a8a3eda7a	MANAGER
\.


--
-- Data for Name: project_templates; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.project_templates (id, org_id, slug, sector, name, description, thumbnail_url, is_built_in, is_published, default_config, source_template_id, created_at) FROM stdin;
fc14e4a3-943f-479e-bce2-02978f290b5c	\N	software	software	Software Project	Agile development with sprints, boards, and releases	\N	t	t	{"cycleKinds": ["SPRINT", "RELEASE"], "cycleNavLabel": "Sprints", "enabledFeatures": ["goal", "milestone", "risk"]}	\N	2026-05-26 02:52:54.886
a0fe1a00-bf03-4a1d-87b1-dbe4e816bc2a	\N	aec	aec	Construction Project	Phase-gated construction with submittals, RFIs, change orders, and daily logs.	\N	t	t	{"cycleKinds": ["PHASE"], "cycleNavLabel": "Phases", "enabledFeatures": ["milestone", "kpi", "risk", "decision", "meeting_note"]}	\N	2026-05-26 02:58:17.441
00dac83c-c871-4da5-a5ab-1ab2a1357bd9	\N	ops	ops	Operations Workspace	Incident management, change requests, runbooks, and SLA tracking.	\N	t	t	{"cycleKinds": ["RELEASE"], "cycleNavLabel": "Releases", "enabledFeatures": ["kpi", "risk", "decision", "meeting_note"]}	\N	2026-05-26 02:58:17.465
0ee9a904-51ed-4db6-a0d3-d5fd6530ca95	\N	consulting	consulting	Client Engagement	Professional services with workstreams, deliverables, and milestone tracking.	\N	t	t	{"cycleKinds": ["PHASE"], "cycleNavLabel": "Phases", "enabledFeatures": ["goal", "milestone", "kpi", "risk", "decision", "meeting_note"]}	\N	2026-05-26 02:58:17.484
26ee8183-f1b9-4bc0-b8b0-4128a119769b	\N	manufacturing	manufacturing	Production Run	Work orders, operations, quality control, and inspection tracking.	\N	t	t	{"cycleKinds": ["RUN"], "cycleNavLabel": "Runs", "enabledFeatures": ["kpi", "risk", "decision"]}	\N	2026-05-26 02:58:17.505
caf35d32-77e2-4e67-a801-9bfebebe4744	\N	education	education	Course	Course design with modules, lessons, assignments, and grading.	\N	t	t	{"cycleKinds": ["MODULE"], "cycleNavLabel": "Modules", "enabledFeatures": ["goal", "milestone", "risk"]}	\N	2026-05-26 02:58:17.524
d6b39e2d-ba22-4481-a616-7496e1e8c24a	\N	event	event	Event	Run-of-show, vendor management, logistics, and risk planning.	\N	t	t	{"cycleKinds": ["EVENT_DAY"], "cycleNavLabel": "Days", "enabledFeatures": ["milestone", "kpi", "risk", "decision", "meeting_note"]}	\N	2026-05-26 02:58:17.546
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.projects (id, org_id, name, key, description, settings, archived, created_at, updated_at, enabled_features, project_template_id) FROM stdin;
d816eefb-9664-4e3e-ba50-f4fbb255d61d	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	R11 UI Audit	R11	\N	{}	f	2026-05-30 21:04:37.655	2026-05-30 21:04:37.655	{}	\N
b1140265-ef3e-4146-857b-61d14d039b88	b3b93f25-2072-4514-8820-74712a67ca64	Sentinel Program	SENTINEL	USAF cyber situational-awareness platform (CUI). CMMC L2 / NIST SP 800-171 in scope.	{}	f	2026-06-03 02:37:49.168	2026-06-03 02:37:49.168	{}	\N
\.


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.push_subscriptions (id, user_id, endpoint, p256dh, auth, user_agent, created_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: revenues; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.revenues (id, org_id, amount, currency, date, client, product, type, description, created_by_id, created_at, updated_at) FROM stdin;
63ea527c-ee67-40aa-94b0-f86e58722eb8	b3b93f25-2072-4514-8820-74712a67ca64	2400000.0000	USD	2026-02-03	USAF AFLCMC	Sentinel Program	PROJECT_BASED	CLIN 0001 — Base Year engineering	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 02:37:49.215	2026-06-03 02:37:49.215
86a7cb00-95a5-4a1a-8204-6140f5cad730	b3b93f25-2072-4514-8820-74712a67ca64	850000.0000	USD	2026-04-04	USAF AFLCMC	Sentinel Program	PROJECT_BASED	CLIN 0002 — Cyber engineering services	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 02:37:49.215	2026-06-03 02:37:49.215
e641923d-16b9-40de-b371-3e559b7d45ef	b3b93f25-2072-4514-8820-74712a67ca64	1200000.0000	USD	2026-05-14	USAF AFLCMC	Sentinel Program	PROJECT_BASED	CLIN 0003 — Option Year 1 (partial obligation)	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 02:37:49.215	2026-06-03 02:37:49.215
f2903f40-5040-4ba5-93d2-0596ffa49ff2	b3b93f25-2072-4514-8820-74712a67ca64	1112500.0000	USD	2025-06-08	USAF AFLCMC	Sentinel Program	PROJECT_BASED	CLIN funding tranche — month -12	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.887	2026-06-03 13:24:16.887
cccc2d1e-f383-4d36-a77a-cc6263e5e370	b3b93f25-2072-4514-8820-74712a67ca64	1112500.0000	USD	2025-10-06	USAF AFLCMC	Sentinel Program	PROJECT_BASED	CLIN funding tranche — month -8	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.887	2026-06-03 13:24:16.887
39d70faf-1e3b-4e1e-a3d7-8648a998edff	b3b93f25-2072-4514-8820-74712a67ca64	1112500.0000	USD	2026-02-03	USAF AFLCMC	Sentinel Program	PROJECT_BASED	CLIN funding tranche — month -4	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.887	2026-06-03 13:24:16.887
\.


--
-- Data for Name: saved_reports; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.saved_reports (id, org_id, created_by_id, name, type, config, schedule, last_run_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: scim_tokens; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.scim_tokens (id, org_id, token_hash, prefix, label, expires_at, last_used, created_at) FROM stdin;
\.


--
-- Data for Name: session_records; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.session_records (id, org_id, user_id, session_token, ip_address, user_agent, status, last_active_at, expires_at, revoked_at, created_at) FROM stdin;
787b6c7f-0c8e-41c5-9663-bb089bb23b55	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	26e7e51e42f139361313cbbdc135884a5f9db6af51d9764e5ac454ea561b9f8c	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-05-31 02:33:29.036	2026-06-07 02:33:25.757	\N	2026-05-31 02:33:29.036
d8d83f2a-4ff9-4e51-a7ab-20040f5ec4b2	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	ee83527f2a2df87d1fde22cabd44c5d19d608e6aa8725085970a95d2be3d4030	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-05-31 02:58:50.591	2026-06-07 02:57:09.586	\N	2026-05-31 02:58:48.435
c9d0132b-6212-4629-9192-25b5e185b379	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	34c124e8546eac057cbc69fb6144f003b190dffe2d5d512fd229aa717f207e6b	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-05-31 03:12:55.609	2026-06-07 03:12:40.031	\N	2026-05-31 03:12:55.609
f61d699d-e262-4f13-a593-87be287478f3	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	60518a7854598eb755ba14251f3aa01eddaa59bf0578c874dff61e4963eba43b	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-05-31 03:38:27.567	2026-06-07 03:37:51.077	\N	2026-05-31 03:38:27.567
090a0518-0540-4203-9c15-bb15d5bf2f7f	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	d7961df0bc4a3383756d6b29ba3ceec6aecd6a9c16e360b57357fb56ba1445da	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-05-31 03:47:01.392	2026-06-07 03:46:30.876	\N	2026-05-31 03:47:01.392
0ef33fa5-c725-48f3-a856-872f8b53e409	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	3af44688b2cded27b7b9dd9521aa21e3abe3ca95fd9c54ede3e489856ff8022b	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-05-31 03:48:33.935	2026-06-07 03:48:04.521	\N	2026-05-31 03:48:33.935
0e100420-16bb-4f07-a8f2-eb85cff1550f	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	a1f181a0fdaa0b5c70b62e789eb08c9f38305ae27b258a8356718cd757addba2	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-05-31 04:11:40.441	2026-06-07 04:11:24.861	\N	2026-05-31 04:11:40.441
2c344ae2-35b8-4627-a7cb-bcd6c45ad82c	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	1ac8c800c7cf67c27a34c79ef4bb0191440f474a8ac4ee880b5cd8c81c20944b	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-05-31 05:19:10.689	2026-06-07 05:18:58.929	\N	2026-05-31 05:19:10.689
4c0256ea-06cc-4ced-8050-1cf1b0412ac9	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	046faf6ba701b40f1587d6b200f82f8c28436449cab163a7ec91ff5045a42663	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-05-31 05:22:18.959	2026-06-07 05:22:07.737	\N	2026-05-31 05:22:18.959
9f57448b-0c11-4c30-a03c-9f6356118aab	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	1a0d6fd71c00efa7f5626e811e1c14b23996f04f60ceffcd0128af76a2a9bb83	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-05-31 05:22:42.163	2026-06-07 05:22:30.99	\N	2026-05-31 05:22:42.163
6370d6fb-e2f0-4eb0-bea6-8c17459f4676	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	7a5cb3b1e5d515e33c8681a85ca4398a5dd07270adf521914586a42edd699e3f	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-05-31 05:26:50.884	2026-06-07 05:26:39.685	\N	2026-05-31 05:26:50.884
8ef05cd3-2ae7-45d0-8073-3891ab2d1dcc	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	fcadd426048201b92396ad7fcaf234f4f09357726eec88f27d8d1922e0a86f73	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-05-31 05:27:14.008	2026-06-07 05:27:02.943	\N	2026-05-31 05:27:14.008
ef91cb58-4ed4-4258-bb2f-2b602deec688	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	45680cd05581b80b6b4659290b50f5c415b3aff49123dcd98c3736b545ec22f6	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-05-31 05:30:05.117	2026-06-07 05:29:52.766	\N	2026-05-31 05:30:05.117
9b98833b-759a-41de-9de0-7915d606cbe1	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	b374d6c32a0a3964edb1a1a1bfcb3d29b06732fa1e9677aac786e65f718a3b04	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-05-31 05:30:28.608	2026-06-07 05:30:17.567	\N	2026-05-31 05:30:28.608
1c4bba8c-9965-4396-ae6b-47ce12623fa4	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	7691e7e479e94c9dad3ccb94d31cb76047316f5d2b29b3af79e9ef2649ef0994	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-06-01 13:56:27.821	2026-06-08 13:54:10.745	\N	2026-06-01 13:56:27.821
25f797cc-5f38-45f8-85cd-a59cc9fd6da4	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	986d81c1857aa14f23135c693b7e4f29e946e112132718dad6ea8812e672ae9c	151.196.127.157	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	ACTIVE	2026-06-01 17:56:55.406	2026-06-02 14:27:34.926	\N	2026-06-01 17:56:55.406
ca4d069f-dbd6-435c-8c8f-b61129457924	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	781394cb392364ddfa9a8ee026b59733be116aa4074404925176ba21d6e93ba9	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-06-01 23:14:29.169	2026-06-08 23:14:24.822	\N	2026-06-01 23:14:29.169
ef6a8e16-e7b0-49b4-832d-56ffd6f4e602	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	d0e3cb12157b8bf7c5d0c639091be375cd47ff5ad9cd66d7649a198015c431be	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-06-01 23:15:42.765	2026-06-08 23:15:41.22	\N	2026-06-01 23:15:42.765
660e4963-fc33-411e-8cba-78d51510a15e	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	54f833b47aa91a4c9276759d222b2dd09cd5a78243f58767a557a13fa852da0c	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-06-01 23:19:34.256	2026-06-08 23:19:32.535	\N	2026-06-01 23:19:34.256
0a2cb408-bb6a-4359-b1df-542d701515cf	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	aa3e4aa44148c5aad92d8b727222569022210f01e0eaac7c185c9d470e211106	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-06-01 23:23:58.73	2026-06-08 23:23:57.063	\N	2026-06-01 23:23:58.73
756a1729-8bdd-40ae-8930-1d0f8fcb91ff	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	3a9c3b9b48dbe55fa9b9b92d689c0960bfd3a16dc4ea187cf52c781d3f39e6e8	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-06-01 23:29:40.989	2026-06-08 23:29:39.441	\N	2026-06-01 23:29:40.989
d32c0ba3-4110-4573-9d54-e58242764d3f	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	33463ce999822f35df781fba8db36f4df731f8cae2bf3c6716d6e5d845934fe8	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-06-01 23:43:46.358	2026-06-08 23:43:44.358	\N	2026-06-01 23:43:46.358
d6c0c361-5e2c-42a5-9917-6edb65b62093	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	8a58586560d47380a408ac4c8d9af94db85ac188456743cbb91ad85ed33964da	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-06-02 00:12:50.679	2026-06-09 00:12:49.135	\N	2026-06-02 00:12:50.679
bf5ed663-9391-4206-a921-299fc5ed4d5e	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	ec022fa88fbdf2cdff5a34d555b8bde53564a95017f621b529667ce799d6ace0	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-06-02 00:14:55.968	2026-06-09 00:14:54.289	\N	2026-06-02 00:14:55.968
f71e9400-d7ac-42cc-9187-ea85eb6d488b	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	b3430754ac6dd57d41597d7b46ef5c23bdba7704ad60ee05476b85fdc2552924	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-06-02 00:21:26.039	2026-06-09 00:21:24.359	\N	2026-06-02 00:21:26.039
4770c6f0-1fcd-437c-8c30-4a0edb9f3f3c	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	81d461753924613f9f7c456794912739c1327499e0a0c16cbfbd0448844e7667	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-06-02 00:41:10.421	2026-06-09 00:41:08.677	\N	2026-06-02 00:41:10.421
e94075f4-9b2f-4a69-bf8d-df835a2c2333	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	bc0c00427cdf539c4c5703ed51889465fd484fb2a373ae267e515b530807c3db	::1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	ACTIVE	2026-06-02 03:25:48.836	2026-06-09 03:25:47.057	\N	2026-06-02 03:25:48.836
381ec428-b286-46b8-b588-393ced9d4c45	b3b93f25-2072-4514-8820-74712a67ca64	f1244511-9f53-4a78-b4d0-91851b50de2e	f3cd12d85b4996693854e7fc3bbb5bcb73c7bdf63d9169d3d18363aacf76eb46	151.196.127.157	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	ACTIVE	2026-06-05 04:33:29.429	2026-06-09 15:10:08.161	\N	2026-06-03 12:56:27.84
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.sessions (id, user_id, expires_at, created_at) FROM stdin;
13dfcfab0b2ca9c1324a022897f09e1fff1de144f11e5d2581289fcba4b7a594	8ec2805b-aaaf-4e66-9ab2-e03f49882cf4	2026-05-29 19:38:43.06	2026-05-22 19:38:43.06
4311c24df33551cc855afee71feb8acbe46d12e173a9b90771940136d41d8408	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-29 23:02:04.687	2026-05-22 23:02:04.688
986d81c1857aa14f23135c693b7e4f29e946e112132718dad6ea8812e672ae9c	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-02 14:27:34.926	2026-05-26 14:27:34.927
6e1fc3657db13f2296347174aa75dfc35a6dd56b7a7b367eb1e06a928c7ccf1c	83e86a90-6e51-498b-b8b8-c6ef124058d2	2026-06-02 19:16:37.987	2026-05-26 19:16:37.987
6663c5d9384aab101befbb11d45b65ed636f0b9472423cf64b33488c28c74e01	83e86a90-6e51-498b-b8b8-c6ef124058d2	2026-06-02 19:19:55.225	2026-05-26 19:19:55.226
8da81cbb3026dc158e7357d8c2bac8335ea862af154eafad1190c8c917500402	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-02 19:34:34.867	2026-05-26 19:34:34.868
293dae671f32ee41d9a2213de1836c7d9175d461bbf4ef01663150229c027ffb	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-04 12:28:38.242	2026-05-28 12:28:38.243
6b9fa031-ee10-4cc0-a1e6-2f1a41f5c125	0c7db1b0-6842-4f34-a845-84f41b1bf498	2026-06-27 13:09:26.136	2026-05-28 13:09:26.137
00b4065a-f455-4e41-9453-a0a08e00a49d	0c7db1b0-6842-4f34-a845-84f41b1bf498	2026-06-27 13:20:56.973	2026-05-28 13:20:56.974
b27a67c9-29d7-41bb-81d7-cf7047553181	0c7db1b0-6842-4f34-a845-84f41b1bf498	2026-06-27 13:26:06.518	2026-05-28 13:26:06.519
6c6982fc-21f7-4b91-a40a-543372cb8e7d	0c7db1b0-6842-4f34-a845-84f41b1bf498	2026-06-27 13:28:34.101	2026-05-28 13:28:34.102
ac0de9c2-a5c3-4884-b53c-6fe1e16a00b1	0c7db1b0-6842-4f34-a845-84f41b1bf498	2026-06-27 13:38:38.924	2026-05-28 13:38:38.925
129a31d5-2313-4ae3-a7dd-d56ec0ced483	0c7db1b0-6842-4f34-a845-84f41b1bf498	2026-06-27 13:43:31.549	2026-05-28 13:43:31.552
774f9f015893a4b1bd66b6b1b17a784c5ee688dab52488fe913655ed7f5de4b7	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:02:45.823	2026-05-28 18:02:45.824
e25a55533fbc56bb7e41cf8b1706cc14ae78a99af6f464638138779762e9d84d	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:03:01.282	2026-05-28 18:03:01.283
59ab70d48a8a1f7e025aea8cab221478fcc99085ce201344b2ac84dfd333b62b	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 18:03:01.283	2026-05-28 18:03:01.284
fd581f1d924995eb5e243ac6363bfdf86a4b13d2fbd0b2842f19e62a30564807	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:05:22.111	2026-05-28 18:05:22.112
32598c8647acd2afc14cede0a74b03311db69fff69e97675a0dd746ccef22fa0	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 18:05:31.333	2026-05-28 18:05:31.335
24078e62c2cbb3b999d089ea94e4814198a8e0f4ce87e58ff2b70b50ddf690e8	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:05:31.321	2026-05-28 18:05:31.323
aebda7f2918e3e491b4dd1acdadb6bee7020c6d49d93954174290af9e24e733f	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:06:00.272	2026-05-28 18:06:00.273
18fbb761179785c8028e938805368bb3dcf6c63391f1b85647c3858e07196f6b	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 18:06:00.272	2026-05-28 18:06:00.273
d5d1008316f93e0fda18829657280311154f86d4a213dd4d58bb1cb8d65f9bb9	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:06:27.625	2026-05-28 18:06:27.626
7f3ec80852b125c705bca9128b341b45f40b64cc0f61ace019da4c850b07c1c5	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 18:06:27.634	2026-05-28 18:06:27.635
6a3e7c8baeefb8077b334fe063cb7320e4fb95b619057adeac150a63583a92bb	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:06:53.261	2026-05-28 18:06:53.262
ee9048b5c64b9d8d80945ed0ca12a897c7cfb003349cf065693b1a1856a83d94	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 18:06:53.274	2026-05-28 18:06:53.275
7e074751b0c4558343930fce43580b18d0e68e001e71b9f0c5831ade3783efab	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:07:11.325	2026-05-28 18:07:11.326
4a2059e590b91df3f9dc00cdbfe33579915e12c8bba9bd9d5ac299d940738b5d	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 18:07:11.325	2026-05-28 18:07:11.328
b655a502905823e8f47cb27a566f673a377952aabb3383f2ab0b4b78acc45486	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:21:03.564	2026-05-28 18:21:03.566
f43736c3f48554d58836ce08cf5ea24c353cca6b618fd2f01e56414899421104	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 18:21:03.569	2026-05-28 18:21:03.57
b1a35e1e28accdecb735d212694023acfbab138a8e5f40e2a6e58a6bb8eefb5b	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:23:22.206	2026-05-28 18:23:22.207
a04cc3aa6fdad646c7d761c5eb01f4f832c1872254462390ff48df604ea2ebfb	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 18:23:22.207	2026-05-28 18:23:22.208
c35320ed047996af51c43007d757751c95e54b727a70859b43e3270e4f5d7f6e	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:25:45.332	2026-05-28 18:25:45.333
f9ffe1859b2b5db0c3b9c703195a6d24b780712f8c55a2380f0513d60e0801b0	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 18:25:45.363	2026-05-28 18:25:45.364
f9e1c1f967ba2581a4ea45cfb28539ea1e7e9fbe889ca2fe96f431d6254f948c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:26:11.529	2026-05-28 18:26:11.53
25fa8147eb1b4fd51b4294d3aea36ac6cb5f692c29340877d1af209b6128a2c7	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:26:46.589	2026-05-28 18:26:46.59
90a1e7e32e7c7ed96e65321e52c10d232fa2cc8020906700a87cbca41ddf28c0	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:27:10.585	2026-05-28 18:27:10.586
e7ab8c14bcc5238746057ba2cdfad1e547e4f60384c7910094b8d668afb31703	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:28:02.936	2026-05-28 18:28:02.937
53b863bffcdaabd789409ecf35b76197aba6382ff13101425d0509f5d749ef08	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:28:30.277	2026-05-28 18:28:30.278
7aece70d49662a4c6bb1b4ae04de850747e0371a65db7ce483dc93be219ca7c0	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:28:45.613	2026-05-28 18:28:45.614
b7f6e987dd4917dfb57cbc9edb13331962c0bc00e9c9c2c94cf7a01bbe39b675	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:29:56.427	2026-05-28 18:29:56.428
694d30308270ae0492642e0290735f041485cf42877ac95be4b53006161964d1	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:30:30.636	2026-05-28 18:30:30.637
eb0d0612ae3d4d95d093df62ed541b1886ef1aa1abe704fd7eed3408e33366ef	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:31:05.611	2026-05-28 18:31:05.612
60ee932a4b21630c98ec229f6faded27123b94ead947ffe45bb06b45dc8bcc3a	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:31:27.78	2026-05-28 18:31:27.781
c00c19cce0cefd7e81a8a7295ec686ab7521ec69490876e71495f30329aa2083	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:32:19.897	2026-05-28 18:32:19.898
b0d3bd278ced8e505f7b444c577f2eb58b7c6153104f5938de765e0e0df6c4da	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:32:51.246	2026-05-28 18:32:51.247
c8dfc57d4d63b269e234127edc41e1c613cf44ec60323acc07c63e97737aedca	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:33:21.733	2026-05-28 18:33:21.734
149ce5937c99ff1e6e835ca86dde76658cb456e7d8c3bb5f45c2f64c2ccd70a5	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:33:41.599	2026-05-28 18:33:41.6
17effdfa22d929da847bd8e09668de8ac9827f716f83e12d9236aa75a64ceb64	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 18:33:41.606	2026-05-28 18:33:41.607
98298ecc05185f76da9ab91e42f67b210dba64d38a825a8f33ad1fdb0d480ee3	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:36:43.683	2026-05-28 18:36:43.684
275e9dffb73fdfcbef206865fa71734842caef00e3334a65a2a3c933ffb88424	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 18:36:43.704	2026-05-28 18:36:43.705
15e2131848aec568bf3f0df788e91809733681352ca6fe9530db2dcc4efdae9f	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:38:53.121	2026-05-28 18:38:53.123
99b64f62519ac5cb539fd485608177262cc7e86c78ac23e31bc5f34f7f31473d	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 18:38:53.143	2026-05-28 18:38:53.144
d33d51ece3b0b51062d901f6c887fed50b819d9148b703ff82b3a7d58aa26ad7	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:39:38.784	2026-05-28 18:39:38.785
347adc94ddea354a50432e1a8c82d89d406bd73b62f45e6cea8a7c16e5e30bb2	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 18:39:38.785	2026-05-28 18:39:38.786
61e31afcf323a1cf64e8c4101210b8444f6b02aa2b59ede88c9423c3a88f907c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:40:10.004	2026-05-28 18:40:10.005
e1ac7b739597bad8a7885a9df9a4a27c59e050d764fe0056ef2614df9c1a29d8	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:40:31.26	2026-05-28 18:40:31.261
16e71defefd4ee5f96f73eb1265b4ee11f1e82a278748071443c4fae38ee4cba	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:41:04.598	2026-05-28 18:41:04.599
0d5919f4e59e277309f6edbec984e0c70b9ef5e1588cccc4aa7e8a5e310cf340	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 18:41:04.629	2026-05-28 18:41:04.63
cd4120547200c28b8799f759aa4c3b03910b6d3b2fdb9ee8445bb0fbe020ac7d	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:41:25.099	2026-05-28 18:41:25.1
628c69767a6a8c4c56520f5b6c6adf623f5494780da4fc7746e6b8aa3438ddf9	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 18:41:25.12	2026-05-28 18:41:25.121
de482c85dc3073b18c1feffbe69ec3e4e3244466a03094a3ad7969c17a917e33	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:42:07.353	2026-05-28 18:42:07.354
264e6257a63796d63db6b37dc00ef3d4022d93e83f740fd14a8d8d5080bc397a	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 18:42:07.378	2026-05-28 18:42:07.379
1dc892bbecb71ae4dab8330614b08717d3e02d33d3117227d2f75a77aa877f45	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:42:58.245	2026-05-28 18:42:58.246
ba2edb1521595da571d879c62d01805dd9bae67d3c342ecafe79a4c47d259eff	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 18:42:58.266	2026-05-28 18:42:58.267
951c72ec08e49c78cdfef31a4e4bfc721854de758a4b3de315b46731f6c45505	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:44:32.763	2026-05-28 18:44:32.764
d52a4bde045bbeb34477324a2d2243eb337d1d4bc0a20c451b80400a8cbeb0ec	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 18:44:32.785	2026-05-28 18:44:32.786
af0c4d38464ead37c4c6fe0171d313a94a9287e1f82afdf476864398d9b746bf	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:45:05.415	2026-05-28 18:45:05.416
3deb4b7257eea71949906663a0b479c3e69c2e1f41804addca739c815f46777f	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 18:45:05.441	2026-05-28 18:45:05.442
c16ba3fe210f8b2a1d09e1d1328127166e20e05aac8509da6797266e3b22d695	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 18:59:47.487	2026-05-28 18:59:47.488
73c49064a8a7ec540d30efe901f29aeba6c957d612e29fd602258aeae47ec16a	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 18:59:47.53	2026-05-28 18:59:47.532
cb28984ed57da57ce62dc06276c1eeace686659cc6b2a0cd9a311d3ef57ef378	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 19:00:26.766	2026-05-28 19:00:26.768
5e5a02d10f5116c0117c1734bc6199b1074da2a240cc914c1d3886c417e4d203	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 19:00:26.81	2026-05-28 19:00:26.811
bdea788c6bde7e7484f105baaf1f7b1a24766c8c436cccd527be04490a7c2c1a	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 19:01:12.41	2026-05-28 19:01:12.411
bf940aba63df3239241e0e77eb745c290da47e0b0ad7d54c4f9a0a9951714c0b	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 19:01:12.442	2026-05-28 19:01:12.444
7fd5e44c5ac6ac0989bce7818574b87c61479dffcebf73448f1ec5ae9274dd14	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 19:01:48.634	2026-05-28 19:01:48.635
550b8a157d6c9bffa6eb4cfc735c17570f2613155d984ccd08f415d26271800b	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 19:01:48.662	2026-05-28 19:01:48.663
8ca646ca9120b827100d195b9050c0c146ab17883aa4070a6ae835a843fba8fe	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 19:02:21.262	2026-05-28 19:02:21.263
87dc77137c805f590a35219f112978b0dec13dbde3161e571f08d5655c1a364f	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 19:02:21.285	2026-05-28 19:02:21.286
1591d67ca23c562b1f28c168583687f5ab36ae5184494cf6cba2d1cbe5c75da0	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 19:03:15.294	2026-05-28 19:03:15.295
54c69110ffc00c115dd97f29c765f8e65de9e94ae4e76ed8a1045dc60e95704d	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 19:04:21.619	2026-05-28 19:04:21.62
83b90a58d9acc6781bbafa92dae6c2247618ea8c28f6ee2f64fa493b24a820c7	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 19:04:21.645	2026-05-28 19:04:21.646
3867b8470ea2c822ab3898e5497c79709f57fd5194be9dd03bc0a4c15e3eee94	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 19:04:53.816	2026-05-28 19:04:53.817
1b7ae02860c331cea47cd100ee40ac6eeaf11dc014d3006f86e19ef89e85c7cf	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 19:05:15.81	2026-05-28 19:05:15.811
387bf1d1dc29487f84b4e3a748f8f09936fa729815fd7f947e83e331b3743d31	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 19:05:15.831	2026-05-28 19:05:15.832
6e13e974560e62442e28aca14c6e82449bf8d1d2183a3d61d5ea05a5c8315284	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 19:07:59.447	2026-05-28 19:07:59.448
6d2e46687341b570e725d65a6c217ae2ced7907527008e8087a547cbef3dcd7a	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 19:07:59.47	2026-05-28 19:07:59.471
5cf5aca30315b3509c5ff392adf26e30bcbe02282c10e4ae240afab220f8db86	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 19:08:49.594	2026-05-28 19:08:49.595
18cf349967acc59243afe906f04df7100e71c9405a94417b1d2c7ee6cbc404e9	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 19:08:49.595	2026-05-28 19:08:49.595
7a95ff3f500595725e7dd632344f3430d358b57d975254085f282ce250a3fb6d	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 20:25:33.088	2026-05-28 20:25:33.09
b2734529972008ffcc47bcefd6cfcfb2bd021e75afb186c5478fb1d61d1586e2	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 20:25:39.464	2026-05-28 20:25:39.467
9228ff993583a08ba02bfc46c46cb782363dd451cc8ca272712cb5c402c697d8	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 20:25:39.463	2026-05-28 20:25:39.467
d17944de93b7aaafcd6d1803d92689e91392595fe25d6168ee435eb75f6c6b14	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-04 20:26:08.746	2026-05-28 20:26:08.747
12110d4b88f984ae5ae97340595f03776efcdbba47fc5bdaa1701e4a77338a58	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-04 20:26:08.747	2026-05-28 20:26:08.748
6fab942133acb23e31782a8d88ee0943cea5b0083ba99de181b266f1e647b6e1	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 00:47:01.015	2026-05-29 00:47:01.016
276159e7503a41b6df995602ea3422876e2637a83df3398f92dfdb60c05572bf	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 00:47:01.061	2026-05-29 00:47:01.064
3ca97e7b7e43657ec12d0531f2079f031ee5ab517b3819dcdb0e2dbfbf5d8310	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 00:47:35.079	2026-05-29 00:47:35.08
e10d5bdd6c74b41cdd47a76174d4ab1d324e3fedd419f0f63b39def243f38039	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 00:47:35.101	2026-05-29 00:47:35.102
1ee81565dd7ae0b417001d4904faef1926f96fd93eb667cfaaa23372e07dcc45	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 00:47:44.078	2026-05-29 00:47:44.079
de0606c520d6c1529eeefa885a0febe66cf75a3b4cb10d440f1ef152fbfef4f7	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 00:47:44.118	2026-05-29 00:47:44.12
1857334f6b792d0549d686be8718b8ababd0a9139db0f015a16e101fc3d3f755	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 00:48:38.798	2026-05-29 00:48:38.799
332c60c72e8257b8b48dcab07ef80aa6104f6c98c19318d9980bc52cae048e2e	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 00:48:38.82	2026-05-29 00:48:38.821
d6ea8a71cf483b134c21573172882785ecc09689b49fcb2df198423fe3f3d04b	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 00:48:55.627	2026-05-29 00:48:55.628
030780e33efd0b695fb2de6bdae101113b9d9bc6933e0e174a7e7d563b07b5e2	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 00:48:55.649	2026-05-29 00:48:55.65
e88b9b9b4623eccd3c8ffd4411fbec08f548759df46f5ac269f5df5e24a6ab9e	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 00:49:05.04	2026-05-29 00:49:05.042
f35eae2a7b104d2cdcbd2d3189fed49bcee807d5d07e8fa83b8c1e938704bf25	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 00:49:05.074	2026-05-29 00:49:05.075
a9feb100be6a01741f98618440556513dac0e4101cf58d64b777e2038c96d030	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 00:49:16.709	2026-05-29 00:49:16.71
6c54c7d24e1d22ec310b3820c2ab8c838de45db206415322cd8b967874c43a5e	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 00:49:16.734	2026-05-29 00:49:16.735
4b82d2a57e4c5cf55363d4a603d13ff344c3d1a788e41b30777488611774dd84	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 00:49:51.929	2026-05-29 00:49:51.93
90bee5e2ee54fada6466e4cb54b1d76941ea236286a24b88f67541d52fc4a057	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 00:49:51.949	2026-05-29 00:49:51.95
086106d74a5e2305de5d1ae88eeb8b70bd292396aedad2b57a70fca55ac3765d	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 00:52:02.264	2026-05-29 00:52:02.265
3df096a3a5f234d0f13beb741a15fcd0ce84a1e74b66ae53321e99fd30a4055d	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 00:52:02.29	2026-05-29 00:52:02.291
7971e2a98bf7c28d8af7390c7bb0f63b5dae293edab9095b5f57db78093fcee7	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 00:52:43.968	2026-05-29 00:52:43.969
bd9b170ef37e0a580650b80a6091c4d997c834ba8bcce5a91659ce3638e3d96a	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 00:52:43.988	2026-05-29 00:52:43.989
1d1d7dd48aff42a091dd9d165b4c75b2905f154644d20a5b7e8bd00b4b74cf4d	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 00:54:12.229	2026-05-29 00:54:12.23
f90e0138d2821835fc0d376a375e4acdf262b353a926510ac1753aeb29c81974	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 00:54:12.252	2026-05-29 00:54:12.253
31059562efd265b7e48c061b7b3a6989f22b772db02eeb478874cd22b89fa757	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 00:54:47.787	2026-05-29 00:54:47.788
42f230bf132029ca7e2c0b51cbe4e71913e306b0cf867c28213871600200486d	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 00:54:47.805	2026-05-29 00:54:47.806
966cc0421c9766149cb38fcb4f070ca7c09c94b412765822c1fef0f8fbd20c3a	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 00:55:23.951	2026-05-29 00:55:23.952
a3eb1a3cdc480eb11825f9ec1dd6ef5a0f443b05b934af5f408509aa408985c8	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 00:55:23.97	2026-05-29 00:55:23.971
43d5b3621a8dd7e4841863137de04608cee72ed7f0084acf210318571651ee1f	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 00:59:18.637	2026-05-29 00:59:18.638
6f0055fee18433b9f364412e9f6f1b7d7096b50a0e4a5567cac92e029f69ca0a	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 00:59:18.658	2026-05-29 00:59:18.659
fc8bdee2b744383aa9b1d2cf0922df2f63e79d645c6abd6be6c166ed59a6fb93	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 00:59:30.88	2026-05-29 00:59:30.881
84dd849644e4a41d937b29bfad6412b87b881c82e38b0a5c5548002fd68710d9	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 00:59:30.898	2026-05-29 00:59:30.899
76e795c224e37d5bfbbefe991b750dcfa84d385f7e2913483d36b26814f5333f	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 00:59:52.391	2026-05-29 00:59:52.392
99e60e7810df5f9fdc83774b9367bd9179956f1ac4e8d218af952b4111a7396d	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 00:59:52.41	2026-05-29 00:59:52.411
8aad1215ed48d98a3c6fd4147fd6ed7dfb1e4a5930b34ffe0bd5817fc6b259fc	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 01:00:22.098	2026-05-29 01:00:22.099
70133f2afc6debb816042605baf7ffa5b84f476c13eeaf1912187971754b1b3a	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 01:00:27.708	2026-05-29 01:00:27.71
3afb43abaa48c8858d237a49d952fbe991ed22d1041cb866a7b948ccc514595d	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 01:00:56.961	2026-05-29 01:00:56.962
665519486ea9931dca39c0921927b22a4a22e34b390d624c47dc346bc4b9b6ae	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 01:02:44.412	2026-05-29 01:02:44.413
5cee3b86dc3a33d1c27da6c3451da150ca2953747a55d65531721397fd3a6eb5	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 01:03:25.949	2026-05-29 01:03:25.95
9dccda528ed541aaf79abd5d0c708aa4467dee438bab668b80f8d51dfa1cc9db	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 01:03:25.95	2026-05-29 01:03:25.951
83dd615dd7f6d3da6a56609f5361aa066feb8e8d842ef01a136ae3cba27b975f	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 01:04:49.026	2026-05-29 01:04:49.027
148e7f0658a09ae550643ffa9e5c7bb1bb274a6e70b5e8e36a8f88c6b23559a6	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 01:06:32.305	2026-05-29 01:06:32.306
0b2185b01e1900831d274f661b71688c613358ee70764938055acaa678ca822e	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 01:07:09.419	2026-05-29 01:07:09.42
e0b71b8b01ecba70e04adf5a8eb59868a493f6d111e5a2dbe3636d5894b7ebb5	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 01:07:09.438	2026-05-29 01:07:09.439
9dc6d04d936eac7e2a32ea1ab04a77f811ed32585b201d8d34b3e44a7bbc11f9	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 01:09:41.021	2026-05-29 01:09:41.022
ec384943e38c346070576834cca15851a6a947c9aab8a889f15f1bb55f06c8f1	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 01:09:41.044	2026-05-29 01:09:41.045
9843974a6c01ce9e3ce9b665c6c496ac8a849f1a169896949289ef430f50bfd1	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 01:10:03.203	2026-05-29 01:10:03.204
e40dca8e10304ff110857f56f1b0b9528fc456d96bdfdc4846c83b72109c1e03	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 01:10:03.225	2026-05-29 01:10:03.226
ca9658ab06a4cc31b9c51173b94a2e05df2ec3501ef9eae2c36e799e0940d038	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 01:10:18.748	2026-05-29 01:10:18.749
0b411673e888eb85c01b7a34d94a5b94a5d48bd40c5c958e98f468c5e3980cb7	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 01:10:18.762	2026-05-29 01:10:18.763
8c6e1b4641a49920b9f9ef61a2cff21ec086390928ea2e7dd4ce8c05ddc4a025	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 01:10:27.644	2026-05-29 01:10:27.645
41f9086039403a8887936ec4f490945ece12140095955b850c94aaf07b0c024e	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 01:10:27.677	2026-05-29 01:10:27.678
a25c949fe136b12bdba9ffe6e36579b5013d06cf6e05c209232c2df4307ef5a1	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 01:10:38.844	2026-05-29 01:10:38.845
1d4cd2ea38102ed15ead034ff49b2125cb9105ef36fb4a755d0c8e562d899e9c	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 01:10:38.844	2026-05-29 01:10:38.845
e728ae756ffb8a96c3980c17dd5fbed515e39784dde3c2ed2aa1134eafc31a4b	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 01:10:46.407	2026-05-29 01:10:46.408
9c08a3be48d6a5d43865df4564ab6ba4a528394e56173a2f0fc799706541e29c	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 01:10:46.426	2026-05-29 01:10:46.426
10ff8acc3ec036e1f5090c1905a869d0f0c06ea4f2f177e3436a473c4edd382a	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 01:11:01.329	2026-05-29 01:11:01.33
6b2e0f4a84ffdefb6d4f50eb9e19361a917b5de39e61e7353979d1903677c939	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 01:11:01.343	2026-05-29 01:11:01.344
7baaa614d3b4f1249c08ce11184d35683a245b5f3b507ea7f8d023229740a783	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 01:11:10.572	2026-05-29 01:11:10.573
4bfe36776b47a36de5001da8e1183c5f4e410d64d47167ff3a55bf1eed65e2cd	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 01:11:10.591	2026-05-29 01:11:10.592
3cde48dc92f117d73417dae38f7a5d44ef9906e81bb415acf0f78183ece6e396	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 01:11:14.368	2026-05-29 01:11:14.369
2f946468383b4f0d820e7d527445ed54d53a1fbe6a232fae97eb54211852a57d	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 01:11:14.369	2026-05-29 01:11:14.37
a204eb1cba4438ca23d42a6cea9947b3afac6418d5e45c8213cfa16aeeae6c4b	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 01:11:21.393	2026-05-29 01:11:21.394
57be405b7480c8aa73ff75ac61aa4fab6c02d4636af040b07c6802c699bc4439	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 01:11:21.394	2026-05-29 01:11:21.395
9fcedbdb78db39650a17cd48d336965807b443f30094d2310564e926e385c267	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 05:14:44.653	2026-05-29 05:14:44.655
4073bcbf1af7d5d09e89f2cd2a2cabe0445ef9dafbbe4cafe01e9b7f17bc7fa5	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 05:14:44.693	2026-05-29 05:14:44.694
53057d8aec74d156fef7090ab05dc45085b275d24cd5557f74b14409af31977c	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 05:15:13.718	2026-05-29 05:15:13.719
30aed0901c4679b2af2c46ef46b6bf02ba7cfae7369f6aca34fd7a2e3d8ed8b4	ee850f7d-f9e2-47ad-9d78-01e4a8175f17	2026-06-05 05:15:30.806	2026-05-29 05:15:30.807
a326ba000fa13c7dab267e0efda0925e35a7557d51b782f87c71aa3635e437cd	47ed672c-c15d-41e4-ab63-08fb039d08d2	2026-06-05 05:15:30.82	2026-05-29 05:15:30.821
c64e2598c5748bee5773412652e27583f4b3b3b620188442e1008cd96e6deedc	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-06 03:25:51.68	2026-05-30 03:25:51.681
1bfa6a04cc6125cab91ab133259be89a71e11d072e3323191fb7b553ed1feb58	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-06 21:42:56.251	2026-05-30 21:42:56.252
fe00893433d88fe9b37a4c5a5e0a818ea5e52ac892f952bc07034412732ba794	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-06 21:46:53.734	2026-05-30 21:46:53.735
7e08fd487cd2a6d1bcae558691a72bb6670392cb99b898165e9f397e94911388	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-06 21:49:25.91	2026-05-30 21:49:25.911
2f9e73b3d858411fdac722615737309b18f3c113f6b8f3a904cd260a5c567944	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-06 21:59:32.302	2026-05-30 21:59:32.304
b0958798e2fa0034c1df58b12dc0eca87bb3e49f1b30ea6297331ff92b481ebb	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-06 22:06:40.441	2026-05-30 22:06:40.442
7e2f92f1b3b165f062d5a793bb00c6f8f1a7164e64964ea9c41c9caf7bdd8c14	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-06 22:07:44.637	2026-05-30 22:07:44.638
b406fb78aef55114280e7fb2c5cb2adc7e6d6dea8e7fc6958576a25064925d2d	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-06 22:08:39.61	2026-05-30 22:08:39.611
543fc6fb298d3bf5dace418ec90e75a8e8041d035e9cae636d8fa68fb3418fd2	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-06 22:09:26.804	2026-05-30 22:09:26.805
0d866b98fbad826c7fed49882cc75dade6f08af03086d7006ad052debe7b7507	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-06 22:10:01.833	2026-05-30 22:10:01.834
4fb0a7b747b646821b8b409e66423b1c951666e129db4c33b3d7a7016b2de985	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-06 22:11:11.103	2026-05-30 22:11:11.104
9291685c30ca758ba9b6df7e325108c0208794cce9799e22cd8a27929db79f15	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-06 22:12:00.481	2026-05-30 22:12:00.482
3e63cca62b491af2d931624148d416921c07f845c1f698cb455b727b5a1de701	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-06 22:20:34.78	2026-05-30 22:20:34.781
be641c4f7b974c60ce73a0c16b34819108a6f8259135b5746aa4edc6a6a4bc6b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-06 22:22:05.984	2026-05-30 22:22:05.985
bdedf9021edff618438f7d70766f113ca75a15e9715deb0f89014fa87e6a274e	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-06 22:38:04.816	2026-05-30 22:38:04.817
7e00327bf49203daee42bd210d1be3a851dccaf026f49284d3498617e428f8e0	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-06 22:40:17.459	2026-05-30 22:40:17.46
eeb9374d2b9c606adf895748cea36c48c0963795cf2f9be2e1c12dd660f2df02	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-06 23:34:28.747	2026-05-30 23:34:28.749
d876ff984e56799d5de275bc998bf92456339676e16bbc1a0cd4ac66633edbf4	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-06 23:34:46.901	2026-05-30 23:34:46.902
3026abc123f294de40ba291c9ebf442f66db2bdac1de27b07ba022e15678750d	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 01:13:24.238	2026-05-31 01:13:24.249
0b1a2f169a6491937ecff7b0d26a1e0deb6c8e693bc5fe2f67a782b5c8c1feca	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 01:18:08.781	2026-05-31 01:18:08.782
a961c2f61bcfb395a351f8d7341dc0c2d44d2c4d8b64b4718b47916b85c43bf8	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 01:18:35.756	2026-05-31 01:18:35.757
99031a34428d0463da3d901d7e5c74011602ffe2ca3a8c3cc89b7bdfb30ca433	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 01:19:53.78	2026-05-31 01:19:53.782
8d41dd8d4bf82951a7c6b7a03006368672ec84283ef941a914dd66d5e469587d	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 01:20:41.65	2026-05-31 01:20:41.651
4e7f296a1a1d91534a6e38fe3c30c724595db7dc93c86bcf039b39cded5a579f	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 01:21:40.843	2026-05-31 01:21:40.844
f532bb6905f8e9547c750ef9740c4507127f19b6462fc73b85fe253436466191	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 01:30:47.969	2026-05-31 01:30:47.97
acf8930684b5334b0a4a87f96e5edeec2e3c57667ff30362af646fdf183475ea	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 01:31:47.183	2026-05-31 01:31:47.184
3b7dc45f474ff50fc7ba9e6f3db1a402885a34c1ae1856ce7da7f9382b18f3a1	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 01:33:19.677	2026-05-31 01:33:19.678
f57e3ee29d8a22805bc79e2964731385d0c46686d293a1bd09d06fe921c22e5b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 02:26:45.325	2026-05-31 02:26:45.33
b464523ddf0332d1a1db806bd14daa30f18e109fadb6eaecefe4d1abf1d0ef7c	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 02:31:56.639	2026-05-31 02:31:56.64
26e7e51e42f139361313cbbdc135884a5f9db6af51d9764e5ac454ea561b9f8c	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 02:33:25.757	2026-05-31 02:33:25.758
ee83527f2a2df87d1fde22cabd44c5d19d608e6aa8725085970a95d2be3d4030	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 02:57:09.586	2026-05-31 02:57:09.588
cacbdd454f05c1054dbacce82465049210bf7e49e9194bf70a3945479f454da5	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 03:01:14.579	2026-05-31 03:01:14.58
34c124e8546eac057cbc69fb6144f003b190dffe2d5d512fd229aa717f207e6b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 03:12:40.031	2026-05-31 03:12:40.032
b9aa933cda12a77a8443a8c98e6b4594388d6f6fe9cbcb3f2ab0dfb336b43841	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 03:14:13.952	2026-05-31 03:14:13.953
03b10b6349374be6e938cf7f67ff1be88d30d31076eb6fc302840c469dafddbb	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 03:16:45.127	2026-05-31 03:16:45.128
f2fef60340e1367daa603bb3ec5e9d40fe95e4a3740e381f58577d7dc6c99178	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 03:18:26.936	2026-05-31 03:18:26.937
0f3121c4d37af93ec0bbdfba4782e8dcc027d00002cf1cc7b6f37ac0772351f8	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 03:19:30.617	2026-05-31 03:19:30.618
60518a7854598eb755ba14251f3aa01eddaa59bf0578c874dff61e4963eba43b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 03:37:51.077	2026-05-31 03:37:51.079
d7961df0bc4a3383756d6b29ba3ceec6aecd6a9c16e360b57357fb56ba1445da	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 03:46:30.876	2026-05-31 03:46:30.877
3af44688b2cded27b7b9dd9521aa21e3abe3ca95fd9c54ede3e489856ff8022b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 03:48:04.521	2026-05-31 03:48:04.522
a1f181a0fdaa0b5c70b62e789eb08c9f38305ae27b258a8356718cd757addba2	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 04:11:24.861	2026-05-31 04:11:24.863
1ac8c800c7cf67c27a34c79ef4bb0191440f474a8ac4ee880b5cd8c81c20944b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 05:18:58.929	2026-05-31 05:18:58.93
046faf6ba701b40f1587d6b200f82f8c28436449cab163a7ec91ff5045a42663	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 05:22:07.737	2026-05-31 05:22:07.74
1a0d6fd71c00efa7f5626e811e1c14b23996f04f60ceffcd0128af76a2a9bb83	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 05:22:30.99	2026-05-31 05:22:30.991
368af03a180bbe4a045b4079d9f89176f827da557e0cf3c5e5fb9b96598fc58e	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 05:23:29.409	2026-05-31 05:23:29.41
7a5cb3b1e5d515e33c8681a85ca4398a5dd07270adf521914586a42edd699e3f	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 05:26:39.685	2026-05-31 05:26:39.686
fcadd426048201b92396ad7fcaf234f4f09357726eec88f27d8d1922e0a86f73	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 05:27:02.943	2026-05-31 05:27:02.944
45680cd05581b80b6b4659290b50f5c415b3aff49123dcd98c3736b545ec22f6	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 05:29:52.766	2026-05-31 05:29:52.767
b374d6c32a0a3964edb1a1a1bfcb3d29b06732fa1e9677aac786e65f718a3b04	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 05:30:17.567	2026-05-31 05:30:17.568
484599f87192eb4e5bbc1f65c9136b190545cd75d7e6513d9dd1cc2d2fb15f1c	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 14:09:15.423	2026-05-31 14:09:15.424
9dab45691600854d3e0977237ded38dac433d769208b44f0037d7923f290b3af	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 14:09:23.87	2026-05-31 14:09:23.871
9dee7c6749284f6a1c92f220696e1ccadd92bf98aa8a023e47b3d9287efe8bfa	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 14:15:19.876	2026-05-31 14:15:19.877
31d1cb7c52bfe076f4178b32507f1f7b61c3306e42a69a4dd0a979ad33504542	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 14:20:04.327	2026-05-31 14:20:04.328
9d5d701973b990967f11b9d3dec5722e9cebeb0d27a1c3ed8b2836a8a34d132e	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 14:20:54.35	2026-05-31 14:20:54.351
5a26d4cbed1b5170b26f7f87087dabdb58c3381e2356ad47149fe4e586436e6e	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 14:21:59.243	2026-05-31 14:21:59.244
830a4e4653e2fef609b1c54a3b01d976fb9c82ea023492304413f8475607b578	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 14:23:14.395	2026-05-31 14:23:14.396
9d81ab97d144d6d281f6a04b42b82d093f78e4d4713b7423f482e734bb280ea0	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 14:23:56.929	2026-05-31 14:23:56.931
e74cff6114964b0c9404ecfeb2d949f32d47987fb9b5ee70385e659c860a2c4e	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 14:24:31.459	2026-05-31 14:24:31.46
0d0e664bf43a933bfc405863723364acad8bbc55f77dba8d265f3949e5244c57	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 14:26:14.272	2026-05-31 14:26:14.273
ce621e9c6308b9ea9de142faf79774cf7ce0f2a2aef45e5a94310d7f238de643	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 14:35:36.973	2026-05-31 14:35:36.975
aae9930a421b48353c88aa5c7519caef012ac93e31c9e8b13394b228787c176e	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 14:42:22.126	2026-05-31 14:42:22.127
8ff6569581a5499e2bed50ef270671f226d518a484b39627b2c58b85f37ed71e	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 14:50:03.356	2026-05-31 14:50:03.357
07d5fe689f90373d15a7a7b71e6c09b8f8ace49eeb4907008195762e853f88d8	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-07 15:24:41.317	2026-05-31 15:24:41.318
ec925319b793d33743caadc6c520fca92a4e5be9e3b37e2d1a06436de9d706eb	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 01:59:21.385	2026-06-01 01:59:21.386
f12a98ebe2cfd31b6a7cfdec07dd041679dc950683ed60a1106936b2befc25dd	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 02:01:27.926	2026-06-01 02:01:27.927
02d645b21ba9f2e31780669030a0769774d4fc2462d780176f0459c55bb9e75d	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 02:04:21.287	2026-06-01 02:04:21.288
4f045bb862549c2b14952643d9bf09161d2fdc1a57773b2b2aa0f99cd20c0f91	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 02:09:01.051	2026-06-01 02:09:01.056
a4d8d20455dfc784673571c4d25819e492c9b5886a38396ff06814dbf05ae1be	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 02:35:53.013	2026-06-01 02:35:53.014
1366390b3c58a4434a1452eddc3e9b58e642823069a02b009b5afebd842ec131	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 04:01:11.757	2026-06-01 04:01:11.759
2ee7ff3afd97a2b71efd2253e8ffc5fa39ab494068725cc9f23e3e35bba8d2a9	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 04:20:21.589	2026-06-01 04:20:21.59
066156a06b35e0f4a5a2a638e1d5dac19a70b38f758bb6546d44f1e001d0c36c	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 04:45:53.371	2026-06-01 04:45:53.373
cb9fbbe3eca1779bbf6be2cc90d9ae218ead5fb3c41af97959abef736c55f59b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 04:58:14.775	2026-06-01 04:58:14.777
7691e7e479e94c9dad3ccb94d31cb76047316f5d2b29b3af79e9ef2649ef0994	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 13:54:10.745	2026-06-01 13:54:10.746
c3b05a2250deff1de7278a663d877c8041e28e2edf65d4104f88dd641dc2883e	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 13:57:38.41	2026-06-01 13:57:38.411
f738bf88d5764c07a3167b473442f7fab74cfa5d6cb574545c0d55515db69e0a	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:02:03.968	2026-06-01 14:02:03.968
82ec71fc563798c66c342e0ba0e6ea0134314d615da0313b13e82a2d44cd2d37	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:17:56.356	2026-06-01 14:17:56.357
5c52512917f85f0000c8e6712824b52791eaa3d98824828c1ab74acff13c426b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:21:45.968	2026-06-01 14:21:45.969
10b4ea44581a859f87f69bae2c71a0604f60ba403b45ca700544b28e98944226	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:31:05.601	2026-06-01 14:31:05.602
84770c09a9f9a7a1290d49b4eadef292e7468ff77db85bea8a8acb2b67b51c3c	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:35:33.366	2026-06-01 14:35:33.367
57c2d841501b982030b77e573936cc5aba42f71758ff77c3d381cb10b3eceed0	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:35:51.091	2026-06-01 14:35:51.092
64991063b6bf774eee9f1e9ed40e7a166a5da8a1d8d926b359566df891ecc3dd	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:36:08.737	2026-06-01 14:36:08.738
659ee4b3fbe7f6df6364d245b36a38e9b2341dca07949b1d6da40e5ff14068d3	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:36:26.366	2026-06-01 14:36:26.367
d18fece182ffceebca76f9004ff33a5f4c535fd9477360c8e0e22b0ee782cbbb	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:36:43.999	2026-06-01 14:36:44
84b50ccfbe089a083efe71376fe45c312199ac64551cd2bc940ce01d833c7ec6	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:37:01.624	2026-06-01 14:37:01.625
0a10ee1b040a536f13b778bf10afea21247a99a051cb6e2d7ae3c16c07ba7bd9	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:37:19.278	2026-06-01 14:37:19.279
b7b8f16df144935343d30de9dec80f7d699fc826dd1d93e16a1d047d2614f4e8	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:37:36.948	2026-06-01 14:37:36.949
cc622e690ff054564e3a15bcd4f1b27e4729ac74b9fbebf9d7f0c945687aeb47	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:37:54.579	2026-06-01 14:37:54.58
7e69b352dfd57793d7e2bcfdf5293ba2a347c2e669f3a595578b0a808bcf8c99	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:40:59.325	2026-06-01 14:40:59.326
c30776080abd0f94daa8a548f45d07ff684fa5dec8c685f291f47eba1c752d9a	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:41:17.025	2026-06-01 14:41:17.026
5e86f8f4ef3d044e1cbbb5f63a47c43d5cf95f35ad206c85121c35a3b037dbe9	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:41:34.415	2026-06-01 14:41:34.416
e9ece91fdfc1c941c9e7aa17aed578c7c0a049bd9d87919a747be6730a551676	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:41:51.742	2026-06-01 14:41:51.743
774e3a3289fdc5222b8286a18d343ef892bb69b9861ece269a13cde5201bb067	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:42:09.107	2026-06-01 14:42:09.108
e728c3920e693ea66c1f48fe9020ad78fbbf35e0ea987ff888a49b2008996254	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:42:26.421	2026-06-01 14:42:26.422
dca3cbf2d5409ca553e7691ccf2e91d585a6276025dd2d7255e4c7ab9068aeeb	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:42:43.79	2026-06-01 14:42:43.791
dee65f6da10169039fa1c939cda08ec4f0cfcd0a1d12b08083c9dc828c7f1c26	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:43:01.178	2026-06-01 14:43:01.179
017071a08ba076fadfd22e0817b7a055bbf471eb01e48d2f3cea82362b241682	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:43:18.56	2026-06-01 14:43:18.561
c28b9c9d7e6d3417926389b8234149642c01165afcb46c5d01c2f64c59bca520	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:43:35.908	2026-06-01 14:43:35.909
8ce323052110c85aa9150e8e7073ed7ecd2051ed8bf5756ecc3de555f9516890	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:43:53.274	2026-06-01 14:43:53.274
6f54741721881a0e91d55ea6178803e020319930279b3114c4627e7c69298ec1	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:44:10.631	2026-06-01 14:44:10.632
2af50d11b1cf51c572a0747de6a41f86f020779d134f76a7c6b371ad1f885863	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:44:27.994	2026-06-01 14:44:27.995
2cf2188f850bed8f5ee8545b3b62e4695bcd7c28f9a34d9fc367b9ecdfc7f59a	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:44:45.344	2026-06-01 14:44:45.345
aa1fa1b291c197e20a4f650ed650e07ea5b42748fc721b17d5901d6a3f73744c	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 14:45:02.696	2026-06-01 14:45:02.697
a06ca8930f722ac26c77f32415a76d9f7582989609c45524fda95401c093d4a1	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:09:27.827	2026-06-01 16:09:27.828
2122d4f205d6ea28e18dc48ac7fd3e49a90e12d835c94ca439afc50c943d574b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:11:03.416	2026-06-01 16:11:03.417
5d0ba9164be777560c71c899a458dfefbf83ec06866aae3fc7dbf077c459ca9b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:11:44.552	2026-06-01 16:11:44.554
94b9ece05ed92691f80cdfec6a48593ac56baddf228121ce1aa027944f747e89	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:12:22.061	2026-06-01 16:12:22.062
8b23984868597e410f9977915385aa9f06f6f009ba7f3826fbbba17d74668f09	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:20:27.047	2026-06-01 16:20:27.048
d714eedef64694e4fe790f6f6489bbe3b92a407cc9beda8806d4e03dd5c8eb54	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:21:22.617	2026-06-01 16:21:22.618
a1bbc24b6f20046bc6d24e30e6dc2718d9b099d40db4d75b41d6d48fb06cb546	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:42:16.564	2026-06-01 16:42:16.565
452c4ef1457177f5705283a2c0c14e1877c351ea6811f645ccc26bf5d4a7e3b3	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:44:15.691	2026-06-01 16:44:15.691
66ce608cff2bbac95515821ddb719c13cede57a492e705952511ac5173718fbe	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:48:10.803	2026-06-01 16:48:10.804
9712b3d436bc6ffd041c2912565c1663c46ec351675035c8ad532afb70cb036e	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:48:28.617	2026-06-01 16:48:28.618
46e4ca5f6aa0d823894b3fd0e3d5d451e8f0503d037f1bae73ec28439a8492e9	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:48:46.106	2026-06-01 16:48:46.106
084f45d9218112b9db099fde3abc83f1c9a0730d69f61afe06794bb573e2e9d2	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:49:03.543	2026-06-01 16:49:03.543
069a2b71048ba2853091c9b0e0e15fdc5d2572e57523b65eee00cfc8611d1fb7	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:49:21	2026-06-01 16:49:21.001
9a2e46dc0de4c593adaed9e3c66babdda67805f75144ebd7f5d2f1ed3770b1e3	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:49:38.425	2026-06-01 16:49:38.426
322399b9bb29f4110ebc438fd600a4fd1fbad5ff8dc3fe864784ee01dafcb39f	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:49:55.848	2026-06-01 16:49:55.849
fd9e779880f15b6a24611d872a31e8ed23c2353bc2b981e5a73e783fc5013759	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:50:13.339	2026-06-01 16:50:13.34
695b433fa45c7f387deb2805538addff4c546242d1ca96eebc2fd3f21ca90942	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:50:30.764	2026-06-01 16:50:30.765
1000d93f81740f1938134f42470fd20f5b4b1fd8d356b6ce90da638651da8f65	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:50:48.211	2026-06-01 16:50:48.212
e99e8299ac745a9ba9e3ba99a73e7a9ebc30e07beae5a969562120d2a7e7d353	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:51:05.679	2026-06-01 16:51:05.68
cce8b462120c42d1511109fe968028659797cdca156663ad87f1cc7d5a32c09b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:51:23.153	2026-06-01 16:51:23.156
afe13dd0c237384fce016c056a05b24950a51ea2ca764670cb1525d97f1973c4	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:51:40.596	2026-06-01 16:51:40.597
27b5ab8364f052f4b26379737283f6242afb7d1eef20228080a328ece70ed8cc	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:51:58.106	2026-06-01 16:51:58.107
5e8af0c855579d1663d3e5a3ae466e772abd9b07e2e2d37bd517e02e3b708953	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:52:15.526	2026-06-01 16:52:15.527
d2827c3a9e5475b9e3f6049165271d998744b9e510295e29017ffcf723f8f6fa	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:52:33.025	2026-06-01 16:52:33.026
fb6d996231649cc7154ce45f29d63db9010d220d085f69f8dd7c446a69cf772b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:52:50.443	2026-06-01 16:52:50.444
06eab086bd5f8dfd714c10b9987c81de7be326929250a723ce3941501a17c046	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:53:07.937	2026-06-01 16:53:07.938
6188334cabecf9adde92cfb8b789442dc183a924e916e56324e8df6a705c6172	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:54:17.457	2026-06-01 16:54:17.458
db7d681be5ec2ecc6264a5f6a3048ad5a5155bd1efc693f48f2afe03d8075b2d	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:58:04.939	2026-06-01 16:58:04.94
38cf24bff151ad762743877d91a99e8fa6d90b79e91b6e0330d842e8ab02e4d2	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:58:22.738	2026-06-01 16:58:22.739
a9112a67a70f53c1e932565a65b1ffc65727bb65cd1c7e4c8a39288d28740f00	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:58:40.232	2026-06-01 16:58:40.233
6d5c55da6bed71ddd655bf32a53e659c1ad2ede5573105c75e9689fb638e3209	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:58:57.67	2026-06-01 16:58:57.67
285a4db88439bf583503a0de2c233598d452bb53b0c2430eaf892913ffe58819	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:59:15.121	2026-06-01 16:59:15.122
d062704eb75eee9001a021ae609a130e7976df8b565a10ac4b5aceb241ce18d9	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:59:32.538	2026-06-01 16:59:32.539
0df78bf24387aa9608d363f5e989b771040188bae91de3c9935fd96429b275ee	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 16:59:49.982	2026-06-01 16:59:49.983
6b5ab9aa6156ff98accf2e554fcd31bfb976b8b27c07a3ae6deb94c3bed61a2a	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:00:07.438	2026-06-01 17:00:07.439
87c361a904232652f7ae5c53ca6d196dd58d75e53fb77a32b895870c7e45005a	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:00:24.923	2026-06-01 17:00:24.924
e5db627abb27de619cb75f0344e20e7dda1561feb82bc17600e44f37f60b0941	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:00:42.412	2026-06-01 17:00:42.413
853878a0748502d6176afed2950a610a08939dbf50febaa1e648c1b38c5229a5	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:00:59.869	2026-06-01 17:00:59.87
74057aa9e0d0d08d9f4d68f94a7be32afcda39ed2288d129629be09e83c0d2ed	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:01:17.314	2026-06-01 17:01:17.315
5ce32720f07760f47969faf0ff172c8a6a13940743725040ca8f490dff3a3933	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:01:34.765	2026-06-01 17:01:34.765
99cb096a8fe8e07a5efd50227e5032f68fa763930f6dd8c5e876040084363403	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:01:52.226	2026-06-01 17:01:52.227
d6f29c9ed2e79e2450fcb7212a91d8316b93ddd667240eee8f4a4adf24cc1a0b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:02:09.648	2026-06-01 17:02:09.649
45f3adc5a8f39fe6d6eac4f0e37123a365eb86e64cf8628aed450ba7c34933e6	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:02:27.068	2026-06-01 17:02:27.069
45c333db4da7054f0286e04a0bd114e639de563d4f77d11316791f39542a8c0d	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:02:44.483	2026-06-01 17:02:44.483
35378130f01ac842973d8850dd7a11ce2d9f4ed3e15aed8c456ab732608621e8	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:03:01.892	2026-06-01 17:03:01.893
03ff38b2938b02f12d5239979c1f01f3fad2300f517dcef8365be8de0b31a4f1	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:06:39.025	2026-06-01 17:06:39.026
4f55c3ecdcda61a8a29c7686061aa9bab1ef75075c83ec06ee63575b8488a6aa	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:06:56.845	2026-06-01 17:06:56.846
91b953e01c55753b53f8bcc692548c4c19323f50520cb985c0abdd4717495203	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:07:14.309	2026-06-01 17:07:14.31
e349eab62b47ae6a9afe57a156eef608973fdd17f72d10a2aebf7e51b8b638be	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:07:31.763	2026-06-01 17:07:31.764
22e0097bb1159f2e300cbe452710ae6dd3eda8b1c965333a3332fdf2cd7a30a9	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:07:49.19	2026-06-01 17:07:49.191
d705e3a8e1a7a1f84f9c832098ecf69a108701916ca9274a1885bb8b42147132	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:08:06.612	2026-06-01 17:08:06.612
04b2d842eefcda983825237dcfa3ed2d9104a12bca5f6c8b4f4990bf37ccb212	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:08:24.048	2026-06-01 17:08:24.049
80dbf145011e794c830e2e6cd8ffba03cb230aa52950f211a94daffd1b3110ce	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:08:41.531	2026-06-01 17:08:41.531
48bdbe6c7368a5f2966f2eae5b9c80181f361ad75099b5df24888f0f01b6a81d	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:09:16.457	2026-06-01 17:09:16.457
09069833d829cbe4d36aad8654cdfc3b1578d5afed3ae27123cc058d24d5b631	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:09:33.92	2026-06-01 17:09:33.921
6d8fd449f52e65f709324ef94da8c6321f164b7c1d0d137f00477e7ac4790af5	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:09:51.357	2026-06-01 17:09:51.358
b81241033bb97815c5f3aa6f8fcad97ecf36b1639f02a015fee8d908626ab54d	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:10:08.808	2026-06-01 17:10:08.809
34c342a3844ef07e1e2af2dcda6dad7233b803666ab457a12a63591433020a6c	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:08:59	2026-06-01 17:08:59.001
0e65bcdff54a593162b4ecff1f92ad427645ed36c4bb3feb18aaea6338d2d268	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:10:26.271	2026-06-01 17:10:26.272
911846102b3fbc4d4e0ac29823140b49094a8bf9b582d68ac9d92440c8e5c119	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 17:10:43.718	2026-06-01 17:10:43.719
9a1b507229012d9e0b35aa90c96e1986c1a536996c9a6387e8ceab5fb22caa08	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:13:52.311	2026-06-01 23:13:52.312
e8c6f7aa9db75dc47aac42ae961ff6847f7203ba40a5e26fdabd6b21df719318	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:13:56.302	2026-06-01 23:13:56.303
5369c7cfdfcd6fabbff25a2c24e10080aa9c76969919d74f54e94e11c03d6236	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:13:59.634	2026-06-01 23:13:59.635
c085336157f80a520c65fce37aa12e5410a49c493196569cbdefc3a409255d47	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:14:02.569	2026-06-01 23:14:02.57
be340e328c769fcc735c7551646197164878540c98023ee66b5d0724afe3a7ec	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:14:05.674	2026-06-01 23:14:05.675
28d58720fd33526ed771b0419df86c2a6f46b2dc28230afba12c11730ed2b52a	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:14:08.671	2026-06-01 23:14:08.672
f6a8e5d47c0830af5d2f85c4d9e0cefc9695b3d48b66dadc995042e9f91b07e3	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:14:13.034	2026-06-01 23:14:13.035
518371ef6d265e0663539d22966bc097be741e0cbb927bf4d31c9049f351deb6	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:14:16.931	2026-06-01 23:14:16.932
d967f6b6375a9362edfb80cb3d3a9aac347108e7550d98935ff389ed7b7dbbde	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:14:20.155	2026-06-01 23:14:20.156
781394cb392364ddfa9a8ee026b59733be116aa4074404925176ba21d6e93ba9	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:14:24.822	2026-06-01 23:14:24.823
052bb8e3fdc4410940475f1948ccbea28672a0b8252b6da26543809febb731ee	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:14:29.036	2026-06-01 23:14:29.038
ae9e3955b109732c4d7b89c42bb6cab5d9fd0bf1ca5bf929f6f6b20023b74652	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:15:15.854	2026-06-01 23:15:15.855
bae73c6060b250dad25ee87b5c5355cccf1b5efa65fdc1b60210b232ba43b872	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:15:18.378	2026-06-01 23:15:18.379
364f37e89fe03331114118cdc6cd8be6ec8763ff343eb7c8cd3300f3195c9b3e	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:15:21.143	2026-06-01 23:15:21.144
fbc52e839b31a529c46ad438e21599fa34ed5b4d94b6a90ced9aefc51937a207	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:15:23.549	2026-06-01 23:15:23.55
9ec5adae0c33e72ae4e4559d2786da3fbea00dd5106161c34ec07ad57feb2a36	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:15:26.26	2026-06-01 23:15:26.261
69af921744392efb3039b4f405d91b7adc5a4ca8a138e1d74e1ec067b15442af	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:15:28.978	2026-06-01 23:15:28.979
9431ba728914034e8a9c5e9bba2e5ad735b93fbe8e4547f8f4bcbcbeabc0303b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:15:31.322	2026-06-01 23:15:31.323
c2fa84ba8a91a500228b731eac7a90fc424d93e07f41bd7b90757b56650a39b5	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:15:33.924	2026-06-01 23:15:33.925
bc11b16b7b67e8dda4628569d3ad81b4d32ab252831c6fb8b37d68af8b87618b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:15:37.911	2026-06-01 23:15:37.912
d0e3cb12157b8bf7c5d0c639091be375cd47ff5ad9cd66d7649a198015c431be	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:15:41.22	2026-06-01 23:15:41.221
6c265542e38106c36864719906a4771ff2d8e7e61515e660930c4d2d53d43277	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:15:44.095	2026-06-01 23:15:44.096
de44e2a51695aee61080bfc15304a1008e22d816d318c31bc1b054d0312c2c3d	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:16:02.352	2026-06-01 23:16:02.353
a3b1fa9e95f8e32e2591e448e2d5bd74b630e005761a43d1ad2030fd98046127	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:16:52.13	2026-06-01 23:16:52.131
3186b9250ddfe3f4e062eab231a024cc649c1611cc525ca4b862ed2e47064638	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:17:09.914	2026-06-01 23:17:09.915
6ad32c8d159da173c622b3ea6c8875f1d52f3836415f97dcbdbf7cf506d31e25	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:17:27.635	2026-06-01 23:17:27.636
c0b9e29a71d45c5539b05f7bbe61dc06b5fae070807bf3ce3c996c1ea2a723cb	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:17:45.317	2026-06-01 23:17:45.318
8b21560dd2d15d8cfcf95cb393d2b826e5e01bee928ca13cf82110e96639b6db	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:18:03.142	2026-06-01 23:18:03.143
13162179ef56ffd5bcddf9be80b1085963593a9f7824d35840094392332c2f0b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:18:20.994	2026-06-01 23:18:20.995
d908f72271639958a7d425b440a0a20c5c9c1280d5ab10139c80ad00021f4d0f	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:18:38.759	2026-06-01 23:18:38.76
0b52b199ad0b69fcc882c495af003da90efc758c7d2e7062ed4f1ccf8a30c810	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:18:56.262	2026-06-01 23:18:56.263
9228dd2c07c6b292916a5f40896f6e6d64d7cebb8a7fb72d4b046cb68a3dd8c1	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:19:14.605	2026-06-01 23:19:14.606
54f833b47aa91a4c9276759d222b2dd09cd5a78243f58767a557a13fa852da0c	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:19:32.535	2026-06-01 23:19:32.536
7baeb20d1a6afdb8ef6e202b11b93bbe59a8e9b7306e320ceffe8429e5ad161e	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:19:50.35	2026-06-01 23:19:50.351
997845fbc4eed7c40b522dc056ca32d9cb31a0dbd1538fa9acf210b1f8948257	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:21:16.987	2026-06-01 23:21:16.988
daf74b95c988618e054615a8a12ff54289766e770f00d6970df44cc09a37ab50	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:21:34.555	2026-06-01 23:21:34.556
3cb812f46ae2384f626265c09de9bf433a40781b20e49324a7f22c7e678f1c84	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:21:52.388	2026-06-01 23:21:52.389
11a79690e7a363b7f35a22bf34aff9a870abb00b5867d6a6b45ea89ee0411b1a	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:22:10.206	2026-06-01 23:22:10.207
60db713a26116d49216641c5da190a52544fa34113e19a5c91a03e7454982791	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:22:27.784	2026-06-01 23:22:27.785
d3a4c7c75e6189cf7f5361edc606d69caa5bb304603091368811a84d4c859ec3	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:22:45.27	2026-06-01 23:22:45.271
a01051af6a9c5bc4b742f4121a157143c71aab0c6493d51c90778ec557aa5909	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:23:02.879	2026-06-01 23:23:02.88
2d7d42f59b44bbb1e6f5b5f318f1bcc4da472cbd253a8a2e192923b8669bf2e3	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:23:20.541	2026-06-01 23:23:20.542
6a00daf3decb16a99c28485f98dd56ed9c9c7aaa8be93b2f89024c2e668881ad	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:23:39.14	2026-06-01 23:23:39.141
aa3e4aa44148c5aad92d8b727222569022210f01e0eaac7c185c9d470e211106	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:23:57.063	2026-06-01 23:23:57.064
d119a696c1a7a4f751d19a2ecb0f40b057a7ebda53011b836ed76d118004ddab	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:24:15.119	2026-06-01 23:24:15.12
21ef97b8ac480c87f3010c3b022cc83aa7ccd9c1c14093c5a240a97947504ccf	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:25:20.547	2026-06-01 23:25:20.548
1cba72248e3c20e56f61c9bbb5144f68ab4d0998d753b7b479881f040ae01f96	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:26:07.484	2026-06-01 23:26:07.485
92af067a420efd6b2bd7dffd5962e53e6a5f812f9ba1f93d418c2e75e4feb015	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:27:00.671	2026-06-01 23:27:00.672
3f4b0d64c8c923e2b8cfbaf6e7d74517bcb3184615c6cd4462a6ad7ae95c94f2	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:27:18.313	2026-06-01 23:27:18.314
1ff4419548cc6b618e17e6d48761936f63e58b6e481b8b2d021316bdda2e9e9b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:27:36.048	2026-06-01 23:27:36.049
c7c23a9e149519407443df642405aff1316c3cf608acff57d17a9f8f2093301d	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:27:53.492	2026-06-01 23:27:53.493
7756579551d41bcc6ad13c2b2759bf96fcb763e9ab540734d6dec0d9645907f2	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:28:10.96	2026-06-01 23:28:10.961
e36a4b872a85088d68cfa70d6be9ed11473dcd9f6c2cf31e4466566dc32086be	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:28:28.769	2026-06-01 23:28:28.77
7ac671cccbbd510d0e54ada803b284825da8589f90f9b5bb925a024623efd551	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:28:46.392	2026-06-01 23:28:46.393
8a513055e37eecc8277fa090b45d4563fcf00f49bb653028463f3436791e7566	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:29:03.741	2026-06-01 23:29:03.742
63536c904b1816e113125db8788630d7bb7dfc9b61f3d166fdda4321201b61f9	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:29:21.495	2026-06-01 23:29:21.496
3a9c3b9b48dbe55fa9b9b92d689c0960bfd3a16dc4ea187cf52c781d3f39e6e8	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:29:39.441	2026-06-01 23:29:39.442
d508b66a8c48e9f589509bde6ab179d7e541251d949ffb7fdb056155cbabdb04	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:29:57.392	2026-06-01 23:29:57.393
f41631ea03285bada8e00b0b260f458fb64536eaa8bc9d334ccb3f4fb4db2a1d	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:43:20.041	2026-06-01 23:43:20.042
112292e81da2f1e229301ea328d0a811fa6d156f4a74d042375fc58a9aeb306c	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:43:21.95	2026-06-01 23:43:21.952
d99ce078133ecce54d7a0c7d71cd1a071b5d0044e03d5b18de80f8cfd2542df7	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:43:23.96	2026-06-01 23:43:23.961
9260448924e3b7c0eb45b32258773ef8a49b403a61057c528d90f9c8d4b94b99	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:43:26.657	2026-06-01 23:43:26.658
1a10ec126c7a785322aaaeec161020fba9cf71ecec4075e2b5c9a100cbde2326	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:43:29.929	2026-06-01 23:43:29.93
8fccb4e4db791747f81c358aa14431738af9236c7708afe57418c4f9a3693d44	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:43:32.497	2026-06-01 23:43:32.498
95908f7d9d5182bd156e01a7b0339eaf1a1db5439c71033e53f5db0cfe427613	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:43:35.062	2026-06-01 23:43:35.063
1f22a152c1b377990fc949afd8979636b13abff9adde0419eb04e3c6165cc61b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:43:38.405	2026-06-01 23:43:38.406
bd097feaf6eaf95fc0437b0445139a4e4b2a26b4d9f0aeb065386235aef29fe5	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:43:41.796	2026-06-01 23:43:41.797
33463ce999822f35df781fba8db36f4df731f8cae2bf3c6716d6e5d845934fe8	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:43:44.358	2026-06-01 23:43:44.361
3e6d4d086a2659aa862791b19341a0ad0bae09be0f2ef40b9e024c42ed56d19c	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:43:47.794	2026-06-01 23:43:47.795
e4eb75e38f6523657280af780aefefa95796710292bc56b0558cdd8f3891ab86	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-08 23:44:37.66	2026-06-01 23:44:37.661
a3927c98a1e08f0f54c2722e40e48bdac004a4db4f9474f5b7d842962bcaef01	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:12:01.769	2026-06-02 00:12:01.77
696263070eee9606e79465f5f9d00676339e10489dc16cc280d800b0543b5d39	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:12:03.704	2026-06-02 00:12:03.706
b8c9990f4d172851c230fa963f1767ae9eb93e4afd4854ddd2bd3d2dd8f1ef0f	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:12:05.699	2026-06-02 00:12:05.7
8f87efa82769dd13f5b8cced564eef5b0f960f6bab8545e00626224ebd3821bb	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:12:08.411	2026-06-02 00:12:08.412
01229ed66af39d0060c290bbaa90bfea8347ca4a4531b129c46aa078f809fe39	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:12:11.59	2026-06-02 00:12:11.591
49116dff81c7c36c6f4b568aa5081ddd14c5acf921872d1d98f243fb72161252	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:12:14.082	2026-06-02 00:12:14.083
392488668b6b59eeec50bf380948b62c81388adabc6043add30a8785cec7232f	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:12:17.42	2026-06-02 00:12:17.421
4e88c2a7d4fd99c13d3449836d19076711b27f351e7a8eb233b5fd17dd9cd763	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:12:19.934	2026-06-02 00:12:19.935
544401d0d8bd3a04f024d0dde0b806013dfe813fa2d879a2c87822b51d36a8a1	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:12:22.446	2026-06-02 00:12:22.447
d8df2e07a359fb55e78ea8ff9a94220c22b4e3158371642a89797ba494934fda	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:12:25.634	2026-06-02 00:12:25.635
ef7279b79f49962b037cdeff6cb6ad8064735e44c511d9233106bb9e1196cb39	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:12:31.6	2026-06-02 00:12:31.601
7bd320eb8ea9cc6081ed4064f4f1a0d8809cb9f2a5e7b093692b30365841ae97	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:12:35.114	2026-06-02 00:12:35.115
bdc00db095143ab1aa6c1fbe0ed7bcd92755c608533e7c160b8e3789bf91fed4	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:12:37.309	2026-06-02 00:12:37.31
9a325ce98fc0a5f31b1ad9f2be607519eb7d8d9d1cca6106be081e4cac249cf1	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:12:40.776	2026-06-02 00:12:40.777
b0337dfa8b1ff260808f62bc31107fcf111330cffc96027ce537413593487c43	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:12:43.19	2026-06-02 00:12:43.191
8a58586560d47380a408ac4c8d9af94db85ac188456743cbb91ad85ed33964da	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:12:49.135	2026-06-02 00:12:49.136
70e180e41b6a5edc2acb7d9720184d60c4beca2504832b3b19e4a959062172cd	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:12:51.904	2026-06-02 00:12:51.905
503f85fc55ca9e78138cf3a8e6f2e377ad1b75f69297229f955abaf2bb7424d5	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:12:53.823	2026-06-02 00:12:53.824
a99089b97d3763a4950e58df186d93e30ce722ef974d05d0c9142bab111d3cd5	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:12:59.749	2026-06-02 00:12:59.75
237bb8e734d8a5252b475ca091dd3ab851f5f6bdb7577fbfbff7d524a18782b9	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:13:04.141	2026-06-02 00:13:04.142
441eb06ae2fcb1fcb13a7125b8d60dcc198f1f22952eb74f197adf6aa4abb96c	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:13:07.576	2026-06-02 00:13:07.578
c2fc6a72d820bfad2f76bad7d48c99b9d11e60f2036023e502ffd63a70b16f20	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:13:11.117	2026-06-02 00:13:11.118
216cd42d10f0f07cf1f293ca7a64db4a6e88f844c0d139847bc2824d925a66c0	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:13:17.79	2026-06-02 00:13:17.791
6e4df02a579d934b4d50e45be0856bb73b0735d63ffde14e4dcf114ac2038291	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:13:24.423	2026-06-02 00:13:24.424
b5bd2cdc7e5753bd46365729da7835fa064e76d60a38b1c6606aa68608be1bc5	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:13:31.022	2026-06-02 00:13:31.023
d703c30b46d01df9131ce9c82a383b175f7ed5bd64ae6fe7b12370f9b3ed2723	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:14:16.334	2026-06-02 00:14:16.335
ee1f5393a713030176b74ff71dbf5fadefb9a99865e26fce5c128d0eda725cea	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:14:18.341	2026-06-02 00:14:18.342
f96949abfee6ca8a04db8ecbee562b9ef70204abf6e4297f71883f57a494dcc4	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:14:20.324	2026-06-02 00:14:20.325
02dedb4283f2a55324756d74330eea31b80d555a4b44e8902e6d4b1466b4f9bb	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:14:23.812	2026-06-02 00:14:23.813
38a882d5d7415062d6fe4150f19d8bfc5e5a04be92036d9fb53e4de37f1bf418	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:14:27.141	2026-06-02 00:14:27.142
c24c2458349bc201fa9c8d28289e02309180fabe5cd39de61660e706385fe6a3	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:14:29.802	2026-06-02 00:14:29.803
cdaff87737dc77c93034f1e43a19a0fdf7cc249a921f0deab44e341f7bc68626	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:14:31.627	2026-06-02 00:14:31.628
92a8067e215370e503c82a4d58c4fd139f4673affb134c0f0775f87a71758653	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:14:34.173	2026-06-02 00:14:34.174
40cf3e17e6d46a081d9cd7c28d0f5d1f8bf20b8f71bd519a5627266a75093161	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:14:37.18	2026-06-02 00:14:37.181
a8b0599f4155f458c1da3b244a5f2aa17dde8107d5db5c2191f1a034824150d0	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:14:40.286	2026-06-02 00:14:40.287
8e3da167cb794fba9f963cae4c0c843368744c9639d923b15b2d593265bdb6b5	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:14:42.834	2026-06-02 00:14:42.835
e4966d83fd01999ce3c00a91819e10b0e52a7e7845ea2ce473e93448e0573f9c	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:14:44.699	2026-06-02 00:14:44.7
2a838a5ffb418649d5223275fdea81bf0e27ad22aeb8a171f83c4196e6ca3bfd	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:14:46.734	2026-06-02 00:14:46.735
fc77e2d3c3345dcd9c1a6d49a72198546f5756e8339dcbc081d803e724a33ebe	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:14:48.942	2026-06-02 00:14:48.943
2936e535427507102f85d04f10115461bdc4c9b1999932837288893c8a720dd6	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:14:50.824	2026-06-02 00:14:50.825
ec022fa88fbdf2cdff5a34d555b8bde53564a95017f621b529667ce799d6ace0	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:14:54.289	2026-06-02 00:14:54.29
3d3a7269b98db4823f057eb5a628395499ad569455e4d296eb4b64f3478e3376	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:14:57.101	2026-06-02 00:14:57.102
d1c33dce332b3587f8814860a168764c37c633b71e5eddecc79ce49c970079d7	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:14:58.942	2026-06-02 00:14:58.943
74a8ed4153359ba3abf733b1e24709c1d71ddf65ffe83364d109da02751aa5db	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:15:02.096	2026-06-02 00:15:02.097
3c39e276288805bd901d9e11f1e857735de9173a72bc674546450f7766dee35b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:15:04.071	2026-06-02 00:15:04.072
480f3122e4bb8607d58569277ff60fecb692614b5d4804d2fde0fe66946b409b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:15:05.979	2026-06-02 00:15:05.98
d22ad998fe4c659bdd9e35060e05c6d9bca8a1d7b2b3d24d5098b44bdfafcb96	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:15:08.031	2026-06-02 00:15:08.032
f2024d131f0cb934e5f3f44d78077d8123787783da77dd5c9251b1450f72c11a	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:15:11.52	2026-06-02 00:15:11.521
2dd8b96baa340a029f9983f6ede5d9f112e6e8f6eedba6acced8ce51d62cae83	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:15:15.477	2026-06-02 00:15:15.478
3f2f057b23ef63f3a205bd52fb4f364bd93d37b396f28bcde88aa365171bbdcd	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:15:19.395	2026-06-02 00:15:19.396
389cd433279c782e4b8ff8e2478f8b67552f1391c0441b21eddff1a611167b9f	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:16:24.072	2026-06-02 00:16:24.074
a272c148aba828586db437b6b11427c2d9df99ad5853adf633b179814f453e4d	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:16:59.562	2026-06-02 00:16:59.563
92241514da9743d875388fd4e48653fe7ad14ef0085c2c928552108009f670d5	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:20:46.465	2026-06-02 00:20:46.466
db7ab92aeb0cd0434e3e550b2a84ffa6cecca9dea8270981e12f6724643f49a0	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:20:48.481	2026-06-02 00:20:48.482
ccec49006e15c0d7f0febe50aa0bcf915c03278f9cd4f909d74beb26ebcadd23	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:20:50.563	2026-06-02 00:20:50.564
4e0661a795d14ad77c5cb07e70526e40dcf8d3abb59870bb00d79b61ddb41d47	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:20:54.154	2026-06-02 00:20:54.155
b9fefcd7ae4293fce6150c69dbb38202a3e1b2377f12fb15ef62ac69a2ce1cf5	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:20:57.388	2026-06-02 00:20:57.389
c19a01feb51132129b2c0d35b2d87202abc2384f6db51cb8a966f95aa765be4e	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:21:00.046	2026-06-02 00:21:00.047
59a11a5a99d8e97d82d2dae7f2d86f09f8c0adb5189c06b7819a60a2ead277e0	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:21:01.83	2026-06-02 00:21:01.831
2dfbf34972b163dc4ad64f7cc50c9687a0a4d67a93fd3a5742e176027b46bce0	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:21:04.877	2026-06-02 00:21:04.879
8ae6d4556608ade201abccbef892589aab406ad47b5cacd58be9de5fe2c5ac75	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:21:07.976	2026-06-02 00:21:07.977
c48860fe5fe87234b46d6f72c1f257117d9b1e856601ffc4eb110319ec48ad7e	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:21:11.139	2026-06-02 00:21:11.14
3d3e87e14528099458df6bd92ef7e87d6aaabd2553896de4f212a79f5fcba76a	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:21:13.71	2026-06-02 00:21:13.711
8e3963d0be6ce10e35f96f109387ed92aea8a36735bc3ab05e1722fd7b3b04b0	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:21:15.524	2026-06-02 00:21:15.525
d900810c43155be14e1d3c1e2209107e133b004c14f19e13877369d2be0920c5	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:21:17.515	2026-06-02 00:21:17.516
84cb7e92456872712f02996962d55d294de86b96bd25271d55f37c758b987192	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:21:19.494	2026-06-02 00:21:19.495
baae69e82cd29bd76b52decdd74b247b70042f47e54bbbfd933332280b51ba03	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:21:21.545	2026-06-02 00:21:21.547
b3430754ac6dd57d41597d7b46ef5c23bdba7704ad60ee05476b85fdc2552924	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:21:24.359	2026-06-02 00:21:24.36
5954cdc2e129858318d7996e974730e494139ed6cc8f8d64875e37a08f8bd970	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:21:27.192	2026-06-02 00:21:27.193
4f7e592cfc589d84dc2b9b921cbe4f4d251958f3c0a74ac210333af83c2f55b2	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:21:29.16	2026-06-02 00:21:29.161
2bccc68b813dae7f7c8b240434a116782ede4af8c5511d6095cc54f88bda9749	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:21:32.283	2026-06-02 00:21:32.285
47ef6bae6600a78962961c7ed873feba211e745f1d1d1680aca594be9d8ba268	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:21:34.117	2026-06-02 00:21:34.118
8f1d2e619bff5c00e9ea05976569a2d8cf2a340654bd2b4dd75dba8b649116e2	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:21:36.003	2026-06-02 00:21:36.004
b09795fc1d7c6092aeb7f1e4d0401687277f456eb01976fda741e9798aec3710	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:21:38.032	2026-06-02 00:21:38.033
3e62d3101d338328b6bbfd0c0deeacc6a50a529f4e7981b6201c058b9453b685	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:21:40.75	2026-06-02 00:21:40.751
743880af72a3a12d474401e5846aae94ca310be4a5036897d504696e30703ed7	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:21:43.943	2026-06-02 00:21:43.944
2b1838fd431988ff76a362690552765e9745065bc5d4a7ba7f556df0c99809a9	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:21:46.617	2026-06-02 00:21:46.618
095a02646748edec0ca5d7711191cd53381e7e98fd0a6e96c57533098b705ec3	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:39:50.957	2026-06-02 00:39:50.958
646e71cdeee6eba948391ae35ad2c6ddfee1776f45509e95b08de4ebc5efb7f7	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:40:06.744	2026-06-02 00:40:06.745
48d29433f3d598338bf846914b1017622b6361e24b9005927edbce5663d22e5d	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:40:27.001	2026-06-02 00:40:27.003
e2fad82d3480c373851bbb0d142375ad9b7c1507c8679622cc6122abb842ccea	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:40:29.534	2026-06-02 00:40:29.535
c4e62b8b73770483b8f0b2e385c3fe960cdfca8f8aaa8eb12c05522eb55de320	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:40:31.8	2026-06-02 00:40:31.801
268a507478d539e4abff30aabc8d9cb50a5434634e98a8cec6f85ef7505a4850	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:40:35.275	2026-06-02 00:40:35.277
47b5a415df8d1d9da6ea555ae6d9696222af3d5e657f69be6c3590818157c5c5	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:40:39.387	2026-06-02 00:40:39.388
5835bd09033430fcc8ff7305ff32537ba9b03639fde6692588b5945a1afc3a55	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:40:42.999	2026-06-02 00:40:43
9f2327075dc9da32df94cf15b87eb10d5227dbcd82ca0246fdcefd240d3bcc9b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:40:45.285	2026-06-02 00:40:45.286
2bd51855fa243cdf0eeabf5f534c93770a1613f40ce5096654dc47ec1af5dcff	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:40:48.552	2026-06-02 00:40:48.553
4b660958e7e40a9af7aa63ff2f327921ff961702f56977a244fa40ec85cf3c78	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:40:51.726	2026-06-02 00:40:51.727
3b098c315e0ba6ee406513dd54b50feebb6d07b08996adeaf0ccaf265b78ed3a	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:40:54.881	2026-06-02 00:40:54.882
bdf0c47b7625769fa41bb23476fd21c8539779772069fe2d8916276cb77ef66e	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:40:57.95	2026-06-02 00:40:57.951
f52de2a903f113144b240a15948ccad9284c8a29bec0ad8e88d991cd0bcf3bdb	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:40:59.738	2026-06-02 00:40:59.739
f8f7de33e97aed780e3beb224e311079696946976187157fc3a1ee4966f8b071	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:41:01.887	2026-06-02 00:41:01.888
f81d868f881e9618e5d1248b6c13aac60d7e4cb6914862961985c8b12789c73b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:41:03.942	2026-06-02 00:41:03.943
93b400546bc25c933da8750953eed276326cdfaf0459d960259966349e02628c	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:41:05.833	2026-06-02 00:41:05.834
81d461753924613f9f7c456794912739c1327499e0a0c16cbfbd0448844e7667	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:41:08.677	2026-06-02 00:41:08.678
c3cbf65bdb4982580dfd2821fa3ab13c6ba9116e5ceeafaca1fa97c52020ee5e	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:41:11.547	2026-06-02 00:41:11.548
bebc8b5850339e0e17338aed528e17a84faa9405cab7f2f2733d8db26db29b8f	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:41:13.606	2026-06-02 00:41:13.607
5ad8725eb39d17bb6d4eb3e19a4c3484d039a90834665a2400de20041bbef8ac	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:41:16.874	2026-06-02 00:41:16.875
0799de607e5745e58cf7206d9593004cda71d3b90b59500e47a9c5ab4b298072	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:41:18.783	2026-06-02 00:41:18.784
1d919eb0604af6cf7b0d0c5ae6c98b135242281a26c771fa8176197c4ee606b8	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:41:20.757	2026-06-02 00:41:20.758
2dff7d40046cb88f4c6816ac47f168dd06acf22df34105fd2a96f53b6c4ec6c2	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:41:22.842	2026-06-02 00:41:22.843
c507f5b4c448063b76c7f33f3a9870e42623544d3f7ec76dd96d55dfcc0a7b3e	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:41:25.623	2026-06-02 00:41:25.624
6d5eec1e4ea1a98f45441546f317ba32853a573b2cd3622f626f5b5675732526	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:41:28.969	2026-06-02 00:41:28.97
e73ce4fb49641cdc00f3a3ad41dce6e454154e592a9a03261c3870799b0b6c93	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:41:31.706	2026-06-02 00:41:31.707
7720a59d4fc00e6a07df2a44704351fd812367dfe763b4697e6083b5e681cdb7	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:57:04.038	2026-06-02 00:57:04.039
ee985b419069c0541c6b26101f1550c992fcfa8f9e7ee89b1c248465a4146031	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:57:56.256	2026-06-02 00:57:56.257
a5676efdf3698ec3d08fd25d8bf247578f81d5d8d4147f2c848dba51cb619ada	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:58:38.694	2026-06-02 00:58:38.695
bc0c53ceb8c56c5ac6670d19b42cf4627c5b32157afca470c347fc45548244d4	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 00:59:21.51	2026-06-02 00:59:21.511
c95315ce304d07ce26cd9d3a115dbca2b6cf5193c4147e2b575d945964b218fd	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:00:35.227	2026-06-02 01:00:35.228
d2ed5fa5c3e3766f3da90437b27023e83f37cd73f7e420f0146a9991bb26c393	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:01:08.871	2026-06-02 01:01:08.872
25077c196d93b6a628ff9fe132541d11237c79bfa9af08aa360a1ffbf9703517	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:01:11.52	2026-06-02 01:01:11.521
4dfa1a0e3dee2e9aeb64333aefe518a7380df2157b89ae69172d5998baf69a5e	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:01:14.112	2026-06-02 01:01:14.113
e0fc80a144e9ff064bf2c28400754ead8ad15ee84d2c9c84bee61b4ef44129d8	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:12:58.87	2026-06-02 01:12:58.871
f1e774eb9633ca91b6c5c494d832ec08c72787bd33f21cd66995ac038ef62fff	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:15:06.151	2026-06-02 01:15:06.152
96e909f6a56ce76b135da15dacbe391d2f21e4a2f442b3f948f0f695d7d46506	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:15:21.945	2026-06-02 01:15:21.946
0db6a9e66be0a9e34f80218ed9b45f1ffead48aaafb8b15a663ce37b61f03420	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:15:24.801	2026-06-02 01:15:24.802
e4c8851d1ecbe1b3cab39f51dad70a5e8fcde0d21a488d4e4b8dca873ccc1975	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:15:27.62	2026-06-02 01:15:27.621
27926bef142f0f4f9eb54fedc4bb034dc7ea266c3b0c233d9b1e0a6dd2673a3f	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:31:44.296	2026-06-02 01:31:44.297
41ca8de507c30fe61d4be41e72ef52e0633b26d65eec603b841781171ba1fdf8	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:31:45.822	2026-06-02 01:31:45.823
d9d00d93d041568c092bfad992308eb3b2cc451e558ec27a5feba1788d8a2a69	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:32:02.271	2026-06-02 01:32:02.272
8371af0090cb8b84d6ae2307c43d96f9420337294cba86aed3bedc1ad2514005	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:32:03.591	2026-06-02 01:32:03.592
e1ef71bf5584db52c323a40f30766b047ea685b7910742aaefbdaf85ec3bb19d	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:32:05.035	2026-06-02 01:32:05.036
2b2a222b6fe9bf2f023cba46ac531c597d8b41ae8f82c68400daa76e3ed7fc51	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:32:21.478	2026-06-02 01:32:21.479
f036485269f692768c70f41483f883bc45fbecbc16c807ed0830ed1ba2bde657	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:32:24.084	2026-06-02 01:32:24.085
a0a9721c2c608533561b8515da3a3325d7ee4da401d4971d82583043588e902f	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:32:40.676	2026-06-02 01:32:40.677
7b8ea8b43b51076d24e364d7dfcfc7624d8ac8949abd3ccc3cbbdec22ca21a0d	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:32:41.972	2026-06-02 01:32:41.973
3a8f85da8873b488dd3d1d68ddfa7de08c63b6a98f72ad96c2924bbc2623cb27	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:34:50.982	2026-06-02 01:34:50.983
8789208b6f6c85dbdf2e8705709592834667958be763fa8757c918ec560217a7	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:34:52.464	2026-06-02 01:34:52.465
0fa61658042d49ce7f230766a63733191b7b0c9fbda310ee248649ade9bb93df	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:34:54.927	2026-06-02 01:34:54.928
99585c5a0826c204df4150d96ca366c57c5c9c2333a25e5eb242a1df61694a5a	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:34:56.17	2026-06-02 01:34:56.171
fc0d88c1748ec3cd03447e3fccc92e638d2fa79d885881fa76ea0b91331c3ac4	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:34:57.998	2026-06-02 01:34:57.999
d593f8f7f9d80a2b05cb5010999160414de90f90b4820d93699c19805c6553d9	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:35:00.55	2026-06-02 01:35:00.551
5802edb8631826eaef0f43afd6066e6a5030ea3b3c0b61adf33ef633f38c40ba	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:35:02.968	2026-06-02 01:35:02.969
4d5800df766cdc355412ebc33b4e44b3ce8a836c28beec74fb596f726efacdbc	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:35:30.317	2026-06-02 01:35:30.318
3d80839756e8c11a68c869286e3d27e42159657075ff8c050a18bd1fcfa11bd4	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:35:31.808	2026-06-02 01:35:31.81
58af0cec84cecb9b575d5fd42181da110c14f29f1fceb2209b9ed51fedbb6fd8	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:36:06.997	2026-06-02 01:36:06.998
7a7dca5cbf320fd974df39a39942e163fe7eee99bda3732c0953bf3aa1588fab	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:36:08.352	2026-06-02 01:36:08.353
34b03f87bead37377a5fcd87ec32ef701508611135f0cfc2c6dab1e368eaebc7	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:36:11.117	2026-06-02 01:36:11.118
41c91786b22f950c19a2ab2efd53bf8977d8f93427b81b24fa561b05463c1daf	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:36:12.773	2026-06-02 01:36:12.774
8e1658379c90ff8bed1158caf5a545e61c04ac6505b07a65668b5679613c115e	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:36:14.714	2026-06-02 01:36:14.717
7686777447789bc2862ac7b04b2025127347b638b71b092da121a53bdfa22f6e	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:36:17.873	2026-06-02 01:36:17.874
e9ba0cc8445eaa6a2cc01cb39fcd2a3c7dadf1d456a7153535b22b8f90ded344	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:36:19.662	2026-06-02 01:36:19.663
bc051f4603d9b328ebf20dff4b39067b6e2bd7948e511126780ff9dc0d82e33b	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:36:21.486	2026-06-02 01:36:21.487
52f77a8bd5bc423625570bf762e858e9b2805bac13ac428dc33e38c5c9bc1e1d	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 01:40:54.434	2026-06-02 01:40:54.435
ed1ee8360398f0f483dd6ada56f1bfbad1d64c2e151db6def511773dae3febfa	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 02:11:51.461	2026-06-02 02:11:51.462
909681a6d34b6187e06b800b13f2ce87332b391d0b47cfa131730812d4646fbf	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 02:11:53.996	2026-06-02 02:11:53.997
50503d204793cc18c84240d51653691da070f8f83510bc1500f54e191b92a8d0	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 02:11:56.477	2026-06-02 02:11:56.478
228468145d51620021dfe5ec9db281e6249bcb17ac687c7f88d1fba8fc90ebf0	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 02:12:00.494	2026-06-02 02:12:00.495
2d0564fb8377a2daf9afd6d1c2df4f86b3fbec146c11a17f8811e88de8fc3b85	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 02:32:59.821	2026-06-02 02:32:59.822
a2357d37a51a372a2c5c8694623cc4aabcb353b7877c1ee08564d2fda56083a7	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 02:37:21.705	2026-06-02 02:37:21.706
28b0ef01fbdcf18927f9df3b82059e96c32de9a3d02d2d2035ffe534c2823e93	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 02:38:03.018	2026-06-02 02:38:03.019
edb1d1eec4ed3e5cac0794a14df7e42d232a7331e68266b570be1da9dee813c3	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 02:38:53.14	2026-06-02 02:38:53.141
d063db3f42deeb16aec48b3b56f0f0a7148093bcedfae02f76d8f02d4e134231	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:24:37.808	2026-06-02 03:24:37.809
9580404cb99501f993db89b541959cd5f99aa7db79dc652f2862d840f38fef14	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:24:41.001	2026-06-02 03:24:41.002
3068b66b4736fcb67f9b19e2039a84e2206a8d0de7abb7ff694253257428cac1	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:03.419	2026-06-02 03:25:03.42
981f2a4220d5375ebc2df91e465cd53e5aadda9e5c10eb7762846fee08894691	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:05.439	2026-06-02 03:25:05.44
f35c1aaf231f57a1960fea6471008406c6fd8edc3caf919c3ef4bf22810895c2	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:07.409	2026-06-02 03:25:07.41
0d918539c45352f1604ea4ddd91da477d93ab9e130182d6a4d8ce2cbf72297fd	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:10.361	2026-06-02 03:25:10.362
84bc2891e76dbe652467141f46a1407297519e58a4e682a06390d3847dab01a3	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:12.43	2026-06-02 03:25:12.431
c8e6a92beb6f53d775017b2361078be219d43b08a58919d2a50b75085004c90e	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:15.758	2026-06-02 03:25:15.759
25b34ec31a881b6340093564d866752cab753b801dab79067b36f8d2980d1cfd	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:18.91	2026-06-02 03:25:18.911
157acf9193239d8ac84155a6fcb6779e617c630800ed4f3367a5a8dde3d47d09	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:22.522	2026-06-02 03:25:22.523
0c0a521c50d86adbb8820de34dd43bd41a453359720234e10409c71a28fcc889	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:24.367	2026-06-02 03:25:24.368
867ede7e099392457091555055f93456a6fc9112224d8af6dfb32518d80adf77	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:27.411	2026-06-02 03:25:27.412
f0c0992fb7c898f2eb5d495ab999f2f7cdaac99bc6ed171b840b3ef19bc5c745	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:30.496	2026-06-02 03:25:30.497
a64ad9e5b96619ce5b076e998981db6366318d26d5fd3fb125a5a0dd8420affe	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:33.649	2026-06-02 03:25:33.65
3c4552bec13e66742cf40a5b78e328d619e32b6e0a66c8df7eb630d8677af478	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:36.28	2026-06-02 03:25:36.281
caa9c1f1259df8b9eef42f4fb05a3e4bb972e892324af05df6acd461cae98269	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:38.3	2026-06-02 03:25:38.301
7cecfe05035fc5efb5b43c53cf8329fd10b63720cb2d008d9d54b597686e51e1	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:40.41	2026-06-02 03:25:40.412
b265e5235c149a330f21d419db3c01e394f130f5290dc6341ca6580959b3ce67	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:42.414	2026-06-02 03:25:42.415
dc6b6aa63f913f4307a94526c8ec90aff68c9658885711a08f6dc3ac2a1bb0e8	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:44.344	2026-06-02 03:25:44.345
bc0c00427cdf539c4c5703ed51889465fd484fb2a373ae267e515b530807c3db	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:47.057	2026-06-02 03:25:47.058
e8796d090fbdd40be280aab34c2dac550f155c4054233427be946e734fe4ca15	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:50.381	2026-06-02 03:25:50.382
88b1821b5c53bee3b647242d0732e2991f791d15a6f1cdcd435c5124b59cda14	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:52.326	2026-06-02 03:25:52.327
5a0da732cd4436da69de16f41540ddd04eb50caefaf8a254a84d23a90bd416c6	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:55.579	2026-06-02 03:25:55.58
64994df5b4d09045b1ddff0d17cac871f3211f382384e46e79468e86c4c8f4c2	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:57.429	2026-06-02 03:25:57.43
3694a1e92d49b4bf54e2fc92a9710155b4e0cde3a4ee7c57f45b83c145ae9f83	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:26:01.55	2026-06-02 03:26:01.552
c8a544d7fa37e1f312a95966916731fb24ced98a743757a78004d908f6694efd	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:26:05.128	2026-06-02 03:26:05.129
e31c211f18d522822795585f87850a3eee860bfeef9b9fc2362bf80f938af398	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:26:11.336	2026-06-02 03:26:11.337
32aaf25388716264ea4bd7b366d60f9ee6bf2c66e42d358a4b9f6698fef7e1d1	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:25:59.461	2026-06-02 03:25:59.462
58705c806ef90a67ec8ea06db97a216ee15c1f824516aff268d121c883a94734	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:26:08.388	2026-06-02 03:26:08.39
410867011e30c529b971b9380252f962f4160dc787d4e4b185b48878b37d6aa9	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:30:18.913	2026-06-02 03:30:18.915
b7d77ffdd7b7694060cbbe7d6eb68ba05aab829174eca5e431f4c4221c59d823	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:40:07.264	2026-06-02 03:40:07.265
f3405d7e31ca0ac51a04daecea609fba89f79d7d989e06616a243bbe8f7437c8	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:41:30.687	2026-06-02 03:41:30.688
0ac067ff9c27aa51eb255dad921ec56f2cf21e4e2cf59c20fbef22aed9a26ccf	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:42:16.11	2026-06-02 03:42:16.111
e6110ded46b35fdcf6bc919e005df16e4da608fbd80306f559904482d4b6e2cc	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:43:23.392	2026-06-02 03:43:23.393
07e0f14cd2b75eb4dc53501ec87bdccc24dc0dfb1f68e6eecce7cafb334aadb6	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 03:43:27.455	2026-06-02 03:43:27.456
0c8cc2e57cfe6a0e537040f288f9c878e1fd9957c8b5c5b1c046ac209297f9f9	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 04:15:34.808	2026-06-02 04:15:34.809
4f7c0aed411b8328a013a9daf77e846dcb4af04c4dca3e06bd191315bf33ca07	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 04:15:40.39	2026-06-02 04:15:40.391
f3cd12d85b4996693854e7fc3bbb5bcb73c7bdf63d9169d3d18363aacf76eb46	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-09 15:10:08.161	2026-06-02 15:10:08.162
6fdc8c3c0aa6f48921a2802c9503de7e61114ca95a947da961119f66eabdbfaa	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-10 14:30:42.684	2026-06-03 14:30:42.685
8d2646a65613132c5cac6c2a03970d7328bea76481e2c40014098f2cb8d122ea	83e86a90-6e51-498b-b8b8-c6ef124058d2	2026-06-11 13:05:27.788	2026-06-04 13:05:27.788
\.


--
-- Data for Name: sync_meetings; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.sync_meetings (id, org_id, project_id, sprint_id, meeting_date, meeting_type, status, transcript, ai_summary, ai_tickets, notes, created_by_id, created_at, updated_at, title, search_vector, artifacts, meet_conference_name, meet_space_name, meeting_url, video_provider) FROM stdin;
fb36761c-c8b3-4495-b037-6e1a88e2b365	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	\N	2026-05-13 13:24:16.685	SPRINT_REVIEW	MEETING_COMPLETED	\N	\N	[]	Action items captured; see linked work items.	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.849	2026-06-03 13:24:16.849	Sprint 4 Review	\N	[]	\N	\N	\N	\N
34a67f84-c190-4b0f-ac5c-b2788003c85a	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	\N	2026-05-13 13:24:16.685	RETROSPECTIVE	MEETING_COMPLETED	\N	\N	[]	Action items captured; see linked work items.	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.852	2026-06-03 13:24:16.852	Sprint 4 Retrospective	\N	[]	\N	\N	\N	\N
3a980533-6fc3-4dfb-94ae-34182b155612	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	\N	2026-05-16 13:24:16.685	OTHER	MEETING_COMPLETED	\N	\N	[]	Action items captured; see linked work items.	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.854	2026-06-03 13:24:16.854	Monthly Program IPR with PMO	\N	[]	\N	\N	\N	\N
cb64f567-34a0-4a8f-88f3-587f5c1948f2	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	\N	2026-05-20 13:24:16.685	OTHER	MEETING_COMPLETED	\N	\N	[]	Action items captured; see linked work items.	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.856	2026-06-03 13:24:16.856	Technical Interchange Meeting — Boundary Architecture	\N	[]	\N	\N	\N	\N
2a0a7ec5-6930-41b1-87bb-524d936a4abb	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	\N	2026-05-24 13:24:16.685	SPRINT_PLANNING	MEETING_COMPLETED	\N	\N	[]	Action items captured; see linked work items.	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.858	2026-06-03 13:24:16.858	Sprint 5 Planning	\N	[]	\N	\N	\N	\N
ec42c6aa-c8aa-4333-a734-ab74c9253f1c	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	\N	2026-05-30 13:24:16.685	OTHER	MEETING_COMPLETED	\N	\N	[]	Action items captured; see linked work items.	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.859	2026-06-03 13:24:16.859	CMMC Evidence Sync with ISSO	\N	[]	\N	\N	\N	\N
f7aeba09-b4c9-4de6-8f21-3c984d9be63a	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	\N	2026-06-04 13:24:16.685	STANDUP	SCHEDULED	\N	\N	[]		f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.861	2026-06-03 13:24:16.861	Daily Standup	\N	[]	\N	\N	\N	\N
402c72d3-7c52-4a97-89ae-95c0cb701580	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	\N	2026-06-05 13:24:16.685	OTHER	SCHEDULED	\N	\N	[]		f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.862	2026-06-03 13:24:16.862	CMMC Pre-Assessment Review	\N	[]	\N	\N	\N	\N
b2ea5bac-700b-46ed-aa1b-efcd815f2e2e	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	\N	2026-06-08 13:24:16.685	SPRINT_REVIEW	SCHEDULED	\N	\N	[]		f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.864	2026-06-03 13:24:16.864	Sprint 5 Review	\N	[]	\N	\N	\N	\N
0dd8707d-aa09-4149-afac-c2c53d9c1715	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	\N	2026-06-15 13:24:16.685	OTHER	SCHEDULED	\N	\N	[]		f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.865	2026-06-03 13:24:16.865	C3PAO Readiness IPR	\N	[]	\N	\N	\N	\N
\.


--
-- Data for Name: themes; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.themes (id, org_id, slug, name, mode, colors, typography, spacing, branding, is_built_in, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: time_entries; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.time_entries (id, org_id, user_id, project_id, work_item_id, date, hours, rate, client, description, billable_type, status, approved_by_id, approved_at, tags, created_at, updated_at) FROM stdin;
0414d869-5133-4028-ad31-290f01a199c5	b3b93f25-2072-4514-8820-74712a67ca64	241480b1-17de-4c30-975e-722aa992e640	b1140265-ef3e-4146-857b-61d14d039b88	39e9a20c-0d29-42b7-bc40-8e723a4d7ce5	2026-05-18	7	195.0000	\N	SIEM rule tuning	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-19 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
2f56471d-977f-4f10-886a-d1daab1aebb6	b3b93f25-2072-4514-8820-74712a67ca64	7789efda-ce1b-4f2d-bec5-edf32f52e443	b1140265-ef3e-4146-857b-61d14d039b88	3fcf248b-3f8f-4212-9533-81639019425d	2026-05-18	8	185.0000	\N	Sprint ceremonies	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-19 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
a5c4570b-929a-41fd-be16-41f89790bf32	b3b93f25-2072-4514-8820-74712a67ca64	118ec485-9938-4146-9d0b-943c007ffc64	b1140265-ef3e-4146-857b-61d14d039b88	487e7b8e-7f03-4e86-83ce-56d2c980490a	2026-05-18	6	185.0000	\N	Engineering — Sentinel	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-19 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
ca61c749-0279-4abd-b016-2a977e748dd0	b3b93f25-2072-4514-8820-74712a67ca64	18198088-f46b-420d-a37e-0b7d8d968855	b1140265-ef3e-4146-857b-61d14d039b88	6b56e81f-83c8-49d6-90cc-2e7f362d2983	2026-05-18	7	175.0000	\N	ATO evidence prep	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-19 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
f5e610fd-1eba-4f76-82c6-9be43114f824	b3b93f25-2072-4514-8820-74712a67ca64	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	b1140265-ef3e-4146-857b-61d14d039b88	83513990-1e1b-4831-99d9-5f25a03e4e5c	2026-05-18	8	215.0000	\N	STIG remediation	NON_BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-19 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
c94c27ba-c3ff-4e66-ab96-7bb69a41e426	b3b93f25-2072-4514-8820-74712a67ca64	241480b1-17de-4c30-975e-722aa992e640	b1140265-ef3e-4146-857b-61d14d039b88	39c3c7bb-8de9-454a-93a0-1ac653d52725	2026-05-19	6	195.0000	\N	Code review & test	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-20 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
f4dd07da-8baa-4196-9669-349142b7fd2b	b3b93f25-2072-4514-8820-74712a67ca64	7789efda-ce1b-4f2d-bec5-edf32f52e443	b1140265-ef3e-4146-857b-61d14d039b88	39e9a20c-0d29-42b7-bc40-8e723a4d7ce5	2026-05-19	7	185.0000	\N	SIEM rule tuning	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-20 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
d342949e-09b7-435e-babb-1686f5625f48	b3b93f25-2072-4514-8820-74712a67ca64	118ec485-9938-4146-9d0b-943c007ffc64	b1140265-ef3e-4146-857b-61d14d039b88	3fcf248b-3f8f-4212-9533-81639019425d	2026-05-19	8	185.0000	\N	Sprint ceremonies	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-20 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
21428a92-fc50-4c4c-a11d-04bee86a118e	b3b93f25-2072-4514-8820-74712a67ca64	18198088-f46b-420d-a37e-0b7d8d968855	b1140265-ef3e-4146-857b-61d14d039b88	487e7b8e-7f03-4e86-83ce-56d2c980490a	2026-05-19	6	175.0000	\N	Engineering — Sentinel	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-20 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
6eee5797-5038-4ae2-a2f2-6869cfc53a11	b3b93f25-2072-4514-8820-74712a67ca64	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	b1140265-ef3e-4146-857b-61d14d039b88	6b56e81f-83c8-49d6-90cc-2e7f362d2983	2026-05-19	7	215.0000	\N	ATO evidence prep	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-20 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
6cb29e58-f840-4222-92c9-eb70a04c99c5	b3b93f25-2072-4514-8820-74712a67ca64	241480b1-17de-4c30-975e-722aa992e640	b1140265-ef3e-4146-857b-61d14d039b88	27fe3905-f7d8-4b4e-a720-b6946a5a8ca4	2026-05-20	8	195.0000	\N	STIG remediation	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-21 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
0deb5644-b2ae-466a-91c2-1cad0907afce	b3b93f25-2072-4514-8820-74712a67ca64	7789efda-ce1b-4f2d-bec5-edf32f52e443	b1140265-ef3e-4146-857b-61d14d039b88	39c3c7bb-8de9-454a-93a0-1ac653d52725	2026-05-20	6	185.0000	\N	Code review & test	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-21 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
f403704b-bf4f-4a38-9ade-7ff55fa22bf8	b3b93f25-2072-4514-8820-74712a67ca64	118ec485-9938-4146-9d0b-943c007ffc64	b1140265-ef3e-4146-857b-61d14d039b88	39e9a20c-0d29-42b7-bc40-8e723a4d7ce5	2026-05-20	7	185.0000	\N	SIEM rule tuning	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-21 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
cf0bb10a-02d7-4a00-9079-7b0556bd0c2c	b3b93f25-2072-4514-8820-74712a67ca64	18198088-f46b-420d-a37e-0b7d8d968855	b1140265-ef3e-4146-857b-61d14d039b88	3fcf248b-3f8f-4212-9533-81639019425d	2026-05-20	8	175.0000	\N	Sprint ceremonies	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-21 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
1469dde0-15d9-44e4-a520-04030aa685b2	b3b93f25-2072-4514-8820-74712a67ca64	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	b1140265-ef3e-4146-857b-61d14d039b88	487e7b8e-7f03-4e86-83ce-56d2c980490a	2026-05-20	6	215.0000	\N	Engineering — Sentinel	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-21 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
87170705-0059-4eca-a412-adc3f12eaa05	b3b93f25-2072-4514-8820-74712a67ca64	241480b1-17de-4c30-975e-722aa992e640	b1140265-ef3e-4146-857b-61d14d039b88	189d5330-50b0-40a1-8ec5-8cd0211f7b72	2026-05-21	7	195.0000	\N	ATO evidence prep	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-22 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
d7bcf08a-7c0c-4acf-a285-8f6e8cc198d6	b3b93f25-2072-4514-8820-74712a67ca64	7789efda-ce1b-4f2d-bec5-edf32f52e443	b1140265-ef3e-4146-857b-61d14d039b88	27fe3905-f7d8-4b4e-a720-b6946a5a8ca4	2026-05-21	8	185.0000	\N	STIG remediation	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-22 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
122a6b53-0473-407b-9ea3-63da76915505	b3b93f25-2072-4514-8820-74712a67ca64	118ec485-9938-4146-9d0b-943c007ffc64	b1140265-ef3e-4146-857b-61d14d039b88	39c3c7bb-8de9-454a-93a0-1ac653d52725	2026-05-21	6	185.0000	\N	Code review & test	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-22 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
2bf71d9e-63bc-45d0-94cb-3dc6764f7215	b3b93f25-2072-4514-8820-74712a67ca64	18198088-f46b-420d-a37e-0b7d8d968855	b1140265-ef3e-4146-857b-61d14d039b88	39e9a20c-0d29-42b7-bc40-8e723a4d7ce5	2026-05-21	7	175.0000	\N	SIEM rule tuning	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-22 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
4bdfcba2-09d4-4e15-ae3e-37101688f12b	b3b93f25-2072-4514-8820-74712a67ca64	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	b1140265-ef3e-4146-857b-61d14d039b88	3fcf248b-3f8f-4212-9533-81639019425d	2026-05-21	8	215.0000	\N	Sprint ceremonies	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-22 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
7cf94c1e-0023-4037-8143-d7b9de0c69b7	b3b93f25-2072-4514-8820-74712a67ca64	241480b1-17de-4c30-975e-722aa992e640	b1140265-ef3e-4146-857b-61d14d039b88	03ca3d82-fb93-417b-ac0b-931f1605cb87	2026-05-22	6	195.0000	\N	Engineering — Sentinel	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-23 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
3b6feebb-fbaf-41ed-bc16-e053eab358e0	b3b93f25-2072-4514-8820-74712a67ca64	7789efda-ce1b-4f2d-bec5-edf32f52e443	b1140265-ef3e-4146-857b-61d14d039b88	189d5330-50b0-40a1-8ec5-8cd0211f7b72	2026-05-22	7	185.0000	\N	ATO evidence prep	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-23 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
5cbc3537-8e7e-4f03-b926-0350d47bec26	b3b93f25-2072-4514-8820-74712a67ca64	118ec485-9938-4146-9d0b-943c007ffc64	b1140265-ef3e-4146-857b-61d14d039b88	27fe3905-f7d8-4b4e-a720-b6946a5a8ca4	2026-05-22	8	185.0000	\N	STIG remediation	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-23 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
167a0eae-4562-4526-a54a-2ca1231d00e3	b3b93f25-2072-4514-8820-74712a67ca64	18198088-f46b-420d-a37e-0b7d8d968855	b1140265-ef3e-4146-857b-61d14d039b88	39c3c7bb-8de9-454a-93a0-1ac653d52725	2026-05-22	6	175.0000	\N	Code review & test	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-23 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
010f4547-1165-40de-8872-71d7e64b2687	b3b93f25-2072-4514-8820-74712a67ca64	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	b1140265-ef3e-4146-857b-61d14d039b88	39e9a20c-0d29-42b7-bc40-8e723a4d7ce5	2026-05-22	7	215.0000	\N	SIEM rule tuning	NON_BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-23 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
c1994293-1c3e-42a4-994f-5f8b64e6b603	b3b93f25-2072-4514-8820-74712a67ca64	241480b1-17de-4c30-975e-722aa992e640	b1140265-ef3e-4146-857b-61d14d039b88	9405945c-fc8a-4190-b5d9-0f3992a5c903	2026-05-25	6	195.0000	\N	Code review & test	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-26 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
7127b6d3-f12c-4229-a773-c88504e79502	b3b93f25-2072-4514-8820-74712a67ca64	7789efda-ce1b-4f2d-bec5-edf32f52e443	b1140265-ef3e-4146-857b-61d14d039b88	95dd2ba3-d4e7-4a22-a1a6-029e203af38a	2026-05-25	7	185.0000	\N	SIEM rule tuning	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-26 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
38b212c5-4249-4077-976f-e9cd06788b4b	b3b93f25-2072-4514-8820-74712a67ca64	118ec485-9938-4146-9d0b-943c007ffc64	b1140265-ef3e-4146-857b-61d14d039b88	a984f166-eb59-4c4d-a5c8-514d2acaa271	2026-05-25	8	185.0000	\N	Sprint ceremonies	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-26 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
af973e82-9ae1-4ca3-a1b3-a1f5b70f8f12	b3b93f25-2072-4514-8820-74712a67ca64	18198088-f46b-420d-a37e-0b7d8d968855	b1140265-ef3e-4146-857b-61d14d039b88	03ca3d82-fb93-417b-ac0b-931f1605cb87	2026-05-25	6	175.0000	\N	Engineering — Sentinel	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-26 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
cb2fd9f2-d1e6-4bee-b4a9-0385159f21ca	b3b93f25-2072-4514-8820-74712a67ca64	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	b1140265-ef3e-4146-857b-61d14d039b88	189d5330-50b0-40a1-8ec5-8cd0211f7b72	2026-05-25	7	215.0000	\N	ATO evidence prep	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-26 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
c7b55b29-f034-4fcb-9ea3-b8c09f1d3db4	b3b93f25-2072-4514-8820-74712a67ca64	241480b1-17de-4c30-975e-722aa992e640	b1140265-ef3e-4146-857b-61d14d039b88	83513990-1e1b-4831-99d9-5f25a03e4e5c	2026-05-26	8	195.0000	\N	STIG remediation	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-27 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
f85d5e58-45d1-42c2-938f-811424477395	b3b93f25-2072-4514-8820-74712a67ca64	7789efda-ce1b-4f2d-bec5-edf32f52e443	b1140265-ef3e-4146-857b-61d14d039b88	9405945c-fc8a-4190-b5d9-0f3992a5c903	2026-05-26	6	185.0000	\N	Code review & test	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-27 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
aeea297e-a214-4a20-a11c-705ae89d35e8	b3b93f25-2072-4514-8820-74712a67ca64	118ec485-9938-4146-9d0b-943c007ffc64	b1140265-ef3e-4146-857b-61d14d039b88	95dd2ba3-d4e7-4a22-a1a6-029e203af38a	2026-05-26	7	185.0000	\N	SIEM rule tuning	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-27 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
59e854fa-dc16-4177-9118-5a7df201b5db	b3b93f25-2072-4514-8820-74712a67ca64	18198088-f46b-420d-a37e-0b7d8d968855	b1140265-ef3e-4146-857b-61d14d039b88	a984f166-eb59-4c4d-a5c8-514d2acaa271	2026-05-26	8	175.0000	\N	Sprint ceremonies	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-27 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
0dc8a836-a974-448c-a2fc-d97916c9a8bd	b3b93f25-2072-4514-8820-74712a67ca64	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	b1140265-ef3e-4146-857b-61d14d039b88	03ca3d82-fb93-417b-ac0b-931f1605cb87	2026-05-26	6	215.0000	\N	Engineering — Sentinel	NON_BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-27 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
8aa7b6cf-596c-4e51-960c-b93673f0c1a6	b3b93f25-2072-4514-8820-74712a67ca64	241480b1-17de-4c30-975e-722aa992e640	b1140265-ef3e-4146-857b-61d14d039b88	6b56e81f-83c8-49d6-90cc-2e7f362d2983	2026-05-27	7	195.0000	\N	ATO evidence prep	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-28 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
4f14cd1b-e509-43df-b9cb-d457f90f3024	b3b93f25-2072-4514-8820-74712a67ca64	7789efda-ce1b-4f2d-bec5-edf32f52e443	b1140265-ef3e-4146-857b-61d14d039b88	83513990-1e1b-4831-99d9-5f25a03e4e5c	2026-05-27	8	185.0000	\N	STIG remediation	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-28 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
9823662f-6630-487a-a037-68602385cdc5	b3b93f25-2072-4514-8820-74712a67ca64	118ec485-9938-4146-9d0b-943c007ffc64	b1140265-ef3e-4146-857b-61d14d039b88	9405945c-fc8a-4190-b5d9-0f3992a5c903	2026-05-27	6	185.0000	\N	Code review & test	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-28 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
972d8399-076c-4c8b-939a-e9671c0c2958	b3b93f25-2072-4514-8820-74712a67ca64	18198088-f46b-420d-a37e-0b7d8d968855	b1140265-ef3e-4146-857b-61d14d039b88	95dd2ba3-d4e7-4a22-a1a6-029e203af38a	2026-05-27	7	175.0000	\N	SIEM rule tuning	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-28 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
9fc19d00-5a2c-4200-a804-4c0e4f206cb3	b3b93f25-2072-4514-8820-74712a67ca64	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	b1140265-ef3e-4146-857b-61d14d039b88	a984f166-eb59-4c4d-a5c8-514d2acaa271	2026-05-27	8	215.0000	\N	Sprint ceremonies	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-28 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
9560c1d6-3aee-4da7-83bd-1e56c205daed	b3b93f25-2072-4514-8820-74712a67ca64	241480b1-17de-4c30-975e-722aa992e640	b1140265-ef3e-4146-857b-61d14d039b88	487e7b8e-7f03-4e86-83ce-56d2c980490a	2026-05-28	6	195.0000	\N	Engineering — Sentinel	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-29 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
caea652d-68ed-465d-bd5b-66023ef7e187	b3b93f25-2072-4514-8820-74712a67ca64	7789efda-ce1b-4f2d-bec5-edf32f52e443	b1140265-ef3e-4146-857b-61d14d039b88	6b56e81f-83c8-49d6-90cc-2e7f362d2983	2026-05-28	7	185.0000	\N	ATO evidence prep	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-29 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
48a1e814-e5fc-4598-a731-02f567423101	b3b93f25-2072-4514-8820-74712a67ca64	118ec485-9938-4146-9d0b-943c007ffc64	b1140265-ef3e-4146-857b-61d14d039b88	83513990-1e1b-4831-99d9-5f25a03e4e5c	2026-05-28	8	185.0000	\N	STIG remediation	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-29 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
71a8cfa8-9d45-4175-abb1-2b958aee54ee	b3b93f25-2072-4514-8820-74712a67ca64	18198088-f46b-420d-a37e-0b7d8d968855	b1140265-ef3e-4146-857b-61d14d039b88	9405945c-fc8a-4190-b5d9-0f3992a5c903	2026-05-28	6	175.0000	\N	Code review & test	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-29 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
cddf3e6e-3c33-49d8-8c58-45f4c78025a9	b3b93f25-2072-4514-8820-74712a67ca64	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	b1140265-ef3e-4146-857b-61d14d039b88	95dd2ba3-d4e7-4a22-a1a6-029e203af38a	2026-05-28	7	215.0000	\N	SIEM rule tuning	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-29 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
91353540-0c53-4ac0-8706-d58d6f9cebec	b3b93f25-2072-4514-8820-74712a67ca64	241480b1-17de-4c30-975e-722aa992e640	b1140265-ef3e-4146-857b-61d14d039b88	3fcf248b-3f8f-4212-9533-81639019425d	2026-05-29	8	195.0000	\N	Sprint ceremonies	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-30 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
4aef1be1-97d9-4b40-af04-a17e55902189	b3b93f25-2072-4514-8820-74712a67ca64	7789efda-ce1b-4f2d-bec5-edf32f52e443	b1140265-ef3e-4146-857b-61d14d039b88	487e7b8e-7f03-4e86-83ce-56d2c980490a	2026-05-29	6	185.0000	\N	Engineering — Sentinel	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-30 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
2c9784b1-1a95-4ad4-9cf5-0cbda17d5456	b3b93f25-2072-4514-8820-74712a67ca64	118ec485-9938-4146-9d0b-943c007ffc64	b1140265-ef3e-4146-857b-61d14d039b88	6b56e81f-83c8-49d6-90cc-2e7f362d2983	2026-05-29	7	185.0000	\N	ATO evidence prep	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-30 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
226b72fb-471b-4b02-b843-e72c885e39d9	b3b93f25-2072-4514-8820-74712a67ca64	18198088-f46b-420d-a37e-0b7d8d968855	b1140265-ef3e-4146-857b-61d14d039b88	83513990-1e1b-4831-99d9-5f25a03e4e5c	2026-05-29	8	175.0000	\N	STIG remediation	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-30 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
3170c8e7-29e5-4164-b25a-08f6b8e10ea5	b3b93f25-2072-4514-8820-74712a67ca64	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	b1140265-ef3e-4146-857b-61d14d039b88	9405945c-fc8a-4190-b5d9-0f3992a5c903	2026-05-29	6	215.0000	\N	Code review & test	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-30 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
7e58b405-43f7-4a6d-8bd4-47d0dfeac617	b3b93f25-2072-4514-8820-74712a67ca64	241480b1-17de-4c30-975e-722aa992e640	b1140265-ef3e-4146-857b-61d14d039b88	27fe3905-f7d8-4b4e-a720-b6946a5a8ca4	2026-06-01	8	195.0000	\N	STIG remediation	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-02 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
1d2b5aba-3743-4fcb-be56-9fad13533c32	b3b93f25-2072-4514-8820-74712a67ca64	7789efda-ce1b-4f2d-bec5-edf32f52e443	b1140265-ef3e-4146-857b-61d14d039b88	39c3c7bb-8de9-454a-93a0-1ac653d52725	2026-06-01	6	185.0000	\N	Code review & test	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-02 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
6c8207d8-1708-4487-b7c5-65fd8b10b312	b3b93f25-2072-4514-8820-74712a67ca64	118ec485-9938-4146-9d0b-943c007ffc64	b1140265-ef3e-4146-857b-61d14d039b88	39e9a20c-0d29-42b7-bc40-8e723a4d7ce5	2026-06-01	7	185.0000	\N	SIEM rule tuning	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-02 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
e27600b3-e151-40cd-b146-ec5a32f81b26	b3b93f25-2072-4514-8820-74712a67ca64	18198088-f46b-420d-a37e-0b7d8d968855	b1140265-ef3e-4146-857b-61d14d039b88	3fcf248b-3f8f-4212-9533-81639019425d	2026-06-01	8	175.0000	\N	Sprint ceremonies	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-02 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
30638902-edde-4061-b5f0-dc41895f2ed5	b3b93f25-2072-4514-8820-74712a67ca64	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	b1140265-ef3e-4146-857b-61d14d039b88	487e7b8e-7f03-4e86-83ce-56d2c980490a	2026-06-01	6	215.0000	\N	Engineering — Sentinel	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-02 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
7a052022-3c1d-44f1-bc17-2a58f9c84173	b3b93f25-2072-4514-8820-74712a67ca64	241480b1-17de-4c30-975e-722aa992e640	b1140265-ef3e-4146-857b-61d14d039b88	189d5330-50b0-40a1-8ec5-8cd0211f7b72	2026-06-02	7	195.0000	\N	ATO evidence prep	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
924ac26d-41f6-429d-bce8-0d32e76c12b2	b3b93f25-2072-4514-8820-74712a67ca64	7789efda-ce1b-4f2d-bec5-edf32f52e443	b1140265-ef3e-4146-857b-61d14d039b88	27fe3905-f7d8-4b4e-a720-b6946a5a8ca4	2026-06-02	8	185.0000	\N	STIG remediation	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
88fa26ed-2e1d-4c70-81dc-34fa069f8458	b3b93f25-2072-4514-8820-74712a67ca64	118ec485-9938-4146-9d0b-943c007ffc64	b1140265-ef3e-4146-857b-61d14d039b88	39c3c7bb-8de9-454a-93a0-1ac653d52725	2026-06-02	6	185.0000	\N	Code review & test	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
1ebbe29c-2066-439f-89ef-9493e147fe87	b3b93f25-2072-4514-8820-74712a67ca64	18198088-f46b-420d-a37e-0b7d8d968855	b1140265-ef3e-4146-857b-61d14d039b88	39e9a20c-0d29-42b7-bc40-8e723a4d7ce5	2026-06-02	7	175.0000	\N	SIEM rule tuning	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
dbb73acc-944b-4409-8d2f-5d8628dc1fac	b3b93f25-2072-4514-8820-74712a67ca64	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	b1140265-ef3e-4146-857b-61d14d039b88	3fcf248b-3f8f-4212-9533-81639019425d	2026-06-02	8	215.0000	\N	Sprint ceremonies	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
6bb11b45-5719-46ce-be11-329cfb8a081a	b3b93f25-2072-4514-8820-74712a67ca64	241480b1-17de-4c30-975e-722aa992e640	b1140265-ef3e-4146-857b-61d14d039b88	03ca3d82-fb93-417b-ac0b-931f1605cb87	2026-06-03	6	195.0000	\N	Engineering — Sentinel	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-04 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
67a92718-df9d-47a2-b127-57500d6113b6	b3b93f25-2072-4514-8820-74712a67ca64	7789efda-ce1b-4f2d-bec5-edf32f52e443	b1140265-ef3e-4146-857b-61d14d039b88	189d5330-50b0-40a1-8ec5-8cd0211f7b72	2026-06-03	7	185.0000	\N	ATO evidence prep	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-04 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
990e7931-a52d-4070-b179-a30e3ba22671	b3b93f25-2072-4514-8820-74712a67ca64	118ec485-9938-4146-9d0b-943c007ffc64	b1140265-ef3e-4146-857b-61d14d039b88	27fe3905-f7d8-4b4e-a720-b6946a5a8ca4	2026-06-03	8	185.0000	\N	STIG remediation	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-04 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
aeffdc63-1748-461a-87b8-0eb13faf8e6d	b3b93f25-2072-4514-8820-74712a67ca64	18198088-f46b-420d-a37e-0b7d8d968855	b1140265-ef3e-4146-857b-61d14d039b88	39c3c7bb-8de9-454a-93a0-1ac653d52725	2026-06-03	6	175.0000	\N	Code review & test	BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-04 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
9daced00-d1ab-428b-9d80-08ee2bcd97c4	b3b93f25-2072-4514-8820-74712a67ca64	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	b1140265-ef3e-4146-857b-61d14d039b88	39e9a20c-0d29-42b7-bc40-8e723a4d7ce5	2026-06-03	7	215.0000	\N	SIEM rule tuning	NON_BILLABLE	APPROVED	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-04 13:24:16.685	{}	2026-06-03 13:24:16.837	2026-06-03 13:24:16.837
\.


--
-- Data for Name: user_preferences; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.user_preferences (id, user_id, theme_id, theme_mode, sidebar_position, navigation_style, density, default_board_id, methodology, created_at, updated_at, bg_dark_url, bg_light_url, dnd_enabled, dnd_start, dnd_end, dnd_timezone) FROM stdin;
df256de7-abfe-4c2c-b704-8b1f556633f9	8ec2805b-aaaf-4e66-9ab2-e03f49882cf4	\N	\N	LEFT	BOTH	COMFORTABLE	\N	\N	2026-05-28 02:38:17.739	2026-05-28 02:38:17.739	/uploads/bg/8ec2805b-aaaf-4e66-9ab2-e03f49882cf4-dark.jpg	\N	f	\N	\N	\N
96da54cf-11b0-41d7-a92c-8d7e7f4b7d28	0c7db1b0-6842-4f34-a845-84f41b1bf498	\N	\N	LEFT	BOTH	COMFORTABLE	\N	\N	2026-05-28 13:15:23.59	2026-05-28 13:15:23.59	\N	\N	f	\N	\N	\N
cb6fc1da-3f34-42fe-b8ad-f563cee5f620	f1244511-9f53-4a78-b4d0-91851b50de2e	\N	\N	LEFT	BOTH	COMFORTABLE	\N	\N	2026-05-22 16:54:27.053	2026-05-30 03:37:11.162	\N	\N	f	\N	\N	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.users (id, auth0_user_id, email, display_name, avatar_url, last_active_at, created_at, google_id, google_refresh_token, is_bot, custom_status, custom_status_emoji, dnd_until_at) FROM stdin;
8ec2805b-aaaf-4e66-9ab2-e03f49882cf4	\N	fightingsmartcyber@gmail.com	Jon (test)	\N	2026-05-21 14:46:40.917	2026-05-21 14:46:40.917	\N	\N	f	\N	\N	\N
0c7db1b0-6842-4f34-a845-84f41b1bf498	\N	dev-playwright@cosmos.local	Dev Playwright	\N	\N	2026-05-28 13:09:26.133	\N	\N	f	\N	\N	\N
ee850f7d-f9e2-47ad-9d78-01e4a8175f17	\N	alice@test.local	Alice	\N	\N	2026-05-28 17:47:16.141	\N	\N	f	\N	\N	\N
47ed672c-c15d-41e4-ab63-08fb039d08d2	\N	bob@test.local	Bob	\N	\N	2026-05-28 17:47:16.143	\N	\N	f	\N	\N	\N
f1244511-9f53-4a78-b4d0-91851b50de2e	\N	jon@fightingsmartcyber.com	Jon Rannabargar	\N	2026-06-02 15:10:08.159	2026-05-21 19:35:18.328	100805722328975796688	1//05vGqTFSfK8ucCgYIARAAGAUSNwF-L9IrQLEferPImw_FDCRPpMy6SM9UgWYUGM_f6iKAFlapDZjM9wU5dbl-U2pAGwsEGuTHR6Y	f	\N	\N	\N
33f5b603-e18d-4a3e-87c5-3cf39f7173c4	\N	dana.reyes@apex-defense.local	Dana Reyes	\N	\N	2026-06-03 02:37:49.152	\N	\N	f	\N	\N	\N
919f24b6-1143-4f55-b96b-067f50a59619	\N	marcus.hale@apex-defense.local	Marcus Hale	\N	\N	2026-06-03 02:37:49.153	\N	\N	f	\N	\N	\N
241480b1-17de-4c30-975e-722aa992e640	\N	priya.nair@apex-defense.local	Priya Nair	\N	\N	2026-06-03 02:37:49.155	\N	\N	f	\N	\N	\N
59d381c3-1431-4a07-bc42-57b1d6cac472	\N	tom.becker@apex-defense.local	Tom Becker	\N	\N	2026-06-03 02:37:49.157	\N	\N	f	\N	\N	\N
7789efda-ce1b-4f2d-bec5-edf32f52e443	\N	alicia.chen@apex-defense.local	Alicia Chen	\N	\N	2026-06-03 13:24:16.79	\N	\N	f	\N	\N	\N
118ec485-9938-4146-9d0b-943c007ffc64	\N	ben.okoro@apex-defense.local	Ben Okoro	\N	\N	2026-06-03 13:24:16.792	\N	\N	f	\N	\N	\N
18198088-f46b-420d-a37e-0b7d8d968855	\N	sara.kim@apex-defense.local	Sara Kim	\N	\N	2026-06-03 13:24:16.794	\N	\N	f	\N	\N	\N
83e86a90-6e51-498b-b8b8-c6ef124058d2	\N	steve@fightingsmartcyber.com	Steve Katzman	\N	2026-06-04 13:05:27.785	2026-05-26 19:16:37.983	106841141819679514274	1//050wJuVQ-ufp_CgYIARAAGAUSNwF-L9Irv6hAdrRWhqfKs0cjPoKGv4SW6c745EyBOmMvzqSRWrjxakV9yGKTi7BQdeUdu09ngXc	f	\N	\N	\N
405c6daf-aaf3-4ef6-8af4-c5076e2106f6	\N	bot+assistant@b3b93f25-2072-4514-8820-74712a67ca64.cosmos.local	Assistant	\N	\N	2026-06-05 04:11:55.208	\N	\N	t	\N	\N	\N
a53d65bc-a02d-4c44-a4cb-20c2c4bb03c7	\N	bot+notetaker@b3b93f25-2072-4514-8820-74712a67ca64.cosmos.local	Note-taker	\N	\N	2026-06-05 04:11:55.214	\N	\N	t	\N	\N	\N
f662c298-69e3-4352-b6d1-66ca2a6307d4	\N	bot+answerer@b3b93f25-2072-4514-8820-74712a67ca64.cosmos.local	Answerer	\N	\N	2026-06-05 04:11:55.222	\N	\N	t	\N	\N	\N
f32a094e-3b86-45aa-a2ce-fbe8edf2d360	\N	bot+standup@b3b93f25-2072-4514-8820-74712a67ca64.cosmos.local	Standup	\N	\N	2026-06-05 04:11:55.228	\N	\N	t	\N	\N	\N
\.


--
-- Data for Name: webhook_deliveries; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.webhook_deliveries (id, webhook_id, event, payload, status, status_code, response_body, attempts, last_attempt_at, created_at) FROM stdin;
\.


--
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.webhooks (id, org_id, url, events, secret, active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: work_item_type_fields; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.work_item_type_fields (id, work_item_type_id, custom_field_id, required, sort_order) FROM stdin;
\.


--
-- Data for Name: work_item_types; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.work_item_types (id, org_id, project_template_id, key, name, plural_name, icon, color, is_built_in, sort_order, default_parent_type_key, celebrate_on_complete, created_at) FROM stdin;
a2fd0275-038f-4a64-a78e-0bdd0ae00ea0	\N	\N	cross.goal	Goal	Goals	Target	#2563eb	t	0	\N	t	2026-05-26 02:52:54.864
3d900f66-66a5-49a3-b36e-a0ffc637315e	\N	\N	cross.milestone	Milestone	Milestones	Flag	#8b5cf6	t	1	\N	f	2026-05-26 02:52:54.867
dbae9033-e08d-44fc-a888-76a0cf4a11c0	\N	\N	cross.kpi	KPI	KPIs	Gauge	#0891b2	t	2	\N	t	2026-05-26 02:52:54.869
8d86e9e4-d20d-4f9d-9c1c-e32fd20d0f72	\N	\N	cross.objective	Objective	Objectives	Compass	#6366f1	t	3	\N	f	2026-05-26 02:52:54.87
7c339221-95a5-4f41-a040-dd4bbb77d355	\N	\N	cross.key_result	Key Result	Key Results	TrendingUp	#10b981	t	4	cross.objective	t	2026-05-26 02:52:54.872
0eeea80b-4c52-4574-a241-7eadf8b38acd	\N	\N	cross.risk	Risk	Risks	ShieldAlert	#ef4444	t	5	\N	f	2026-05-26 02:52:54.874
9943b2d0-fb82-4e95-abec-8843ede2e49b	\N	\N	cross.decision	Decision	Decisions	Gavel	#f59e0b	t	6	\N	f	2026-05-26 02:52:54.875
410839a1-86ad-411d-a1fe-2429c9905da0	\N	\N	cross.meeting_note	Meeting Note	Meeting Notes	FileText	#64748b	t	7	\N	f	2026-05-26 02:52:54.877
bdb63607-8d83-4e9e-939e-fd359c7df9df	\N	\N	software.epic	Epic	Epics	Layers	#8b5cf6	t	0	\N	f	2026-05-26 02:52:54.879
dd2d1d76-3ece-4390-a45c-e7a1951a037b	\N	\N	software.story	Story	Stories	BookOpen	#3b82f6	t	1	software.epic	f	2026-05-26 02:52:54.88
a8ff2b31-4993-4421-938e-4b5acd36e98a	\N	\N	software.task	Task	Tasks	CheckSquare	#10b981	t	2	software.story	t	2026-05-26 02:52:54.881
a465f298-2314-4aea-83dc-e9833c54a9b9	\N	\N	software.bug	Bug	Bugs	Bug	#ef4444	t	3	\N	t	2026-05-26 02:52:54.883
6c711a94-463a-427a-8d1b-37ed3bbeeff2	\N	\N	aec.safety_incident	Safety Incident	Safety Incidents	ShieldAlert	#dc2626	t	7	\N	f	2026-05-26 02:58:17.437
53f229b5-f2a2-44b1-af72-960f49d64aed	\N	\N	aec.cost_impact_item	Cost Impact	Cost Impacts	DollarSign	#ca8a04	t	8	aec.change_order	f	2026-05-26 02:58:17.439
1d7b0fe3-7e39-44e9-9d50-62961d5536f3	\N	\N	ops.problem	Problem	Problems	AlertOctagon	#dc2626	t	0	\N	f	2026-05-26 02:58:17.456
d44cf4fb-32d8-4016-9a12-d9cc91f4c2e1	\N	\N	ops.incident	Incident	Incidents	AlertTriangle	#ef4444	t	1	ops.problem	f	2026-05-26 02:58:17.458
8af367b5-9a55-4c1e-a0f8-297f983abe18	\N	\N	ops.action_item	Action Item	Action Items	CheckCircle	#10b981	t	2	ops.incident	t	2026-05-26 02:58:17.459
947aeb9b-4c59-48ca-b9d8-03de1238f684	\N	\N	ops.change_request	Change Request	Change Requests	GitPullRequest	#3b82f6	t	3	\N	f	2026-05-26 02:58:17.46
4e1565ad-cf3c-4f30-82a2-0482955d93b6	\N	\N	ops.implementation_task	Implementation Task	Implementation Tasks	Wrench	#6366f1	t	4	ops.change_request	t	2026-05-26 02:58:17.462
935f4e85-13a2-45f8-9a67-3ca87415d2e4	\N	\N	ops.service_request	Service Request	Service Requests	Ticket	#8b5cf6	t	5	\N	f	2026-05-26 02:58:17.463
33757073-7b62-407e-a6af-c3f6241cabc4	\N	\N	ops.postmortem	Postmortem	Postmortems	FileSearch	#64748b	t	6	\N	f	2026-05-26 02:58:17.464
a548c80c-8063-4f44-a855-c73c28bb220d	\N	\N	consulting.engagement	Engagement	Engagements	Handshake	#6366f1	t	0	\N	f	2026-05-26 02:58:17.477
a0b72063-de5a-46af-b761-3b731e24f0f6	\N	\N	consulting.workstream	Workstream	Workstreams	GitBranch	#3b82f6	t	1	consulting.engagement	f	2026-05-26 02:58:17.479
50b2fb87-fb77-490b-b706-b827a25425e9	\N	\N	consulting.deliverable	Deliverable	Deliverables	Package	#10b981	t	2	consulting.workstream	t	2026-05-26 02:58:17.48
eaf4f751-055c-48ca-8e95-068ab3014780	\N	\N	consulting.task	Task	Tasks	CheckSquare	#64748b	t	3	consulting.deliverable	t	2026-05-26 02:58:17.481
dd24be56-3a0f-4651-9dde-34eca8e8b5d7	\N	\N	software.subtask	Subtask	Subtasks	ListChecks	#64748b	t	4	software.story	t	2026-05-26 02:52:54.884
5e514b21-5c83-42e2-90ea-7640ddce8c02	\N	\N	aec.phase	Phase	Phases	Milestone	#6366f1	t	0	\N	f	2026-05-26 02:58:17.416
c68d119e-5842-4dfe-bfad-bcbb178b4eb0	\N	\N	aec.submittal	Submittal	Submittals	FileStack	#3b82f6	t	1	aec.phase	f	2026-05-26 02:58:17.417
c9bf5754-f1b7-4567-92ff-edaab0c73415	\N	\N	aec.rfi	RFI	RFIs	FileQuestion	#f59e0b	t	2	aec.phase	f	2026-05-26 02:58:17.419
88997d11-a9f6-4778-aa82-99cb729765c9	\N	\N	consulting.milestone_item	Milestone	Milestones	Flag	#f59e0b	t	4	\N	t	2026-05-26 02:58:17.482
8d6ee442-278f-4d28-9468-ef6de035e2d2	\N	\N	manufacturing.production_order	Production Order	Production Orders	Factory	#6366f1	t	0	\N	f	2026-05-26 02:58:17.495
e420690c-11a6-4e9b-bd8d-df21c1edc7f3	\N	\N	manufacturing.work_order	Work Order	Work Orders	ClipboardList	#3b82f6	t	1	manufacturing.production_order	f	2026-05-26 02:58:17.496
6778e2a0-47d5-4b76-9210-1e67a58f95a8	\N	\N	aec.change_order	Change Order	Change Orders	FileEdit	#ef4444	t	3	aec.phase	f	2026-05-26 02:58:17.432
b84b3991-379f-41a7-9cbc-c5b3d16c9d73	\N	\N	aec.asi	ASI	ASIs	FilePlus	#8b5cf6	t	4	aec.phase	f	2026-05-26 02:58:17.433
1c2569cc-6e83-4299-be47-d502d97764bf	\N	\N	aec.ccd	CCD	CCDs	FileWarning	#a855f7	t	5	aec.phase	f	2026-05-26 02:58:17.434
f1b5f8d5-895e-41af-b20f-503053afa801	\N	\N	aec.punch_item	Punch Item	Punch Items	ListChecks	#10b981	t	6	aec.phase	t	2026-05-26 02:58:17.436
d31e03b9-af1a-422e-94cb-74447cef2366	\N	\N	event.vendor	Vendor	Vendors	Store	#10b981	t	2	\N	f	2026-05-26 02:58:17.538
99a87df8-28ee-401f-900f-e79f93d449d6	\N	\N	event.logistics_item	Logistics Item	Logistics Items	Truck	#f59e0b	t	3	\N	f	2026-05-26 02:58:17.539
51c8a409-942b-46d6-81b6-9be58baa650b	\N	\N	event.run_of_show_item	Run of Show Item	Run of Show Items	ListOrdered	#8b5cf6	t	4	event.session	f	2026-05-26 02:58:17.541
cc810aa6-1162-4075-bc48-8539a8572cfc	\N	\N	event.permit	Permit	Permits	FileCheck	#0891b2	t	5	\N	f	2026-05-26 02:58:17.542
a2bf48cc-e3bf-43dc-8285-fb5812bdddeb	\N	\N	event.bid	Bid	Bids	Tag	#64748b	t	6	\N	f	2026-05-26 02:58:17.543
9bf5ea41-c33f-4d91-af90-508e3abcbb4b	\N	\N	event.contract	Contract	Contracts	FileSignature	#059669	t	7	event.bid	f	2026-05-26 02:58:17.545
a83937e6-5b1d-48dc-8a73-5321743c668b	\N	\N	manufacturing.operation	Operation	Operations	Cog	#10b981	t	2	manufacturing.work_order	f	2026-05-26 02:58:17.498
713f1e4d-0e2c-4b37-85d6-c3b4962b1b19	\N	\N	manufacturing.step	Step	Steps	ArrowRight	#64748b	t	3	manufacturing.operation	t	2026-05-26 02:58:17.499
44d7960d-d06a-4455-97a8-54a7d05628d4	\N	\N	manufacturing.ncr	NCR	NCRs	AlertTriangle	#ef4444	t	4	\N	f	2026-05-26 02:58:17.5
96c736cc-0a76-49bd-8b7a-050cd3acbb1b	\N	\N	manufacturing.car	CAR	CARs	FileWarning	#f59e0b	t	5	\N	f	2026-05-26 02:58:17.502
54c36830-e35b-4d68-95d3-11ef2497e34c	\N	\N	manufacturing.inspection_item	Inspection Item	Inspection Items	Search	#8b5cf6	t	6	\N	t	2026-05-26 02:58:17.503
c0ff5de9-4df7-4382-ab5c-5cd2aa2c458f	\N	\N	education.course	Course	Courses	BookOpen	#6366f1	t	0	\N	f	2026-05-26 02:58:17.515
4ef7c33f-209a-45ac-9cbf-735fc6169e08	\N	\N	education.module	Module	Modules	Layout	#3b82f6	t	1	education.course	f	2026-05-26 02:58:17.516
7b4b09ad-6e12-4b49-9d13-02429a462b11	\N	\N	education.lesson	Lesson	Lessons	FileText	#10b981	t	2	education.module	f	2026-05-26 02:58:17.517
d76e9557-865e-4b01-af9d-e489f278ff45	\N	\N	education.assignment	Assignment	Assignments	ClipboardCheck	#f59e0b	t	3	education.lesson	f	2026-05-26 02:58:17.519
4a387c28-65c8-476f-b775-949c52ba9758	\N	\N	education.submission	Submission	Submissions	Upload	#8b5cf6	t	4	education.assignment	t	2026-05-26 02:58:17.521
0829e536-ee6d-4d3e-b552-50c17dd6c6e8	\N	\N	education.outcome	Learning Outcome	Learning Outcomes	Target	#0891b2	t	5	\N	f	2026-05-26 02:58:17.523
ef53b266-ada5-47b5-ad1b-eb17f97cb326	\N	\N	event.event_day	Event Day	Event Days	CalendarDays	#6366f1	t	0	\N	f	2026-05-26 02:58:17.535
63e2c8dd-f713-4e8a-8ded-4cfb629ab6b9	\N	\N	event.session	Session	Sessions	Clock	#3b82f6	t	1	event.event_day	f	2026-05-26 02:58:17.536
\.


--
-- Data for Name: work_items; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.work_items (id, org_id, project_id, title, description, column_key, assignee_id, priority, parent_id, ticket_number, story_points, sort_order, due_date, start_date, completed_at, column_entered_at, tags, custom_fields, created_by_id, created_at, updated_at, cycle_id, work_item_type_id, search_vector) FROM stdin;
cf9cd7f6-67ec-445c-9dc8-3cf149094c8c	7977bb8b-71a5-4117-8e09-f2313d7f7c4e	d816eefb-9664-4e3e-ba50-f4fbb255d61d	Audit work item		todo	\N	MEDIUM	\N	1	\N	0	\N	\N	\N	2026-06-02 23:46:47.718	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-05-30 21:05:54.533	2026-06-02 23:46:49.011	\N	a8ff2b31-4993-4421-938e-4b5acd36e98a	{"tf": [1, 1, 1], "tokens": ["audit", "work", "item"]}
d60989b3-6bca-4a76-b3cf-082f3ddfe3e9	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Implement FIPS 140-3 validated crypto module for data-at-rest		done	241480b1-17de-4c30-975e-722aa992e640	HIGH	\N	1	8	0	\N	\N	2026-05-29 02:37:49.039	\N	{CUI}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 02:37:49.179	2026-06-03 02:37:49.179	25cb73c5-f1ca-48e4-a2a3-e305e6bf7739	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
eca32c38-d0ba-4bde-9574-76f90ec1e282	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Remediate STIG CAT I findings on the RHEL 9 baseline		done	241480b1-17de-4c30-975e-722aa992e640	CRITICAL	\N	2	5	1	\N	\N	2026-05-31 02:37:49.039	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 02:37:49.179	2026-06-03 02:37:49.179	25cb73c5-f1ca-48e4-a2a3-e305e6bf7739	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
52e52b9b-05f0-4434-8f7c-83757c3d9772	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	CUI tagging + DLP enforcement on the telemetry pipeline		done	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	HIGH	\N	3	8	2	\N	\N	2026-06-01 02:37:49.039	\N	{CUI}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 02:37:49.179	2026-06-03 02:37:49.179	25cb73c5-f1ca-48e4-a2a3-e305e6bf7739	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
27fe3905-f7d8-4b4e-a720-b6946a5a8ca4	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	ATO package: update SSP control families AC, AU, SC		in-progress	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	CRITICAL	\N	4	13	3	2026-06-01 02:37:49.039	\N	\N	\N	{CUI}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 02:37:49.179	2026-06-03 02:37:49.179	25cb73c5-f1ca-48e4-a2a3-e305e6bf7739	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
4d3b494c-c591-46c2-9de1-25a0aec71a69	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	CAC/PIV multifactor authentication integration		done	241480b1-17de-4c30-975e-722aa992e640	HIGH	\N	5	5	4	\N	\N	2026-06-02 02:37:49.039	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 02:37:49.179	2026-06-03 02:37:49.179	25cb73c5-f1ca-48e4-a2a3-e305e6bf7739	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
de5a0237-0d31-488a-b201-5cc7cf4bfd00	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Remediate Q2 Nessus vulnerability findings (CAT II)		todo	241480b1-17de-4c30-975e-722aa992e640	HIGH	\N	6	5	5	2026-06-02 02:37:49.039	\N	\N	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 02:37:49.179	2026-06-03 02:37:49.179	25cb73c5-f1ca-48e4-a2a3-e305e6bf7739	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
f509f8c6-7c32-489b-bb3d-0454ff02a951	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Configure cross-domain boundary protection rules		done	f1244511-9f53-4a78-b4d0-91851b50de2e	MEDIUM	\N	7	8	6	\N	\N	2026-06-02 14:37:49.039	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 02:37:49.179	2026-06-03 02:37:49.179	25cb73c5-f1ca-48e4-a2a3-e305e6bf7739	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
03ca3d82-fb93-417b-ac0b-931f1605cb87	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Author incident-response runbook for CUI spillage		review	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	MEDIUM	\N	8	3	7	2026-06-05 02:37:49.039	\N	\N	\N	{CUI}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 02:37:49.179	2026-06-03 02:37:49.179	25cb73c5-f1ca-48e4-a2a3-e305e6bf7739	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
a984f166-eb59-4c4d-a5c8-514d2acaa271	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Supply-chain risk assessment (NIST SP 800-161) for subcontractors		todo	919f24b6-1143-4f55-b96b-067f50a59619	MEDIUM	\N	9	5	8	2026-06-08 02:37:49.039	\N	\N	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 02:37:49.179	2026-06-03 02:37:49.179	25cb73c5-f1ca-48e4-a2a3-e305e6bf7739	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
bf987815-c92b-4bbd-badb-91bc0abbae97	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Stand up GovCloud landing zone (IL4)		done	7789efda-ce1b-4f2d-bec5-edf32f52e443	MEDIUM	\N	10	8	1	\N	\N	2026-03-28 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.808	2026-06-03 13:24:16.808	7a9c71dd-c7fa-4305-bdce-c587c5526292	dd2d1d76-3ece-4390-a45c-e7a1951a037b	\N
8cc7f32a-d5af-4104-96f7-45588f53eb3b	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Implement RMF control inheritance from the CSP		done	18198088-f46b-420d-a37e-0b7d8d968855	MEDIUM	\N	11	5	2	\N	\N	2026-03-28 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.808	2026-06-03 13:24:16.808	7a9c71dd-c7fa-4305-bdce-c587c5526292	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
8ed71a12-9798-472c-82bd-49dfdb821bc1	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Integrate Splunk for centralized audit logging		done	241480b1-17de-4c30-975e-722aa992e640	MEDIUM	\N	12	5	3	\N	\N	2026-03-28 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.808	2026-06-03 13:24:16.808	7a9c71dd-c7fa-4305-bdce-c587c5526292	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
9a4b9adb-1d9b-4637-9552-5497095d583a	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Develop CUI data-flow diagrams for the SSP		done	118ec485-9938-4146-9d0b-943c007ffc64	MEDIUM	\N	13	3	4	\N	\N	2026-03-28 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.808	2026-06-03 13:24:16.808	7a9c71dd-c7fa-4305-bdce-c587c5526292	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
2863b5fe-6835-4e42-b71e-cb8635403c19	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Establish PKI / CAC authentication		done	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	MEDIUM	\N	14	8	5	\N	\N	2026-03-28 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.808	2026-06-03 13:24:16.808	7a9c71dd-c7fa-4305-bdce-c587c5526292	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
c18fd7f0-2faa-4880-917e-013dc5dee9eb	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Container image hardening (DISA STIG)		done	7789efda-ce1b-4f2d-bec5-edf32f52e443	MEDIUM	\N	15	5	6	\N	\N	2026-03-28 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.808	2026-06-03 13:24:16.808	7a9c71dd-c7fa-4305-bdce-c587c5526292	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
8486ee0e-909b-49dc-9995-3aa3b05a357f	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Build CI/CD pipeline with security gates		done	118ec485-9938-4146-9d0b-943c007ffc64	MEDIUM	\N	16	8	7	\N	\N	2026-04-12 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.811	2026-06-03 13:24:16.811	4301fadb-47ad-42ea-b1a1-051f175d0058	dd2d1d76-3ece-4390-a45c-e7a1951a037b	\N
f7d355a0-cc69-4a9b-8627-0d5990d9d91e	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Automate STIG compliance scanning (SCAP)		done	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	MEDIUM	\N	17	5	8	\N	\N	2026-04-12 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.811	2026-06-03 13:24:16.811	4301fadb-47ad-42ea-b1a1-051f175d0058	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
b283d45c-4900-4a20-a8d6-a8261f78744f	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Deploy FIPS-validated TLS across services		done	7789efda-ce1b-4f2d-bec5-edf32f52e443	MEDIUM	\N	18	5	9	\N	\N	2026-04-12 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.811	2026-06-03 13:24:16.811	4301fadb-47ad-42ea-b1a1-051f175d0058	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
bc1db502-c956-47e6-bf58-8c45c7c6ba41	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Set up vulnerability management (ACAS/Nessus)		done	18198088-f46b-420d-a37e-0b7d8d968855	MEDIUM	\N	19	5	10	\N	\N	2026-04-12 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.811	2026-06-03 13:24:16.811	4301fadb-47ad-42ea-b1a1-051f175d0058	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
f592497b-2a9c-44bf-ac25-deecb34d6a67	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Implement role-based access control (RBAC)		done	241480b1-17de-4c30-975e-722aa992e640	MEDIUM	\N	20	8	11	\N	\N	2026-04-12 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.811	2026-06-03 13:24:16.811	4301fadb-47ad-42ea-b1a1-051f175d0058	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
f42e0ca8-c5dd-4b5e-a096-b3be926097b3	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Configure boundary firewall rules		done	118ec485-9938-4146-9d0b-943c007ffc64	MEDIUM	\N	21	3	12	\N	\N	2026-04-12 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.811	2026-06-03 13:24:16.811	4301fadb-47ad-42ea-b1a1-051f175d0058	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
711e9201-22c6-4900-af22-099f468d2ab7	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Telemetry ingestion service v1		done	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	MEDIUM	\N	22	8	13	\N	\N	2026-04-12 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.811	2026-06-03 13:24:16.811	4301fadb-47ad-42ea-b1a1-051f175d0058	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
b07745f3-c248-497b-9398-4575198505e3	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Develop threat dashboard UI		done	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	MEDIUM	\N	23	8	14	\N	\N	2026-04-27 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.815	2026-06-03 13:24:16.815	8bfc5efb-4c06-4dbe-a4a8-d68c7092030a	dd2d1d76-3ece-4390-a45c-e7a1951a037b	\N
91eb6e27-76bc-4190-8098-4c018e670fc3	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Integrate MISP threat-intelligence feed		done	7789efda-ce1b-4f2d-bec5-edf32f52e443	MEDIUM	\N	24	5	15	\N	\N	2026-04-27 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.815	2026-06-03 13:24:16.815	8bfc5efb-4c06-4dbe-a4a8-d68c7092030a	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
cf8e9eb9-e3da-4f44-a498-17430f5727dc	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Privileged access management (PAM) rollout		done	18198088-f46b-420d-a37e-0b7d8d968855	MEDIUM	\N	25	5	16	\N	\N	2026-04-27 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.815	2026-06-03 13:24:16.815	8bfc5efb-4c06-4dbe-a4a8-d68c7092030a	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
9c029257-0a4a-4581-8029-653aab69f636	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Configure SIEM correlation rules		done	241480b1-17de-4c30-975e-722aa992e640	MEDIUM	\N	26	5	17	\N	\N	2026-04-27 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.815	2026-06-03 13:24:16.815	8bfc5efb-4c06-4dbe-a4a8-d68c7092030a	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
3cd69862-4b9e-4fb2-a379-8bb2d09cbd42	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Data-at-rest encryption (FIPS 140-3)		done	118ec485-9938-4146-9d0b-943c007ffc64	MEDIUM	\N	27	8	18	\N	\N	2026-04-27 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.815	2026-06-03 13:24:16.815	8bfc5efb-4c06-4dbe-a4a8-d68c7092030a	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
ac080c85-a091-4d44-8d01-9d482d4ef349	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Implement session timeout & lockout policies		done	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	MEDIUM	\N	28	3	19	\N	\N	2026-04-27 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.815	2026-06-03 13:24:16.815	8bfc5efb-4c06-4dbe-a4a8-d68c7092030a	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
66305e03-cc46-458f-bf9f-18597bd1a378	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Anomaly-detection model v1		done	241480b1-17de-4c30-975e-722aa992e640	MEDIUM	\N	29	13	20	\N	\N	2026-05-12 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.818	2026-06-03 13:24:16.818	19337766-db98-4ae9-bcd3-1dcd1215d310	dd2d1d76-3ece-4390-a45c-e7a1951a037b	\N
ac8ccf6d-c662-4ead-8b51-aac5b9e665ed	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Develop API gateway with mTLS		done	118ec485-9938-4146-9d0b-943c007ffc64	MEDIUM	\N	30	8	21	\N	\N	2026-05-12 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.818	2026-06-03 13:24:16.818	19337766-db98-4ae9-bcd3-1dcd1215d310	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
ca87f783-dfba-484b-9247-29d6b23d269c	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Configure DLP for CUI egress		done	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	MEDIUM	\N	31	5	22	\N	\N	2026-05-12 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.818	2026-06-03 13:24:16.818	19337766-db98-4ae9-bcd3-1dcd1215d310	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
5e0b7e60-92c0-43ac-bb58-5ddc79ed5827	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Implement backup & DR runbook		done	7789efda-ce1b-4f2d-bec5-edf32f52e443	MEDIUM	\N	32	5	23	\N	\N	2026-05-12 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.818	2026-06-03 13:24:16.818	19337766-db98-4ae9-bcd3-1dcd1215d310	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
877d482d-9106-4290-94d7-c12068d387b5	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Penetration test remediation (round 1)		done	18198088-f46b-420d-a37e-0b7d8d968855	MEDIUM	\N	33	8	24	\N	\N	2026-05-12 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.818	2026-06-03 13:24:16.818	19337766-db98-4ae9-bcd3-1dcd1215d310	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
1a6fc40a-f254-4575-8156-ef02eb3f3f7a	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	SBOM generation in build pipeline		done	241480b1-17de-4c30-975e-722aa992e640	MEDIUM	\N	34	3	25	\N	\N	2026-05-12 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.818	2026-06-03 13:24:16.818	19337766-db98-4ae9-bcd3-1dcd1215d310	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
e6ba2a54-1d81-42d6-81ed-6e54dd4ff780	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Implement audit-log tamper protection		done	118ec485-9938-4146-9d0b-943c007ffc64	MEDIUM	\N	35	5	26	\N	\N	2026-05-12 13:24:16.685	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.818	2026-06-03 13:24:16.818	19337766-db98-4ae9-bcd3-1dcd1215d310	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
f5da244b-282b-4241-bb57-27ef2447bca3	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Increment 3 capability roadmap		backlog	\N	CRITICAL	\N	36	13	0	\N	\N	\N	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.822	2026-06-03 13:24:16.822	\N	bdb63607-8d83-4e9e-939e-fd359c7df9df	\N
83513990-1e1b-4831-99d9-5f25a03e4e5c	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	ML-based threat scoring v2		todo	7789efda-ce1b-4f2d-bec5-edf32f52e443	HIGH	\N	37	13	1	\N	\N	\N	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.822	2026-06-03 13:24:16.822	\N	bdb63607-8d83-4e9e-939e-fd359c7df9df	\N
3fcf248b-3f8f-4212-9533-81639019425d	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Multi-region failover (GovCloud East/West)		todo	118ec485-9938-4146-9d0b-943c007ffc64	HIGH	\N	38	8	2	\N	\N	\N	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.822	2026-06-03 13:24:16.822	\N	dd2d1d76-3ece-4390-a45c-e7a1951a037b	\N
b8d66c27-6dfd-4309-9d83-724a1af00951	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	FedRAMP High readiness assessment		backlog	18198088-f46b-420d-a37e-0b7d8d968855	MEDIUM	\N	39	8	3	\N	\N	\N	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.822	2026-06-03 13:24:16.822	\N	dd2d1d76-3ece-4390-a45c-e7a1951a037b	\N
6b56e81f-83c8-49d6-90cc-2e7f362d2983	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Integrate JADC2 data fabric		todo	\N	MEDIUM	\N	40	13	4	\N	\N	\N	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.822	2026-06-03 13:24:16.822	\N	bdb63607-8d83-4e9e-939e-fd359c7df9df	\N
487e7b8e-7f03-4e86-83ce-56d2c980490a	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	CAC-enabled mobile companion app		todo	241480b1-17de-4c30-975e-722aa992e640	LOW	\N	41	8	5	\N	\N	\N	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.822	2026-06-03 13:24:16.822	\N	dd2d1d76-3ece-4390-a45c-e7a1951a037b	\N
9405945c-fc8a-4190-b5d9-0f3992a5c903	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Automated POA&M remediation workflows		backlog	7789efda-ce1b-4f2d-bec5-edf32f52e443	HIGH	\N	42	5	6	\N	\N	\N	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.822	2026-06-03 13:24:16.822	\N	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
e041f853-c92b-462f-a3ac-3b9f6b97b7d7	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Quantum-resistant crypto evaluation		todo	118ec485-9938-4146-9d0b-943c007ffc64	LOW	\N	43	5	7	\N	\N	\N	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.822	2026-06-03 13:24:16.822	\N	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
95dd2ba3-d4e7-4a22-a1a6-029e203af38a	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Real-time collaboration for SOC analysts		todo	\N	MEDIUM	\N	44	5	8	\N	\N	\N	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.822	2026-06-03 13:24:16.822	\N	dd2d1d76-3ece-4390-a45c-e7a1951a037b	\N
39e9a20c-0d29-42b7-bc40-8e723a4d7ce5	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	Expand to IL5 enclave		backlog	33f5b603-e18d-4a3e-87c5-3cf39f7173c4	MEDIUM	\N	45	8	9	\N	\N	\N	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.822	2026-06-03 13:24:16.822	\N	dd2d1d76-3ece-4390-a45c-e7a1951a037b	\N
39c3c7bb-8de9-454a-93a0-1ac653d52725	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	AI explainability for threat verdicts		todo	241480b1-17de-4c30-975e-722aa992e640	MEDIUM	\N	46	5	10	\N	\N	\N	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.822	2026-06-03 13:24:16.822	\N	a8ff2b31-4993-4421-938e-4b5acd36e98a	\N
189d5330-50b0-40a1-8ec5-8cd0211f7b72	b3b93f25-2072-4514-8820-74712a67ca64	b1140265-ef3e-4146-857b-61d14d039b88	PMO self-service reporting portal		todo	7789efda-ce1b-4f2d-bec5-edf32f52e443	LOW	\N	47	5	11	\N	\N	\N	\N	{}	{}	f1244511-9f53-4a78-b4d0-91851b50de2e	2026-06-03 13:24:16.822	2026-06-03 13:24:16.822	\N	dd2d1d76-3ece-4390-a45c-e7a1951a037b	\N
\.


--
-- Data for Name: work_roles; Type: TABLE DATA; Schema: public; Owner: cosmos
--

COPY public.work_roles (id, org_id, key, name, description, grants, policies, is_built_in, created_at, updated_at) FROM stdin;
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: accounting_periods accounting_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.accounting_periods
    ADD CONSTRAINT accounting_periods_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: activities activities_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY (id);


--
-- Name: allowed_emails allowed_emails_email_key; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_email_key UNIQUE (email);


--
-- Name: allowed_emails allowed_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: assistant_conversations assistant_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.assistant_conversations
    ADD CONSTRAINT assistant_conversations_pkey PRIMARY KEY (id);


--
-- Name: assistant_messages assistant_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.assistant_messages
    ADD CONSTRAINT assistant_messages_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: bank_accounts bank_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.bank_accounts
    ADD CONSTRAINT bank_accounts_pkey PRIMARY KEY (id);


--
-- Name: bank_rules bank_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.bank_rules
    ADD CONSTRAINT bank_rules_pkey PRIMARY KEY (id);


--
-- Name: bank_transactions bank_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.bank_transactions
    ADD CONSTRAINT bank_transactions_pkey PRIMARY KEY (id);


--
-- Name: board_columns board_columns_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.board_columns
    ADD CONSTRAINT board_columns_pkey PRIMARY KEY (id);


--
-- Name: board_template_widgets board_template_widgets_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.board_template_widgets
    ADD CONSTRAINT board_template_widgets_pkey PRIMARY KEY (id);


--
-- Name: board_templates board_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.board_templates
    ADD CONSTRAINT board_templates_pkey PRIMARY KEY (id);


--
-- Name: boards boards_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.boards
    ADD CONSTRAINT boards_pkey PRIMARY KEY (id);


--
-- Name: chat_alert_keywords chat_alert_keywords_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_alert_keywords
    ADD CONSTRAINT chat_alert_keywords_pkey PRIMARY KEY (id);


--
-- Name: chat_bot_channels chat_bot_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_bot_channels
    ADD CONSTRAINT chat_bot_channels_pkey PRIMARY KEY (id);


--
-- Name: chat_bot_runs chat_bot_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_bot_runs
    ADD CONSTRAINT chat_bot_runs_pkey PRIMARY KEY (id);


--
-- Name: chat_bots chat_bots_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_bots
    ADD CONSTRAINT chat_bots_pkey PRIMARY KEY (id);


--
-- Name: chat_channel_members chat_channel_members_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_channel_members
    ADD CONSTRAINT chat_channel_members_pkey PRIMARY KEY (id);


--
-- Name: chat_channels chat_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_channels
    ADD CONSTRAINT chat_channels_pkey PRIMARY KEY (id);


--
-- Name: chat_message_attachments chat_message_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_message_attachments
    ADD CONSTRAINT chat_message_attachments_pkey PRIMARY KEY (id);


--
-- Name: chat_message_mentions chat_message_mentions_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_message_mentions
    ADD CONSTRAINT chat_message_mentions_pkey PRIMARY KEY (id);


--
-- Name: chat_message_reactions chat_message_reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_message_reactions
    ADD CONSTRAINT chat_message_reactions_pkey PRIMARY KEY (id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: chat_pinned_messages chat_pinned_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_pinned_messages
    ADD CONSTRAINT chat_pinned_messages_pkey PRIMARY KEY (id);


--
-- Name: chat_thread_followers chat_thread_followers_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_thread_followers
    ADD CONSTRAINT chat_thread_followers_pkey PRIMARY KEY (id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: compliance_controls compliance_controls_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.compliance_controls
    ADD CONSTRAINT compliance_controls_pkey PRIMARY KEY (id);


--
-- Name: contracts contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_pkey PRIMARY KEY (id);


--
-- Name: crm_contacts crm_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.crm_contacts
    ADD CONSTRAINT crm_contacts_pkey PRIMARY KEY (id);


--
-- Name: custom_fields custom_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.custom_fields
    ADD CONSTRAINT custom_fields_pkey PRIMARY KEY (id);


--
-- Name: cycle_capacities cycle_capacities_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.cycle_capacities
    ADD CONSTRAINT cycle_capacities_pkey PRIMARY KEY (id);


--
-- Name: cycles cycles_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.cycles
    ADD CONSTRAINT cycles_pkey PRIMARY KEY (id);


--
-- Name: dashboard_widgets dashboard_widgets_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.dashboard_widgets
    ADD CONSTRAINT dashboard_widgets_pkey PRIMARY KEY (id);


--
-- Name: data_classifications data_classifications_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.data_classifications
    ADD CONSTRAINT data_classifications_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: feedback_items feedback_items_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.feedback_items
    ADD CONSTRAINT feedback_items_pkey PRIMARY KEY (id);


--
-- Name: feedback_votes feedback_votes_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.feedback_votes
    ADD CONSTRAINT feedback_votes_pkey PRIMARY KEY (id);


--
-- Name: home_widgets home_widgets_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.home_widgets
    ADD CONSTRAINT home_widgets_pkey PRIMARY KEY (id);


--
-- Name: integrations integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_pkey PRIMARY KEY (id);


--
-- Name: invitations invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.invitations
    ADD CONSTRAINT invitations_pkey PRIMARY KEY (id);


--
-- Name: ip_allowlists ip_allowlists_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.ip_allowlists
    ADD CONSTRAINT ip_allowlists_pkey PRIMARY KEY (id);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: journal_lines journal_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT journal_lines_pkey PRIMARY KEY (id);


--
-- Name: key_results key_results_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.key_results
    ADD CONSTRAINT key_results_pkey PRIMARY KEY (id);


--
-- Name: mcp_servers mcp_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.mcp_servers
    ADD CONSTRAINT mcp_servers_pkey PRIMARY KEY (id);


--
-- Name: meeting_attendees meeting_attendees_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.meeting_attendees
    ADD CONSTRAINT meeting_attendees_pkey PRIMARY KEY (id);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: objectives objectives_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.objectives
    ADD CONSTRAINT objectives_pkey PRIMARY KEY (id);


--
-- Name: org_member_work_roles org_member_work_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.org_member_work_roles
    ADD CONSTRAINT org_member_work_roles_pkey PRIMARY KEY (org_member_id, work_role_id);


--
-- Name: org_members org_members_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_pkey PRIMARY KEY (id);


--
-- Name: org_security_settings org_security_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.org_security_settings
    ADD CONSTRAINT org_security_settings_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: partners partners_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: project_members project_members_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.project_members
    ADD CONSTRAINT project_members_pkey PRIMARY KEY (id);


--
-- Name: project_templates project_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.project_templates
    ADD CONSTRAINT project_templates_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: revenues revenues_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.revenues
    ADD CONSTRAINT revenues_pkey PRIMARY KEY (id);


--
-- Name: saved_reports saved_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.saved_reports
    ADD CONSTRAINT saved_reports_pkey PRIMARY KEY (id);


--
-- Name: scim_tokens scim_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.scim_tokens
    ADD CONSTRAINT scim_tokens_pkey PRIMARY KEY (id);


--
-- Name: session_records session_records_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.session_records
    ADD CONSTRAINT session_records_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sync_meetings sync_meetings_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.sync_meetings
    ADD CONSTRAINT sync_meetings_pkey PRIMARY KEY (id);


--
-- Name: themes themes_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.themes
    ADD CONSTRAINT themes_pkey PRIMARY KEY (id);


--
-- Name: time_entries time_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_pkey PRIMARY KEY (id);


--
-- Name: user_preferences user_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webhook_deliveries webhook_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.webhook_deliveries
    ADD CONSTRAINT webhook_deliveries_pkey PRIMARY KEY (id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- Name: work_item_type_fields work_item_type_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.work_item_type_fields
    ADD CONSTRAINT work_item_type_fields_pkey PRIMARY KEY (id);


--
-- Name: work_item_types work_item_types_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.work_item_types
    ADD CONSTRAINT work_item_types_pkey PRIMARY KEY (id);


--
-- Name: work_items work_items_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT work_items_pkey PRIMARY KEY (id);


--
-- Name: work_roles work_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.work_roles
    ADD CONSTRAINT work_roles_pkey PRIMARY KEY (id);


--
-- Name: accounting_periods_org_id_start_date_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX accounting_periods_org_id_start_date_key ON public.accounting_periods USING btree (org_id, start_date);


--
-- Name: accounting_periods_org_id_status_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX accounting_periods_org_id_status_idx ON public.accounting_periods USING btree (org_id, status);


--
-- Name: accounts_org_id_code_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX accounts_org_id_code_key ON public.accounts USING btree (org_id, code);


--
-- Name: accounts_org_id_type_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX accounts_org_id_type_idx ON public.accounts USING btree (org_id, type);


--
-- Name: activities_org_id_work_item_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX activities_org_id_work_item_id_idx ON public.activities USING btree (org_id, work_item_id);


--
-- Name: assistant_conversations_org_id_user_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX assistant_conversations_org_id_user_id_idx ON public.assistant_conversations USING btree (org_id, user_id);


--
-- Name: assistant_messages_conversation_id_created_at_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX assistant_messages_conversation_id_created_at_idx ON public.assistant_messages USING btree (conversation_id, created_at);


--
-- Name: audit_logs_org_id_created_at_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX audit_logs_org_id_created_at_idx ON public.audit_logs USING btree (org_id, created_at);


--
-- Name: bank_accounts_org_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX bank_accounts_org_id_idx ON public.bank_accounts USING btree (org_id);


--
-- Name: bank_rules_org_id_is_active_priority_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX bank_rules_org_id_is_active_priority_idx ON public.bank_rules USING btree (org_id, is_active, priority);


--
-- Name: bank_transactions_bank_account_id_external_id_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX bank_transactions_bank_account_id_external_id_key ON public.bank_transactions USING btree (bank_account_id, external_id);


--
-- Name: bank_transactions_bank_account_id_fingerprint_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX bank_transactions_bank_account_id_fingerprint_key ON public.bank_transactions USING btree (bank_account_id, fingerprint);


--
-- Name: bank_transactions_org_id_bank_account_id_status_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX bank_transactions_org_id_bank_account_id_status_idx ON public.bank_transactions USING btree (org_id, bank_account_id, status);


--
-- Name: board_columns_board_id_key_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX board_columns_board_id_key_key ON public.board_columns USING btree (board_id, key);


--
-- Name: board_templates_org_id_slug_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX board_templates_org_id_slug_key ON public.board_templates USING btree (org_id, slug);


--
-- Name: chat_alert_keywords_user_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX chat_alert_keywords_user_id_idx ON public.chat_alert_keywords USING btree (user_id);


--
-- Name: chat_alert_keywords_user_id_keyword_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX chat_alert_keywords_user_id_keyword_key ON public.chat_alert_keywords USING btree (user_id, keyword);


--
-- Name: chat_bot_channels_bot_id_channel_id_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX chat_bot_channels_bot_id_channel_id_key ON public.chat_bot_channels USING btree (bot_id, channel_id);


--
-- Name: chat_bot_channels_channel_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX chat_bot_channels_channel_id_idx ON public.chat_bot_channels USING btree (channel_id);


--
-- Name: chat_bot_runs_bot_id_created_at_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX chat_bot_runs_bot_id_created_at_idx ON public.chat_bot_runs USING btree (bot_id, created_at);


--
-- Name: chat_bot_runs_message_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX chat_bot_runs_message_id_idx ON public.chat_bot_runs USING btree (message_id);


--
-- Name: chat_bots_org_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX chat_bots_org_id_idx ON public.chat_bots USING btree (org_id);


--
-- Name: chat_bots_org_id_key_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX chat_bots_org_id_key_key ON public.chat_bots USING btree (org_id, key);


--
-- Name: chat_bots_user_id_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX chat_bots_user_id_key ON public.chat_bots USING btree (user_id);


--
-- Name: chat_channel_members_channel_id_user_id_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX chat_channel_members_channel_id_user_id_key ON public.chat_channel_members USING btree (channel_id, user_id);


--
-- Name: chat_channel_members_user_id_channel_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX chat_channel_members_user_id_channel_id_idx ON public.chat_channel_members USING btree (user_id, channel_id);


--
-- Name: chat_channels_org_id_dm_key_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX chat_channels_org_id_dm_key_key ON public.chat_channels USING btree (org_id, dm_key);


--
-- Name: chat_channels_org_id_kind_archived_at_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX chat_channels_org_id_kind_archived_at_idx ON public.chat_channels USING btree (org_id, kind, archived_at);


--
-- Name: chat_channels_org_id_last_message_at_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX chat_channels_org_id_last_message_at_idx ON public.chat_channels USING btree (org_id, last_message_at);


--
-- Name: chat_channels_org_id_slug_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX chat_channels_org_id_slug_key ON public.chat_channels USING btree (org_id, slug);


--
-- Name: chat_channels_project_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX chat_channels_project_id_idx ON public.chat_channels USING btree (project_id);


--
-- Name: chat_message_attachments_message_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX chat_message_attachments_message_id_idx ON public.chat_message_attachments USING btree (message_id);


--
-- Name: chat_message_attachments_uploaded_by_id_created_at_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX chat_message_attachments_uploaded_by_id_created_at_idx ON public.chat_message_attachments USING btree (uploaded_by_id, created_at);


--
-- Name: chat_message_mentions_message_id_user_id_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX chat_message_mentions_message_id_user_id_key ON public.chat_message_mentions USING btree (message_id, user_id);


--
-- Name: chat_message_mentions_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX chat_message_mentions_user_id_created_at_idx ON public.chat_message_mentions USING btree (user_id, created_at);


--
-- Name: chat_message_reactions_message_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX chat_message_reactions_message_id_idx ON public.chat_message_reactions USING btree (message_id);


--
-- Name: chat_message_reactions_message_id_user_id_emoji_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX chat_message_reactions_message_id_user_id_emoji_key ON public.chat_message_reactions USING btree (message_id, user_id, emoji);


--
-- Name: chat_messages_author_id_created_at_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX chat_messages_author_id_created_at_idx ON public.chat_messages USING btree (author_id, created_at);


--
-- Name: chat_messages_channel_id_created_at_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX chat_messages_channel_id_created_at_idx ON public.chat_messages USING btree (channel_id, created_at);


--
-- Name: chat_messages_channel_id_parent_message_id_created_at_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX chat_messages_channel_id_parent_message_id_created_at_idx ON public.chat_messages USING btree (channel_id, parent_message_id, created_at);


--
-- Name: chat_messages_content_tsv_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX chat_messages_content_tsv_idx ON public.chat_messages USING gin (content_tsv);


--
-- Name: chat_pinned_messages_channel_id_message_id_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX chat_pinned_messages_channel_id_message_id_key ON public.chat_pinned_messages USING btree (channel_id, message_id);


--
-- Name: chat_pinned_messages_channel_id_pinned_at_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX chat_pinned_messages_channel_id_pinned_at_idx ON public.chat_pinned_messages USING btree (channel_id, pinned_at);


--
-- Name: chat_thread_followers_parent_message_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX chat_thread_followers_parent_message_id_idx ON public.chat_thread_followers USING btree (parent_message_id);


--
-- Name: chat_thread_followers_user_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX chat_thread_followers_user_id_idx ON public.chat_thread_followers USING btree (user_id);


--
-- Name: chat_thread_followers_user_id_parent_message_id_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX chat_thread_followers_user_id_parent_message_id_key ON public.chat_thread_followers USING btree (user_id, parent_message_id);


--
-- Name: compliance_controls_org_id_framework_control_id_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX compliance_controls_org_id_framework_control_id_key ON public.compliance_controls USING btree (org_id, framework, control_id);


--
-- Name: compliance_controls_org_id_framework_status_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX compliance_controls_org_id_framework_status_idx ON public.compliance_controls USING btree (org_id, framework, status);


--
-- Name: contracts_org_id_status_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX contracts_org_id_status_idx ON public.contracts USING btree (org_id, status);


--
-- Name: crm_contacts_org_id_stage_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX crm_contacts_org_id_stage_idx ON public.crm_contacts USING btree (org_id, stage);


--
-- Name: custom_fields_org_id_key_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX custom_fields_org_id_key_key ON public.custom_fields USING btree (org_id, key);


--
-- Name: cycle_capacities_cycle_id_user_id_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX cycle_capacities_cycle_id_user_id_key ON public.cycle_capacities USING btree (cycle_id, user_id);


--
-- Name: cycles_project_id_number_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX cycles_project_id_number_key ON public.cycles USING btree (project_id, number);


--
-- Name: data_classifications_org_id_project_id_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX data_classifications_org_id_project_id_key ON public.data_classifications USING btree (org_id, project_id);


--
-- Name: data_classifications_project_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX data_classifications_project_id_idx ON public.data_classifications USING btree (project_id);


--
-- Name: documents_org_id_project_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX documents_org_id_project_id_idx ON public.documents USING btree (org_id, project_id);


--
-- Name: expenses_org_id_date_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX expenses_org_id_date_idx ON public.expenses USING btree (org_id, date);


--
-- Name: expenses_org_id_status_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX expenses_org_id_status_idx ON public.expenses USING btree (org_id, status);


--
-- Name: feedback_items_org_id_status_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX feedback_items_org_id_status_idx ON public.feedback_items USING btree (org_id, status);


--
-- Name: feedback_votes_feedback_item_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX feedback_votes_feedback_item_id_idx ON public.feedback_votes USING btree (feedback_item_id);


--
-- Name: feedback_votes_feedback_item_id_user_id_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX feedback_votes_feedback_item_id_user_id_key ON public.feedback_votes USING btree (feedback_item_id, user_id);


--
-- Name: home_widgets_org_id_owner_id_type_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX home_widgets_org_id_owner_id_type_key ON public.home_widgets USING btree (org_id, owner_id, type);


--
-- Name: integrations_org_id_provider_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX integrations_org_id_provider_key ON public.integrations USING btree (org_id, provider);


--
-- Name: invitations_token_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX invitations_token_idx ON public.invitations USING btree (token);


--
-- Name: invitations_token_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX invitations_token_key ON public.invitations USING btree (token);


--
-- Name: ip_allowlists_org_id_cidr_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX ip_allowlists_org_id_cidr_key ON public.ip_allowlists USING btree (org_id, cidr);


--
-- Name: journal_entries_org_id_date_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX journal_entries_org_id_date_idx ON public.journal_entries USING btree (org_id, date);


--
-- Name: journal_entries_org_id_entry_number_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX journal_entries_org_id_entry_number_key ON public.journal_entries USING btree (org_id, entry_number);


--
-- Name: journal_entries_org_id_reverses_id_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX journal_entries_org_id_reverses_id_key ON public.journal_entries USING btree (org_id, reverses_id);


--
-- Name: journal_entries_org_id_source_source_id_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX journal_entries_org_id_source_source_id_key ON public.journal_entries USING btree (org_id, source, source_id);


--
-- Name: journal_entries_org_id_status_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX journal_entries_org_id_status_idx ON public.journal_entries USING btree (org_id, status);


--
-- Name: journal_lines_journal_entry_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX journal_lines_journal_entry_id_idx ON public.journal_lines USING btree (journal_entry_id);


--
-- Name: journal_lines_org_id_account_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX journal_lines_org_id_account_id_idx ON public.journal_lines USING btree (org_id, account_id);


--
-- Name: journal_lines_org_id_project_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX journal_lines_org_id_project_id_idx ON public.journal_lines USING btree (org_id, project_id);


--
-- Name: key_results_objective_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX key_results_objective_id_idx ON public.key_results USING btree (objective_id);


--
-- Name: mcp_servers_org_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX mcp_servers_org_id_idx ON public.mcp_servers USING btree (org_id);


--
-- Name: meeting_attendees_meeting_id_user_id_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX meeting_attendees_meeting_id_user_id_key ON public.meeting_attendees USING btree (meeting_id, user_id);


--
-- Name: notes_org_id_visibility_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX notes_org_id_visibility_idx ON public.notes USING btree (org_id, visibility);


--
-- Name: notifications_user_id_read_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX notifications_user_id_read_idx ON public.notifications USING btree (user_id, read);


--
-- Name: objectives_org_id_project_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX objectives_org_id_project_id_idx ON public.objectives USING btree (org_id, project_id);


--
-- Name: org_member_work_roles_work_role_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX org_member_work_roles_work_role_id_idx ON public.org_member_work_roles USING btree (work_role_id);


--
-- Name: org_members_org_id_user_id_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX org_members_org_id_user_id_key ON public.org_members USING btree (org_id, user_id);


--
-- Name: org_security_settings_org_id_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX org_security_settings_org_id_key ON public.org_security_settings USING btree (org_id);


--
-- Name: organizations_auth0_org_id_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX organizations_auth0_org_id_key ON public.organizations USING btree (auth0_org_id);


--
-- Name: organizations_slug_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX organizations_slug_key ON public.organizations USING btree (slug);


--
-- Name: partners_org_id_status_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX partners_org_id_status_idx ON public.partners USING btree (org_id, status);


--
-- Name: products_org_id_status_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX products_org_id_status_idx ON public.products USING btree (org_id, status);


--
-- Name: project_members_project_id_org_member_id_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX project_members_project_id_org_member_id_key ON public.project_members USING btree (project_id, org_member_id);


--
-- Name: project_templates_org_id_slug_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX project_templates_org_id_slug_key ON public.project_templates USING btree (org_id, slug);


--
-- Name: projects_org_id_key_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX projects_org_id_key_key ON public.projects USING btree (org_id, key);


--
-- Name: push_subscriptions_endpoint_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX push_subscriptions_endpoint_key ON public.push_subscriptions USING btree (endpoint);


--
-- Name: push_subscriptions_user_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX push_subscriptions_user_id_idx ON public.push_subscriptions USING btree (user_id);


--
-- Name: revenues_org_id_date_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX revenues_org_id_date_idx ON public.revenues USING btree (org_id, date);


--
-- Name: saved_reports_org_id_type_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX saved_reports_org_id_type_idx ON public.saved_reports USING btree (org_id, type);


--
-- Name: scim_tokens_org_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX scim_tokens_org_id_idx ON public.scim_tokens USING btree (org_id);


--
-- Name: session_records_org_id_user_id_status_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX session_records_org_id_user_id_status_idx ON public.session_records USING btree (org_id, user_id, status);


--
-- Name: session_records_session_token_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX session_records_session_token_idx ON public.session_records USING btree (session_token);


--
-- Name: session_records_session_token_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX session_records_session_token_key ON public.session_records USING btree (session_token);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX sessions_user_id_idx ON public.sessions USING btree (user_id);


--
-- Name: sync_meetings_org_id_meeting_date_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX sync_meetings_org_id_meeting_date_idx ON public.sync_meetings USING btree (org_id, meeting_date);


--
-- Name: themes_org_id_slug_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX themes_org_id_slug_key ON public.themes USING btree (org_id, slug);


--
-- Name: time_entries_org_id_status_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX time_entries_org_id_status_idx ON public.time_entries USING btree (org_id, status);


--
-- Name: time_entries_org_id_user_id_date_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX time_entries_org_id_user_id_date_idx ON public.time_entries USING btree (org_id, user_id, date);


--
-- Name: user_preferences_user_id_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX user_preferences_user_id_key ON public.user_preferences USING btree (user_id);


--
-- Name: users_auth0_user_id_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX users_auth0_user_id_key ON public.users USING btree (auth0_user_id);


--
-- Name: users_google_id_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX users_google_id_key ON public.users USING btree (google_id);


--
-- Name: webhook_deliveries_webhook_id_created_at_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX webhook_deliveries_webhook_id_created_at_idx ON public.webhook_deliveries USING btree (webhook_id, created_at);


--
-- Name: webhooks_org_id_active_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX webhooks_org_id_active_idx ON public.webhooks USING btree (org_id, active);


--
-- Name: work_item_type_fields_work_item_type_id_custom_field_id_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX work_item_type_fields_work_item_type_id_custom_field_id_key ON public.work_item_type_fields USING btree (work_item_type_id, custom_field_id);


--
-- Name: work_item_types_org_id_key_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX work_item_types_org_id_key_key ON public.work_item_types USING btree (org_id, key);


--
-- Name: work_items_org_id_assignee_id_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX work_items_org_id_assignee_id_idx ON public.work_items USING btree (org_id, assignee_id);


--
-- Name: work_items_org_id_column_key_idx; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE INDEX work_items_org_id_column_key_idx ON public.work_items USING btree (org_id, column_key);


--
-- Name: work_items_org_id_project_id_ticket_number_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX work_items_org_id_project_id_ticket_number_key ON public.work_items USING btree (org_id, project_id, ticket_number);


--
-- Name: work_roles_org_id_key_key; Type: INDEX; Schema: public; Owner: cosmos
--

CREATE UNIQUE INDEX work_roles_org_id_key_key ON public.work_roles USING btree (org_id, key);


--
-- Name: accounts accounts_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: activities activities_work_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_work_item_id_fkey FOREIGN KEY (work_item_id) REFERENCES public.work_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: api_keys api_keys_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: assistant_conversations assistant_conversations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.assistant_conversations
    ADD CONSTRAINT assistant_conversations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: assistant_messages assistant_messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.assistant_messages
    ADD CONSTRAINT assistant_messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.assistant_conversations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bank_transactions bank_transactions_bank_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.bank_transactions
    ADD CONSTRAINT bank_transactions_bank_account_id_fkey FOREIGN KEY (bank_account_id) REFERENCES public.bank_accounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: board_columns board_columns_board_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.board_columns
    ADD CONSTRAINT board_columns_board_id_fkey FOREIGN KEY (board_id) REFERENCES public.boards(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: board_template_widgets board_template_widgets_parent_widget_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.board_template_widgets
    ADD CONSTRAINT board_template_widgets_parent_widget_id_fkey FOREIGN KEY (parent_widget_id) REFERENCES public.board_template_widgets(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: board_template_widgets board_template_widgets_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.board_template_widgets
    ADD CONSTRAINT board_template_widgets_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.board_templates(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: board_templates board_templates_project_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.board_templates
    ADD CONSTRAINT board_templates_project_template_id_fkey FOREIGN KEY (project_template_id) REFERENCES public.project_templates(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: board_templates board_templates_source_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.board_templates
    ADD CONSTRAINT board_templates_source_template_id_fkey FOREIGN KEY (source_template_id) REFERENCES public.board_templates(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: boards boards_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.boards
    ADD CONSTRAINT boards_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_alert_keywords chat_alert_keywords_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_alert_keywords
    ADD CONSTRAINT chat_alert_keywords_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_bot_channels chat_bot_channels_bot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_bot_channels
    ADD CONSTRAINT chat_bot_channels_bot_id_fkey FOREIGN KEY (bot_id) REFERENCES public.chat_bots(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_bot_channels chat_bot_channels_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_bot_channels
    ADD CONSTRAINT chat_bot_channels_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.chat_channels(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_bot_runs chat_bot_runs_bot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_bot_runs
    ADD CONSTRAINT chat_bot_runs_bot_id_fkey FOREIGN KEY (bot_id) REFERENCES public.chat_bots(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_bot_runs chat_bot_runs_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_bot_runs
    ADD CONSTRAINT chat_bot_runs_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.chat_messages(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_bot_runs chat_bot_runs_triggered_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_bot_runs
    ADD CONSTRAINT chat_bot_runs_triggered_by_user_id_fkey FOREIGN KEY (triggered_by_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: chat_bots chat_bots_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_bots
    ADD CONSTRAINT chat_bots_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_bots chat_bots_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_bots
    ADD CONSTRAINT chat_bots_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_channel_members chat_channel_members_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_channel_members
    ADD CONSTRAINT chat_channel_members_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.chat_channels(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_channels chat_channels_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_channels
    ADD CONSTRAINT chat_channels_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_message_attachments chat_message_attachments_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_message_attachments
    ADD CONSTRAINT chat_message_attachments_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.chat_messages(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_message_mentions chat_message_mentions_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_message_mentions
    ADD CONSTRAINT chat_message_mentions_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.chat_messages(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_message_reactions chat_message_reactions_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_message_reactions
    ADD CONSTRAINT chat_message_reactions_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.chat_messages(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_messages chat_messages_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.chat_channels(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_messages chat_messages_parent_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_parent_message_id_fkey FOREIGN KEY (parent_message_id) REFERENCES public.chat_messages(id) ON UPDATE CASCADE;


--
-- Name: chat_pinned_messages chat_pinned_messages_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_pinned_messages
    ADD CONSTRAINT chat_pinned_messages_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.chat_channels(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_pinned_messages chat_pinned_messages_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_pinned_messages
    ADD CONSTRAINT chat_pinned_messages_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.chat_messages(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_thread_followers chat_thread_followers_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_thread_followers
    ADD CONSTRAINT chat_thread_followers_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.chat_channels(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_thread_followers chat_thread_followers_parent_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_thread_followers
    ADD CONSTRAINT chat_thread_followers_parent_message_id_fkey FOREIGN KEY (parent_message_id) REFERENCES public.chat_messages(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_thread_followers chat_thread_followers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.chat_thread_followers
    ADD CONSTRAINT chat_thread_followers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: comments comments_work_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_work_item_id_fkey FOREIGN KEY (work_item_id) REFERENCES public.work_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: compliance_controls compliance_controls_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.compliance_controls
    ADD CONSTRAINT compliance_controls_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: contracts contracts_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_partner_id_fkey FOREIGN KEY (partner_id) REFERENCES public.partners(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: contracts contracts_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: cycle_capacities cycle_capacities_cycle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.cycle_capacities
    ADD CONSTRAINT cycle_capacities_cycle_id_fkey FOREIGN KEY (cycle_id) REFERENCES public.cycles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cycle_capacities cycle_capacities_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.cycle_capacities
    ADD CONSTRAINT cycle_capacities_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cycles cycles_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.cycles
    ADD CONSTRAINT cycles_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cycles cycles_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.cycles
    ADD CONSTRAINT cycles_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dashboard_widgets dashboard_widgets_board_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.dashboard_widgets
    ADD CONSTRAINT dashboard_widgets_board_id_fkey FOREIGN KEY (board_id) REFERENCES public.boards(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: data_classifications data_classifications_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.data_classifications
    ADD CONSTRAINT data_classifications_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: data_classifications data_classifications_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.data_classifications
    ADD CONSTRAINT data_classifications_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: documents documents_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: documents documents_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: feedback_items feedback_items_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.feedback_items
    ADD CONSTRAINT feedback_items_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: feedback_votes feedback_votes_feedback_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.feedback_votes
    ADD CONSTRAINT feedback_votes_feedback_item_id_fkey FOREIGN KEY (feedback_item_id) REFERENCES public.feedback_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: home_widgets home_widgets_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.home_widgets
    ADD CONSTRAINT home_widgets_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: home_widgets home_widgets_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.home_widgets
    ADD CONSTRAINT home_widgets_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: integrations integrations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.integrations
    ADD CONSTRAINT integrations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invitations invitations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.invitations
    ADD CONSTRAINT invitations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ip_allowlists ip_allowlists_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.ip_allowlists
    ADD CONSTRAINT ip_allowlists_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: journal_entries journal_entries_reverses_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_reverses_id_fkey FOREIGN KEY (reverses_id) REFERENCES public.journal_entries(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: journal_lines journal_lines_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT journal_lines_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: journal_lines journal_lines_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT journal_lines_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.contracts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: journal_lines journal_lines_journal_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT journal_lines_journal_entry_id_fkey FOREIGN KEY (journal_entry_id) REFERENCES public.journal_entries(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: journal_lines journal_lines_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.journal_lines
    ADD CONSTRAINT journal_lines_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: key_results key_results_objective_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.key_results
    ADD CONSTRAINT key_results_objective_id_fkey FOREIGN KEY (objective_id) REFERENCES public.objectives(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: mcp_servers mcp_servers_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.mcp_servers
    ADD CONSTRAINT mcp_servers_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: meeting_attendees meeting_attendees_meeting_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.meeting_attendees
    ADD CONSTRAINT meeting_attendees_meeting_id_fkey FOREIGN KEY (meeting_id) REFERENCES public.sync_meetings(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: objectives objectives_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.objectives
    ADD CONSTRAINT objectives_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: objectives objectives_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.objectives
    ADD CONSTRAINT objectives_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: org_member_work_roles org_member_work_roles_org_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.org_member_work_roles
    ADD CONSTRAINT org_member_work_roles_org_member_id_fkey FOREIGN KEY (org_member_id) REFERENCES public.org_members(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: org_member_work_roles org_member_work_roles_work_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.org_member_work_roles
    ADD CONSTRAINT org_member_work_roles_work_role_id_fkey FOREIGN KEY (work_role_id) REFERENCES public.work_roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: org_members org_members_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: org_members org_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: org_security_settings org_security_settings_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.org_security_settings
    ADD CONSTRAINT org_security_settings_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_members project_members_org_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.project_members
    ADD CONSTRAINT project_members_org_member_id_fkey FOREIGN KEY (org_member_id) REFERENCES public.org_members(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_members project_members_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.project_members
    ADD CONSTRAINT project_members_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_templates project_templates_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.project_templates
    ADD CONSTRAINT project_templates_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_templates project_templates_source_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.project_templates
    ADD CONSTRAINT project_templates_source_template_id_fkey FOREIGN KEY (source_template_id) REFERENCES public.project_templates(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: projects projects_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: projects projects_project_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_project_template_id_fkey FOREIGN KEY (project_template_id) REFERENCES public.project_templates(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: push_subscriptions push_subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: saved_reports saved_reports_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.saved_reports
    ADD CONSTRAINT saved_reports_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: scim_tokens scim_tokens_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.scim_tokens
    ADD CONSTRAINT scim_tokens_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: session_records session_records_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.session_records
    ADD CONSTRAINT session_records_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_preferences user_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: webhook_deliveries webhook_deliveries_webhook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.webhook_deliveries
    ADD CONSTRAINT webhook_deliveries_webhook_id_fkey FOREIGN KEY (webhook_id) REFERENCES public.webhooks(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: webhooks webhooks_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: work_item_type_fields work_item_type_fields_custom_field_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.work_item_type_fields
    ADD CONSTRAINT work_item_type_fields_custom_field_id_fkey FOREIGN KEY (custom_field_id) REFERENCES public.custom_fields(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: work_item_type_fields work_item_type_fields_work_item_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.work_item_type_fields
    ADD CONSTRAINT work_item_type_fields_work_item_type_id_fkey FOREIGN KEY (work_item_type_id) REFERENCES public.work_item_types(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: work_item_types work_item_types_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.work_item_types
    ADD CONSTRAINT work_item_types_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: work_item_types work_item_types_project_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.work_item_types
    ADD CONSTRAINT work_item_types_project_template_id_fkey FOREIGN KEY (project_template_id) REFERENCES public.project_templates(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: work_items work_items_cycle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT work_items_cycle_id_fkey FOREIGN KEY (cycle_id) REFERENCES public.cycles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: work_items work_items_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT work_items_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.work_items(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: work_items work_items_work_item_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.work_items
    ADD CONSTRAINT work_items_work_item_type_id_fkey FOREIGN KEY (work_item_type_id) REFERENCES public.work_item_types(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: work_roles work_roles_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cosmos
--

ALTER TABLE ONLY public.work_roles
    ADD CONSTRAINT work_roles_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO cosmos;


--
-- PostgreSQL database dump complete
--

\unrestrict GJCjCN0GFtlAHWdjwiw2YxF72JtWcf4dAojP3UWWcKqollutH5LsLLXU7phinU1

